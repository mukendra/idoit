<?php
/**
 * Handler for AJAX requests.
 *
 * @package     i-doit
 * @subpackage  General
 * @author      i-doit-team
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

global $g_absdir, $g_comp_session, $g_comp_template;

switch ($_GET["request"])
{
    case "breadcrumb":

        // Enable cache lifetime of 7 days
        isys_core::expire(isys_convert::WEEK);

        $g_comp_session->write_close();
        $g_comp_session->include_mandator_cache();

        $l_menutree = new isys_component_tree("menu_tree");
        $l_modman   = isys_module_manager::instance();

        if ($l_modman)
        {
            $l_modman->module_loader();

            // Prepare module request.
            $g_modreq        = isys_module_request::build($l_menutree, $g_comp_template, $_GET, $_POST, isys_component_template_navbar::getInstance(), $g_comp_database, $l_modman);
            $g_active_modreq = & $g_modreq;

            $l_modman->init($g_modreq);

            $l_module_id = (isset($_GET[C__GET__MODULE_ID])) ?
                $_GET[C__GET__MODULE_ID] :
                C__MODULE__CMDB;

            $l_breadcrumb = new isys_component_template_breadcrumb();

            echo stripslashes($l_breadcrumb->include_home()->process(false, '</li>', $l_module_id, '<li>'));
        }
        die;

        break;

    case "mydoit":
    case "mydoit_addBookmark":
    case "mydoit_deleteBookmark":
    case "mysearch_viewCriterias":
    case "mysearch_addCriterion":
    case "mysearch_delCriterion":
        if (defined('C__MODULE__PRO'))
        {
            global $g_comp_template;
            $g_output_done = true;
            include_once("hypergate.inc.php");
            require_once("classes/modules/pro/mydoit/my-doit.inc.php");
            $g_comp_template->display("file:content/my-doit.tpl");
            die;
        }
        break;

    case "toObjectView":
    case "toLocationView":
        break;

    case "object":
        global $g_comp_database, $g_comp_template_language_manager;
        $l_dao = new isys_cmdb_dao($g_comp_database);

        if ($_GET[C__CMDB__GET__OBJECT])
        {
            $l_out = "";

            if ($_GET["objtype"] == "1")
            {
                $l_type_id = $l_dao->get_objTypeID($_GET[C__CMDB__GET__OBJECT]);
                if ($l_type_id > 0)
                {
                    $l_out .=
                        $g_comp_template_language_manager->{
                            $l_dao->get_objtype_name_by_id_as_string($l_type_id)
                            } .
                        ": ";
                }
            }
            else $l_type_id = false;

            $l_object_name = $l_dao->get_obj_name_by_id_as_string($_GET[C__CMDB__GET__OBJECT]);

            if ($l_object_name != "")
            {
                $l_out .= $l_object_name;
            }
            else
            {
                $l_out .= "N/A";
            }

	        echo '<p class="bold">' . isys_glob_cut_string($l_out, 42) . '</p>';

            if ($l_type_id)
            {
                echo '<script type="javascript">if ($("obj_type")) {select_obj_type("' . $l_type_id . '");}</script>';
            }
        }
        else
        {
            echo C__GUI_VALUE__NA;
        } // if

        die;

        break;
    default:
        $g_ajax        = true;
        $g_output_done = true;
        $l_get         = $_GET;
        $l_post        = $_POST;

        /* Initialize the AJAX-Handler and call the request */
        $l_ajax = new isys_ajax($l_get, $l_post);

        /* Get locales class */
        include_once($g_absdir . "/src/locales.inc.php");

        /**
         * Check if ajax handler needs including the hypergate
         * note that hypergate automatically loads the CMDB module which can be a high overload.
         */
        if ($l_ajax->needs_hypergate($l_get[C__GET__AJAX_CALL]))
        {
            include_once("hypergate.inc.php");
        }
        else
        {
            $g_menutree      = new isys_component_tree("menu_tree");
            $g_active_modreq = isys_module_request::build(
                $g_menutree, $g_comp_template,
                $l_get, $l_post,
                isys_component_template_navbar::getInstance(), $g_comp_database,
                isys_module_manager::instance()
            );

            isys_module_manager::instance()->init($g_active_modreq);
        }

        // Removed: isys_rs_system

        /**
         * Include mandator-specific constant cache if category constants are undefined
         */
        if (!defined('C__CATG__GLOBAL' && is_array($g_mandator_info)))
        {
            $l_dcm = new isys_component_constant_manager();

            // If not exist, create the constant file (so delete the cachefile to rebuild it)
            $l_dcm_file = $l_dcm->set_subdir($g_mandator_info["isys_mandator__dir_cache"]); // build mandator cache file in the specific subdirech
            if (!file_exists($l_dcm_file))
            {
                $l_dcm->create_dcm_cache();
            }

            include_once($l_dcm_file);
        }

        /* Handle nag screen */
        if (class_exists('isys_module_licence'))
            isys_module_licence::show_nag_screen();

        // Get global locale component.
        if (is_null($g_loc))
        {
            $g_loc = isys_locale::get(
                $g_comp_database,
                $g_comp_session->get_user_id()
            );
        }

        $l_init = $l_ajax->init($l_get[C__GET__AJAX_CALL]);

        break;
}
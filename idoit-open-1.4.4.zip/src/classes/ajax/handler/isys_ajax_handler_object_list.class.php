<?php
/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Dennis Stücken <dstuecken@synetics.de>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_ajax_handler_object_list extends isys_ajax_handler
{
	/**
	 * Define, if this ajax request needs the hypergate logic.
	 *
	 * @static
	 * @return  boolean
	 */
	public static function needs_hypergate()
	{
		return true;
	} // function


	/**
	 * Init method for this request.
	 */
	public function init()
	{
		// For backwards compatibility we use this.
		if (! $_GET['func'])
		{
			global $g_comp_template;

			// Display the template.
			$g_comp_template->display("file:" . $this->m_smarty_dir . "templates/content/main_groups.tpl");

			// End the request.
			$this->_die();
		} // if

		switch ($_GET['func'])
		{
			case 'load_objtype_list':
				$this->load_objtype_list();
				break;
		} // switch
	} // function


	/**
	 * Loads further pages for the new list component.
	 *
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function load_objtype_list()
	{
		header('Content-type: application/json');

		$l_return = '';

		$l_dao = $_GET['dao'];

		if (class_exists($l_dao))
		{
			$l_dao = new $l_dao($this->m_database_component);

			$l_dao->set_object_type((int) $_GET['object_type']);
			$l_return = $l_dao->get_list_data((int) $_POST['offset_block']);
		} // if

		echo $l_return;

		$this->_die();
	} // function
} // class
?>
<?php

/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Van Quyen Hoang <qhoang@i-doit.org>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       1.0
 */
class isys_ajax_handler_ocs_import extends isys_ajax_handler
{
	/**
	 * Init method, which gets called from the framework.
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function init()
	{
		// We set the header information because we don't accept anything than JSON.
		header('Content-Type: application/json');

		$l_return = array();

		switch ($_GET['func'])
		{
			case 'object_list':
				$l_return = $this->get_ocs_object_list($_POST['ocs_id']);
				break;
		} // switch

		echo isys_format_json::encode($l_return);
		$this->_die();
	} // function


	private function get_ocs_object_list($p_db_id){
		global $g_comp_database, $g_comp_database_system, $g_config;

		$l_dao_comp = new isys_component_dao_ocs($g_comp_database);
		$l_settings = $l_dao_comp->getOCSDB($p_db_id);

		try
		{
			if ($l_settings == null)
			{
				throw new Exception("Es wurde keine Datenbank angegeben");
			} // if

			$g_comp_database->close();
			$g_comp_database_system->close();

			$l_ocsdb = isys_component_database::get_database(
				"mysql",
				$l_settings["isys_ocs_db__host"],
				$l_settings["isys_ocs_db__port"],
				$l_settings["isys_ocs_db__user"],
				isys_helper_crypt::decrypt($l_settings["isys_ocs_db__pass"]),
				$l_settings["isys_ocs_db__schema"]);

			$g_comp_database->reconnect();
			$g_comp_database_system->reconnect();
		}
		catch (Exception $e)
		{
			return null;
		}

		$l_daoOCS = new isys_component_dao_ocs($l_ocsdb);

		$l_inventory = $l_daoOCS->getHardware();

		$l_ocsObj = array();
		while ($l_row = $l_inventory->get_row())
		{
			$l_row["imported"] = isys_locale::get_instance()->fmt_date($l_dao_comp
				->retrieve("SELECT isys_obj__imported FROM isys_obj WHERE isys_obj__hostname = '" . $l_row["NAME"] . "'")
				->get_row_value('isys_obj__imported'));
			$l_ocsObj[] = $l_row;
		}

		return $l_ocsObj;
	} // function
} // class
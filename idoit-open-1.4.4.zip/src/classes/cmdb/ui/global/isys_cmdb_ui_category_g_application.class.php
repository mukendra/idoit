<?php
/**
 * i-doit
 *
 * CMDB UI: Application category (category type is global):
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Niclas Potthast <npotthast@i-doit.org>
 * @author      Andre Wösten <awoesten@i-doit.org>
 * @version     0.9
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

class isys_cmdb_ui_category_g_application extends isys_cmdb_ui_category_global
{

	/**
	 * Show the detail-template for subcategories of application.
	 *
	 * @param   isys_cmdb_dao_category_g_application  $p_cat
	 * @author  Niclas Potthast <npotthast@i-doit.org>
	 */
	public function process (isys_cmdb_dao_category_g_application $p_cat)
	{
		$l_app_assigned_obj_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_application_assigned_obj', $p_cat->get_database_component());

		if ($_GET["app_variants"])
		{
			$l_arr = array();
			$l_data = $l_app_assigned_obj_dao->get_variants($_POST['application_id']);

			foreach ($l_data as $l_key => $l_val)
			{
				$l_arr[] = array(
					'id' => $l_key,
					'val' => isys_glob_utf8_encode($l_val)
				);
			} // foreach

			header('Content-Type: application/json');
			echo isys_format_json::encode($l_arr);

			die;
		} // if

		$l_rules = array();
		$l_catdata = $p_cat->get_general_data();

		$this->fill_formfields($p_cat, $l_rules, $l_catdata);

		$l_rules["C__CATG__APPLICATION_OBJ_APPLICATION"]["p_strSelectedID"] = $l_catdata['isys_connection__isys_obj__id'];

		$this->get_template_component()
			->assign("application_ajax_url", "?" . http_build_query($_GET, null, "&") . "&call=category&" . C__CMDB__GET__CATLEVEL . "=" . $l_catdata["isys_catg_application_list__id"] . '&app_variants=1')
			->smarty_tom_add_rules("tom.content.bottom.content", $l_rules);
	} // function
} // class
<?php
/**
 * i-doit
 *
 * CMDB Action Processor
 *
 * Action: Object delete
 *
 * @package     i-doit
 * @subpackage  CMDB
 * @author      Andre Woesten <awoesten@i-doit.de>
 * @version     0.9
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

class isys_cmdb_action_object_rank implements isys_cmdb_action
{
	/**
	 * Handle method for ranking action.
	 *
	 * @global  isys_component_signalcollection  $g_comp_signals
	 * @param   isys_cmdb_dao  $p_dao
	 * @param   array          $p_data
	 * @throws  isys_exception_cmdb
	 */
	public function handle (isys_cmdb_dao $p_dao, &$p_data)
	{
		global $g_comp_signals;

		$p_direction = $p_data[0];
		$p_objects = $p_data[1];
		
		if (is_array($p_objects) && count($p_objects) > 0)
		{
			// Check, if the user is allowed to rank the object.
			foreach ($p_objects as $l_object)
			{
				isys_auth::factory(C__MODULE__CMDB)->check(isys_auth::DELETE, 'OBJ_ID/' . $l_object);
			} // foreach

			$g_comp_signals->emit("mod.cmdb.beforeObjectRank", $p_dao, $p_direction, $p_objects);

			if (!$p_dao->rank_records($p_objects, $p_direction, "isys_obj"))
			{
				throw new isys_exception_cmdb("Could not delete objects (#" . implode(', #', $p_objects) . ") (isys_cmdb_dao->rank_records())", C__CMDB__ERROR__ACTION_PROCESSOR);
			} // if

			$g_comp_signals->emit("mod.cmdb.afterObjectRank", $p_dao, $p_direction, $p_objects);
		} // if
	} // function
} // class
?>
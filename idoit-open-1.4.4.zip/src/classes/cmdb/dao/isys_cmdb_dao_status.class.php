<?php
/**
 * i-doit
 *
 * Status DAO.
 *
 * @package    i-doit
 * @author     Dennis Stücken <dstuecken@i-doit.org>
 * @version    1.0
 * @copyright  synetics GmbH
 * @license    http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

class isys_cmdb_dao_status extends isys_cmdb_dao
{
	/**
	 * Return CMDB/ITIL Status
	 *
	 * @param   mixed   $p_status
	 * @param   string  $p_condition
	 * @return  isys_component_dao_result
	 */
	public function get_cmdb_status ($p_status = null, $p_condition = '')
	{
		$l_sql = "SELECT * FROM isys_cmdb_status WHERE TRUE";

		if ($p_status !== null)
		{
			if (is_numeric($p_status))
			{
				$l_sql .= " AND isys_cmdb_status__id = " . $this->convert_sql_id($p_status);
			}
			else
			{
				$l_sql .= " AND isys_cmdb_status__const = " . $this->convert_sql_text($p_status);
			}// if
		} // if

		return $this->retrieve($l_sql . ' ' . $p_condition . ';');
	} // function


	/**
	 * Description.
	 *
	 * @param   string  $p_const
	 * @return  isys_component_dao_result
	 */
	public function get_cmdb_status_by_const ($p_const)
	{
		return $this->get_cmdb_status(null, 'AND isys_cmdb_status__const = ' . $this->convert_sql_text($p_const));
	} // function


	/**
	 * Retrieves a CMDB status ID by its constant.
	 *
	 * @param   string  $p_const
	 * @return  integer
	 */
	public function get_cmdb_status_by_const_as_int ($p_const)
	{
		$l_return = $this->get_cmdb_status(null, 'AND isys_cmdb_status__const = ' . $this->convert_sql_text($p_const))->get_row();

		return (is_array($l_return) ? $l_return['isys_cmdb_status__id'] : null);
	} // function


	/**
	 * Return CMDB/ITIL Status.
	 *
	 * @deprecated  Just use get_cmdb_status().
	 * @param       integer  $p_id
	 * @param       string   $p_condition
	 * @return      isys_component_dao_result
	 */
	public function get_status ($p_id = null, $p_condition = '')
	{
		return $this->get_cmdb_status($p_id, $p_condition);
	} // function


	/**
	 * Description.
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_new_status
	 * @return  mixed
	 */
	public function add_change ($p_obj_id, $p_new_status)
	{
		if ($p_obj_id > 0)
		{
			$l_sql = 'INSERT INTO isys_cmdb_status_changes
				SET isys_cmdb_status_changes__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ',
				isys_cmdb_status_changes__isys_cmdb_status__id = ' . $this->convert_sql_id($p_new_status) . ';';

			if ($this->update($l_sql) && $this->apply_update())
			{
				return $this->get_last_insert_id();
			} // if
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Description.
	 *
	 * @param   integer  $p_id
	 * @param   string   $p_const
	 * @param   string   $p_title
	 * @param   string   $p_color
	 * @return  boolean
	 */
	public function save ($p_id, $p_const, $p_title, $p_color = "FFFFFF")
	{
		$l_sql = 'UPDATE isys_cmdb_status
			SET isys_cmdb_status__const = ' . $this->convert_sql_text($p_const) . ',
			isys_cmdb_status__title = ' . $this->convert_sql_text($p_title) . ',
			isys_cmdb_status__color = ' . $this->convert_sql_text($p_color) . '
			WHERE isys_cmdb_status__id = ' . $this->convert_sql_id($p_id) . ';';

		return $this->update($l_sql) && $this->apply_update();
	} // function


	/**
	 * Description.
	 *
	 * @param   string  $p_const
	 * @param   string  $p_title
	 * @param   string  $p_color
	 * @return  mixed
	 */
	public function create ($p_const, $p_title, $p_color)
	{
		$l_sql = 'INSERT INTO isys_cmdb_status
			SET isys_cmdb_status__const = ' . $this->convert_sql_text($p_const) . ',
			isys_cmdb_status__title = ' . $this->convert_sql_text($p_title) . ',
			isys_cmdb_status__color = ' . $this->convert_sql_text($p_color) . ',
			isys_cmdb_status__editable = 1;';

		if ($this->update($l_sql) && $this->apply_update())
		{
			return $this->get_last_insert_id();
		} // if

		return false;
	} // function

	/**
	 * Description.
	 *
	 * @param   integer  $p_id
	 * @return  boolean
	 */
	public function delete_status ($p_id)
	{
		return ($this->update('DELETE FROM isys_cmdb_status WHERE isys_cmdb_status__id = ' . $this->convert_sql_id($p_id) . ';') && $this->apply_update());
	} // function


	/**
	 * Description.
	 *
	 * @param   integer  $p_status_id
	 * @return  mixed
	 */
	public function get_cmdb_status_color ($p_status_id)
	{
		$l_cmdb_status = $this->get_cmdb_status($p_status_id)->get_row();

		return $l_cmdb_status["isys_cmdb_status__color"];
	} // function
} // class
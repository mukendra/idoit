<?php

/**
 * i-doit
 *
 * DAO: global category for virtual hosts
 *
 * @package i-doit
 * @subpackage CMDB_Categories
 * @author Van Quyen Hoang <qhoang@i-doit.org>
 * @copyright synetics GmbH
 * @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_virtual_host
	extends isys_cmdb_dao_category_global {

    /**
     * Category's name. Will be used for the identifier, constant, main table,
     * and many more.
     *
     * @var string
     */
    protected $m_category = 'virtual_host';

    /**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 */
	protected function properties()
	{
		return array(
			'virtual_host' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__VIRTUAL_HOST',
						C__PROPERTY__INFO__DESCRIPTION => 'defines if object is a virtual host'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_host_list__virtual_host'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VIRTUAL_HOST__YES_NO',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => serialize(get_smarty_arr_YES_NO()),
						)
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_yes_or_no'
						)
					)
				)),
			'license_server' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CLUSTER__LICENSE_SERVER',
						C__PROPERTY__INFO__DESCRIPTION => 'Defines which object is the licence server'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_host_list__license_server',
						C__PROPERTY__DATA__FIELD_ALIAS => 'licence_server_connection',
						C__PROPERTY__DATA__TABLE_ALIAS => 'connection_licence_server',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_connection',
							'isys_connection__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VIRTUAL_HOST__LICENSE_SERVER',
						C__PROPERTY__UI__PARAMS => array(
							'groupFilter' => 'C__OBJTYPE_GROUP__INFRASTRUCTURE;C__OBJTYPE_GROUP__OTHER;C__OBJTYPE_GROUP__SOFTWARE'
						)
					),
					C__PROPERTY__FORMAT => array(
							C__PROPERTY__FORMAT__CALLBACK => array(
								'isys_export_helper',
								'connection'
							)
						),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false
					)
				)),
			'administration_service' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CLUSTER__ADMINISTRATION_SERVICE',
						C__PROPERTY__INFO__DESCRIPTION => 'Defines which object is the administration service'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_host_list__administration_service',
						C__PROPERTY__DATA__FIELD_ALIAS => 'administration_service_connection',
						C__PROPERTY__DATA__TABLE_ALIAS => 'connection_administration_service',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_connection',
							'isys_connection__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VIRTUAL_HOST__ADMINISTRATION_SERVICE',
						C__PROPERTY__UI__PARAMS => array(
							'groupFilter' => 'C__OBJTYPE_GROUP__INFRASTRUCTURE;C__OBJTYPE_GROUP__OTHER;C__OBJTYPE_GROUP__SOFTWARE',
							'p_strPopupType' => 'browser_object_relation',
							'relationFilter' => 'C__RELATION_TYPE__SOFTWARE'
						)
					),
					C__PROPERTY__FORMAT => array(
							C__PROPERTY__FORMAT__CALLBACK => array(
								'isys_export_helper',
								'database_instance'
							)
						),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => true,
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'categories description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_host_list__description',
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__VIRTUAL_HOST,
					)
				))
		);
	} // function

    public function sync($p_category_data, $p_object_id, $p_status) {
        assert('is_array($p_category_data) && count($p_category_data) > 0');
        assert('is_numeric($p_object_id) && $p_object_id >= 0');
        assert('is_numeric($p_status)');
        $this->m_sync_catg_data = $p_category_data;
        $l_indicator = FALSE;

        switch ($p_status) {
            case isys_import_handler_cmdb::C__CREATE:
                if (($p_category_data['data_id'] = $this->create(
										                    $p_object_id,
										                    C__RECORD_STATUS__NORMAL,
										                    $this->get_property('virtual_host'),
										                    $this->get_property('license_server'),
										                    $this->get_property('administration_service'),
										                    $this->get_property('description')))) {
                    $l_indicator = TRUE;
                }
                break;
            case isys_import_handler_cmdb::C__UPDATE:
                $l_indicator = $this->save(
                                        $p_category_data['data_id'],
                                        C__RECORD_STATUS__NORMAL,
                                        $this->get_property('virtual_host'),
                                        $this->get_property('license_server'),
                                        $this->get_property('administration_service'),
                                        $this->get_property('description'));
                break;
        }
        return ($l_indicator === TRUE) ? $p_category_data['data_id'] : FALSE;
    }


	/**
	 * Add new graphic adapter
	 *
	 * @param string $p_title
	 * @param string $p_manufacturer_id
	 * @param string $p_memory
	 * @param string $p_memory_unit_id
	 */
	public function create($p_object_id, $p_status, $p_virtual_host, $p_license_server, $p_administration_service, $p_description) {
		global $g_comp_database;

		$l_dao_con = new isys_cmdb_dao_connection($g_comp_database);

		$l_sql = "INSERT INTO isys_catg_virtual_host_list ".
					"SET ".
						"isys_catg_virtual_host_list__status = '".$p_status."', ".
						"isys_catg_virtual_host_list__virtual_host = '".$p_virtual_host."', ".
						"isys_catg_virtual_host_list__description = ".$this->convert_sql_text($p_description).", ".
						"isys_catg_virtual_host_list__isys_obj__id = '".$p_object_id."', ".
						"isys_catg_virtual_host_list__license_server = ".$this->convert_sql_id($l_dao_con->add_connection($p_license_server)).", ".
						"isys_catg_virtual_host_list__administration_service = ".$this->convert_sql_id($l_dao_con->add_connection($p_administration_service));

		if ($this->update($l_sql)) {
			if ($this->apply_update()) {
				$this->m_strLogbookSQL = $l_sql;

				return $this->m_db->get_last_insert_id();
			}
		}

		return false;
	}

	/**
	 * Updates an existing
	 *
	 * @param string $p_id
	 * @param string $p_title
	 * @param string $p_memory
	 * @param string $p_memory_unit_id
	 */
	public function save($p_id, $p_status, $p_virtual_host, $p_license_server, $p_administration_service, $p_description) {
		global $g_comp_database;

		$l_dao_connection = new isys_cmdb_dao_connection($this->m_db);

		if (is_numeric($p_id)) {

			$l_data = $this->get_data($p_id)->__to_array();



			if (!$l_data["isys_catg_virtual_host_list__license_server"]) {
				$l_licence_server			= $l_dao_connection->add_connection($p_license_server);
			} else {
				$l_licence_server = $l_data["isys_catg_virtual_host_list__license_server"];
				$l_dao_connection->update_connection($l_licence_server, $p_license_server);
			}

			if (!$l_data["isys_catg_virtual_host_list__license_server"]) {
				$l_administration_service	= $l_dao_connection->add_connection($p_administration_service);
			} else {
				$l_administration_service = $l_data["isys_catg_virtual_host_list__administration_service"];
				$l_dao_connection->update_connection($l_administration_service, $p_administration_service);
			}

			$l_sql = "UPDATE isys_catg_virtual_host_list ".
							"SET ".
								"isys_catg_virtual_host_list__status = '".$p_status."', ".
								"isys_catg_virtual_host_list__virtual_host = '".$p_virtual_host."', ".
								"isys_catg_virtual_host_list__description = ".$this->convert_sql_text($p_description).", ".
								"isys_catg_virtual_host_list__license_server = '".$l_licence_server."', ".
								"isys_catg_virtual_host_list__administration_service = '".$l_administration_service."' ".
						"WHERE ".
							"(isys_catg_virtual_host_list__id = '".$p_id."')".
						";";

			if ($this->update($l_sql)) {
				$this->m_strLogbookSQL = $l_sql;

				return $this->apply_update();
			}
		}

		return false;
	}

	/**
	* @param $p_cat_level
	* @author Van Quyen Hoang <dstuecken@i-doit.org>
	*/
	public function save_element(&$p_cat_level, &$p_status, $p_create = false) {
		$l_catdata = $this->get_general_data();

		if ($p_create && empty($l_catdata)) {

			/**
			 * Create a new virtual host entry
			 */
			$l_id = $this->create($_GET[C__CMDB__GET__OBJECT],
								  C__RECORD_STATUS__NORMAL,
								  $_POST["C__CATG__VIRTUAL_HOST__YES_NO"],
								  $_POST["C__CATG__VIRTUAL_HOST__LICENSE_SERVER__HIDDEN"],
								  $_POST["C__CATG__VIRTUAL_HOST__ADMINISTRATION_SERVICE__HIDDEN"],
								  $_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()]
								  );



			if ($l_id > 0) {
				$p_cat_level = 1;

				return $l_id;
			}

		} else {

			/**
			 * Save the virtual host
			 */
			if ($this->save($l_catdata["isys_catg_virtual_host_list__id"],
							$l_catdata["isys_catg_virtual_host_list__status"],
							$_POST["C__CATG__VIRTUAL_HOST__YES_NO"],
						    $_POST["C__CATG__VIRTUAL_HOST__LICENSE_SERVER__HIDDEN"],
						    $_POST["C__CATG__VIRTUAL_HOST__ADMINISTRATION_SERVICE__HIDDEN"],
							$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()]
							)) {

				$l_mod_event_manager = isys_event_manager::getInstance();

				if ($_GET[C__CMDB__GET__OBJECT]) {
					$l_selected		= explode(",", $_POST["objects"]);
					$l_dao_guests	= new isys_cmdb_dao_category_g_guest_systems($this->get_database_component());
					$l_guests		= $l_dao_guests->get_data(NULL, $_GET[C__CMDB__GET__OBJECT]);

					while ($l_row = $l_guests->get_row()) {
						$l_guest = $l_row["isys_catg_virtual_machine_list__isys_obj__id"];

						if ($l_guest > 0 && in_array($l_guest, $l_selected)) {
							/**
							 * Devirtualize actions
							 */
							if ($_POST["devirtualize_action"]) {
								switch ($_POST["devirtualize_action"]) {
									case 1:
										$l_status = C__RECORD_STATUS__DELETED;
										$l_strConstEvent = "C__LOGBOOK_EVENT__OBJECT_DELETED";
										break;
									case 2:
										$l_status = C__RECORD_STATUS__ARCHIVED;
										$l_strConstEvent = "C__LOGBOOK_EVENT__OBJECT_ARCHIVED";
										break;
								}

								/**
								 * Change object status
								 */
								if ($this->set_object_status($l_guest, $l_status)) {
									/**
									 * Trigger Logbook message
									 */
									$l_mod_event_manager->triggerCMDBEvent(	$l_strConstEvent,
																			$this->get_last_query(),
																			$l_guest,
																			$this->get_objTypeID($l_guest));
								}
							}
						}

						/**
						 * Detach guest system
						 * @todo implement a real detaching instead of overwriting everything with NULL..
						 */
						$l_dao_guests->save($l_row["isys_catg_virtual_machine_list__id"], C__RECORD_STATUS__NORMAL, NULL, NULL, NULL);

					}
				}


				return null;
			}
		}

		return false;
	}

} // class

?>
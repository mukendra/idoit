<?php

/**
 * i-doit
 *
 * CMDB DAO: global category for host addresses
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Dennis Stücken <dstucken@synetics.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
define('C__IP__ADDRESS', 1);
define('C__IP__SUBNET', 2);
define('C__IP__GATEWAY', 3);
define('C__IP__NET', 4);
define('C__IP__ASSIGNMENT', 5);
define('C__IP__IPV6_SCOPE', 6);
define('C__IP__IPV6_PREFIX', 7);

class isys_cmdb_dao_category_g_ip extends isys_cmdb_dao_category_global
{
	/**
	 * Category's name. Will be used for the identifier, constant, main table and many more.
	 * @var  string
	 */
	protected $m_category = 'ip';

	/**
	 * Is category multi-valued or single-valued?
	 * @var  boolean
	 */
	protected $m_multivalued = true;

	/**
	 * Return database field to be used as breadcrumb title
	 *
	 * @return string
	 */
	public function get_breadcrumb_field()
	{
		return 'isys_catg_ip_list__address';
	}

	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function properties ()
	{
		return array(
			'net_type' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__NETWORK__TYPE',
						C__PROPERTY__INFO__DESCRIPTION => 'Type'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_net_type__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_net_type',
							'isys_net_type__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__NET__TYPE',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_net_type',
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => C__CATS_NET_TYPE__IPV4
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					)
				)),
			'primary' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATG__CONTACT_LIST__PRIMARY',
						C__PROPERTY__INFO__DESCRIPTION => 'Primary'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__primary'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATP__IP__PRIMARY',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => serialize(get_smarty_arr_YES_NO()),
							'p_bDbFieldNN' => 1
						),
						// refs #4904
						C__PROPERTY__UI__DEFAULT => 1
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_yes_or_no'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false
					)
				)),
			'active' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__ACTIVE',
						C__PROPERTY__INFO__DESCRIPTION => 'Active'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__active'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATP__IP__ACTIVE',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => serialize(get_smarty_arr_YES_NO()),
							'p_bDbFieldNN' => 1
						),
						// refs #4904
						C__PROPERTY__UI__DEFAULT => 1
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_yes_or_no'
						)
					)
				)),
			'net' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET',
						C__PROPERTY__INFO__DESCRIPTION => 'Net'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_cats_net_ip_addresses_list__isys_obj__id'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__IP__NET',
						C__PROPERTY__UI__PARAMS => array(
							'typeFilter' => 'C__OBJTYPE__LAYER3_NET'
						),
						C__PROPERTY__UI__DEFAULT => C__OBJ__NET_GLOBAL_IPV4
					),
					C__PROPERTY__CHECK => array(
					),
					C__PROPERTY__CHECK => array(),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'object'
						)
					)
				)),
			'ipv4_assignment' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__ASSIGN_IPV4',
						C__PROPERTY__INFO__DESCRIPTION => 'Address allocation IPv4'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_ip_assignment__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_ip_assignment',
							'isys_ip_assignment__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATP__IP__ASSIGN',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_ip_assignment',
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => C__CATP__IP__ASSIGN__DHCP
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					)
				)),
			'ipv4_address' => array_replace_recursive(isys_cmdb_dao_category_pattern::text(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__IP__IPV4_ADDRESS',
						C__PROPERTY__INFO__DESCRIPTION => 'IPv4 address',
						C__PROPERTY__INFO__PRIMARY => true
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_cats_net_ip_addresses_list__id',
						C__PROPERTY__DATA__TABLE_ALIAS => 'ipv4',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_net_ip_addresses_list',
							'isys_cats_net_ip_addresses_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATP__IP__ADDRESS_V4',
						C__PROPERTY__UI__PARAMS => array(
							'type' => 'f_ip',
							//'p_strValue' =>
						)
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_ip_reference'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__REPORT => false
					)
				)),
			'ipv6_assignment' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__ASSIGN_IPV6',
						C__PROPERTY__INFO__DESCRIPTION => 'Address allocation IPv6'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_ipv6_assignment__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_ipv6_assignment',
							'isys_ipv6_assignment__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CATG__IP__IPV6_ASSIGNMENT',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_ipv6_assignment',
							'p_bDbFieldNN' => 1
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					)
				)),
			'ipv6_scope' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog_plus(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__IP__IPV6_SCOPE',
						C__PROPERTY__INFO__DESCRIPTION => 'IPv6 scope'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_ipv6_scope__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_ipv6_scope',
							'isys_ipv6_scope__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CATG__IP__IPV6_SCOPE',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_ipv6_scope'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					)
				)),
			'ipv6_address' => array_replace_recursive(isys_cmdb_dao_category_pattern::text(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__IP__IPV6_ADDRESS',
						C__PROPERTY__INFO__DESCRIPTION => 'IPv6 address',
						C__PROPERTY__INFO__PRIMARY => true
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_cats_net_ip_addresses_list__id',
						C__PROPERTY__DATA__TABLE_ALIAS => 'ipv6',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_net_ip_addresses_list',
							'isys_cats_net_ip_addresses_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CATG__IP__IPV6_ADDRESS'
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_ip_reference'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__REPORT => false
					)
				)),
			'hostaddress' => array_replace_recursive(isys_cmdb_dao_category_pattern::text(), array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CATG__IP_ADDRESS',
					C__PROPERTY__INFO__DESCRIPTION => 'Hostaddress',
					C__PROPERTY__INFO__PRIMARY => true
				),
				C__PROPERTY__DATA => array(
					C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_cats_net_ip_addresses_list__id',
					C__PROPERTY__DATA__REFERENCES => array(
						'isys_cats_net_ip_addresses_list',
						'isys_cats_net_ip_addresses_list__id'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => false,
					C__PROPERTY__PROVIDES__REPORT => true,
					C__PROPERTY__PROVIDES__MULTIEDIT => false,
					C__PROPERTY__PROVIDES__EXPORT => false,
					C__PROPERTY__PROVIDES__IMPORT => false,
					C__PROPERTY__PROVIDES__SEARCH => false,
					C__PROPERTY__PROVIDES__VALIDATION => false
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						'isys_export_helper',
						'get_ip_reference'
					)
				)
			)),
			'hostname' => array_replace_recursive(isys_cmdb_dao_category_pattern::text(), array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__HOSTNAME',
					C__PROPERTY__INFO__DESCRIPTION => 'Hostname'
				),
				C__PROPERTY__DATA => array(
					C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__hostname'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						'isys_export_helper',
						'hostname_handler'
					)
				),
				C__PROPERTY__UI => array(
					C__PROPERTY__UI__ID => 'C__CATP__IP__HOSTNAME'
				),
				C__PROPERTY__CHECK => array(
					C__PROPERTY__CHECK__SANITIZATION => array(
						FILTER_CALLBACK,
						array(
							'options' => array('isys_helper', 'strip_whitespaces')
						)
					)
				)
			)),
			'dns_server' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__DNSSERVER',
						C__PROPERTY__INFO__DESCRIPTION => 'DNS Server'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__id',
						C__PROPERTY__DATA__TABLE_ALIAS => 'dns',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_ip_list_2_isys_catg_ip_list',
							'isys_catg_ip_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__IP__ASSIGNED_DNS_SERVER',
						C__PROPERTY__UI__PARAMS => array(
							'groupFilter' => 'C__OBJTYPE_GROUP__INFRASTRUCTURE',
							'multiselection' => true, // @todo Property Callback for multiedit (in future).
							'secondSelection' => true,
							'secondList' => 'isys_cmdb_dao_category_g_ip::object_browser',
							'secondListFormat' => 'isys_cmdb_dao_category_g_ip::format_selection',
							'p_strSelectedID' => new isys_callback(array('isys_cmdb_dao_category_g_ip', 'callback_property_dns_server'))
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__SEARCH => false,
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_net_dns_server'
						)
					)
				)),
			'dns_domain' => array_replace_recursive(isys_cmdb_dao_category_pattern::multiselect(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATP__IP__DNSDOMAIN',
						C__PROPERTY__INFO__DESCRIPTION => 'DNS Domain'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__id',
						C__PROPERTY__DATA__TABLE_ALIAS => 'dns_domain',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_ip_list_2_isys_net_dns_domain',
							'isys_catg_ip_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATP__IP__DNS_DOMAIN',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_net_dns_domain'
						),
						C__PROPERTY__UI__DEFAULT => null
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__VALIDATION => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'dialog_multiselect'
						)
					)
				)),
			'use_standard_gateway' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATG__IP__DEFAULT_GATEWAY_FOR_THE_NET',
						C__PROPERTY__INFO__DESCRIPTION => 'Default gateway for the net'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__id',
						C__PROPERTY__DATA__TABLE_ALIAS => 'gateway',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_net_list_2_isys_catg_ip_list',
							'isys_catg_ip_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__IP__GW__CHECK',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => serialize(get_smarty_arr_YES_NO()),
							'p_strSelectedID' => new isys_callback(array('isys_cmdb_dao_category_g_ip', 'callback_property_use_standard_gateway')),
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => 0
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__IMPORT => false,
						C__PROPERTY__PROVIDES__SEARCH => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_yes_or_no'
						)
					)
				)),
			'assigned_port' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATG__IP__ASSIGNED_PORT',
						C__PROPERTY__INFO__DESCRIPTION => 'Assigned port'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_catg_port_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_port_list',
							'isys_catg_port_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__IP__ASSIGNED_PORTS',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_ip', 'callback_property_ports')),
							'p_bLinklist' => 1
						)
					),
					C__PROPERTY__CHECK => array(
						C__PROPERTY__CHECK__VALIDATION => array(
							FILTER_CALLBACK,
							array(
								'options' => array('isys_helper', 'filter_combined_dialog')
							)
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_reference_value'
						)
					)
				)),
			'assigned_logical_port' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATG__IP__ASSIGNED_PORT',
						C__PROPERTY__INFO__DESCRIPTION => 'Assigned port'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__isys_catg_log_port_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_log_port_list',
							'isys_catg_log_port_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__IP__ASSIGNED_PORTS',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_ip', 'callback_property_ports')),
							'p_bLinklist' => 1
						)
					),
					C__PROPERTY__CHECK => array(
						C__PROPERTY__CHECK__VALIDATION => array(
							FILTER_CALLBACK,
							array(
								'options' => array('isys_helper', 'filter_combined_dialog')
							)
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_reference_value'
						)
					)
				)),
			'description' => array_replace_recursive(isys_cmdb_dao_category_pattern::commentary(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Categories description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_ip_list__description',
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__IP
					)
				))
		);
	} // function


	/**
	 * Method for retrieving the dynamic properties, used by the new list component.
	 *
	 * @return  array
	 */
	protected function dynamic_properties ()
	{
		return array(
			'_primary_ip' => array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CATG__IP__PRIMARY_ADDRESS',
					C__PROPERTY__INFO__DESCRIPTION => 'Primary IP address'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						$this,
						'dynamic_property_callback_primary_ip'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true
				)
			),
			'_net' => array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET',
					C__PROPERTY__INFO__DESCRIPTION => 'Net'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						$this,
						'dynamic_property_callback_net'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true
				)
			)
		);
	} // function


	/**
	 * Dynamic property handling for getting the primary IP of an object.
	 *
	 * @param   array  $p_row
	 * @return  string
	 */
	public function dynamic_property_callback_primary_ip ($p_row)
	{
		global $g_comp_database;
		$l_ip = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_ip', $g_comp_database)
			->get_data(null, $p_row['isys_obj__id'], "AND isys_catg_ip_list__primary = 1")
			->get_row();

		return $l_ip['isys_cats_net_ip_addresses_list__title'];
	} // function


	/**
	 * Dynamic property handling for displaying the layer3 net of the primary hostaddress (or the first found).
	 *
	 * @param   array  $p_row
	 * @return  string
	 */
	public function dynamic_property_callback_net ($p_row)
	{
		global $g_comp_database;

		$l_dao = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', $g_comp_database);

		$l_sql = 'SELECT isys_cats_net_ip_addresses_list__isys_obj__id FROM isys_catg_ip_list
			LEFT JOIN isys_cats_net_ip_addresses_list ON isys_cats_net_ip_addresses_list__id = isys_catg_ip_list__isys_cats_net_ip_addresses_list__id
			WHERE isys_catg_ip_list__isys_obj__id = ' . $l_dao->convert_sql_id($p_row['isys_obj__id']) . '
			ORDER BY isys_catg_ip_list__primary DESC;';

		$l_obj_id = $l_dao->retrieve($l_sql)->get_row_value('isys_cats_net_ip_addresses_list__isys_obj__id');

		if ($l_obj_id !== null)
		{
			$l_l3_row = $l_dao->get_object($l_obj_id, true)->get_row();
			$l_quick_info = new isys_ajax_handler_quick_info();

			return $l_quick_info->get_quick_info(
				$l_l3_row["isys_obj__id"],
				_L($l_l3_row['isys_obj_type__title']) . ' >> ' . $l_l3_row['isys_obj__title'],
				C__LINK__OBJECT
			);
		} // if

		return C__GUI_VALUE__NA;
	} // function

	public function callback_property_use_standard_gateway(isys_request $p_request)
	{
		$l_catdata = $p_request->get_row();
		$l_net_row = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net', $this->get_database_component())
			->get_all_net_information_by_obj_id($l_catdata['isys_cats_net_ip_addresses_list__isys_obj__id']);

		return ((!empty($l_net_row['isys_cats_net_list__isys_catg_ip_list__id']) && is_array($l_catdata) && $l_net_row['isys_cats_net_list__isys_catg_ip_list__id'] == $l_catdata['isys_catg_ip_list__id']) ? 1 : 0);
	} // function

	/**
	 * Callback method for dns server
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @param   isys_request  $p_request
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function callback_property_dns_server(isys_request $p_request)
	{
		$l_return = array();

		$l_row = $p_request->get_row();
		if(isset($l_row['isys_catg_ip_list__id']))
		{
			$l_return = $this->get_assigned_dns_server($l_row['isys_catg_ip_list__id']);
		} // if
		return $l_return;
	} // function

	/**
	 * Callback method for the ports dialog-field.
	 *
	 * @param   isys_request  $p_request
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function callback_property_ports(isys_request $p_request)
	{
		$l_obj_id = $p_request->get_object_id();

		$l_return = array();
		$l_dao_port = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_network_port', $this->get_database_component());
		$l_dao_log_port = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_network_ifacel', $this->get_database_component());

		$l_res_port = $l_dao_port->get_data(null, $l_obj_id, '', null, C__RECORD_STATUS__NORMAL);
		$l_res_log_port = $l_dao_log_port->get_data(NULL, $l_obj_id, '', NULL, C__RECORD_STATUS__NORMAL);

		// We retrieve the language string once, instead of in every iteration!
		$l_port = _L('LC__CMDB__CATG__NETWORK_TREE_CONFIG_PORTS');
		$l_log_port = _L('LC__CMDB__CATG__NETWORK_TREE_CONFIG_PORT_L');

		while($l_row = $l_res_port->get_row())
		{
			$l_return[$l_port][$l_row['isys_catg_port_list__id'].'_C__CMDB__SUBCAT__NETWORK_PORT'] = $l_row['isys_catg_port_list__title'];
		} // while

		while($l_row = $l_res_log_port->get_row())
		{
			$l_return[$l_log_port][$l_row['isys_catg_log_port_list__id'].'_C__CMDB__SUBCAT__NETWORK_INTERFACE_L'] = $l_row['isys_catg_log_port_list__title'];
		} // while

		return $l_return;
	} // function



	/**
	 * Callback method for the "catdata" browser. Maybe we can switch the first parameter to an instance of isys_request?
	 *
	 * @param   integer  $p_obj_id
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function catdata_browser($p_obj_id)
	{
		$l_return = array();
		$l_res = $this->get_data(NULL, $p_obj_id, "", null, C__RECORD_STATUS__NORMAL);

		while ($l_row = $l_res->get_row())
		{
			$l_val = $l_row['isys_cats_net_ip_addresses_list__title'];

			if (! empty($l_row['isys_catg_ip_list__hostname']))
			{
				$l_val .= ' (' . $l_row['isys_catg_ip_list__hostname'] . ')';
			} // if

			$l_return[$l_row['isys_catg_ip_list__id']] = $l_val;
		} // while

		return $l_return;
	} // function

	/**
	 * Synchronizes properties from an import with the database.
	 *
	 * @param   array    $p_category_data  Values of category data to be saved.
	 * @param   integer  $p_object_id      Current object identifier (from database)
	 * @param   integer  $p_status         Decision whether category data should be created or just updated.
	 * @return  mixed  Returns category data identifier (int) on success, true (bool) if nothing had to be done, otherwise false.
	 */
	public function sync($p_category_data, $p_object_id, $p_status)
	{
		assert('is_array($p_category_data) && count($p_category_data) > 0');
		assert('is_numeric($p_object_id) && $p_object_id >= 0');
		assert('is_numeric($p_status)');

		$this->m_sync_catg_data = $p_category_data;
		$l_indicator = false;

		if (!$this->import_validation())
		{
			return false;
		} // if

        $l_net_obj = $this->get_property('net');
		$l_ip_assignment = $this->get_property('ipv4_assignment');

		switch ($this->get_property('net_type'))
		{
			case C__CATS_NET_TYPE__IPV6:
				$l_address = $this->get_property('ipv6_address');
				$l_net_type = C__CATS_NET_TYPE__IPV6;
				if (empty($l_net_obj))
				{
					$l_net_obj = C__OBJ__NET_GLOBAL_IPV6;
				} // if
				break;
			case C__CATS_NET_TYPE__IPV4:
			default:
				$l_address = $this->get_property('ipv4_address');
				$l_net_type = C__CATS_NET_TYPE__IPV4;
				if (empty($l_net_obj))
				{
					$l_net_obj = C__OBJ__NET_GLOBAL_IPV4;
				} // if
				break;
		} // switch

		if ($l_address != '' && $l_net_obj > 0)
		{
			if ($this->ip_already_in_use($l_net_obj, $l_address, $p_object_id) &&
				$l_net_obj != C__OBJ__NET_GLOBAL_IPV4 &&
				$l_net_obj != C__OBJ__NET_GLOBAL_IPV6 &&
				isys_settings::get('cmdb.unique.ip-address'))
			{
				if(isys_import_handler_cmdb::get_overwrite_ip_conflicts())
				{
					// reassign local hostaddress to global net
					$this->reassign_ip($p_object_id, $l_address, $l_net_type, (($l_net_type == C__CATS_NET_TYPE__IPV4)? C__OBJ__NET_GLOBAL_IPV4: C__OBJ__NET_GLOBAL_IPV6));
				}
				else
				{
					if ($l_net_type == C__CATS_NET_TYPE__IPV4)
					{
						$l_address = $this->get_free_ip($l_net_obj, $l_ip_assignment);
					}
					else if ($l_net_type == C__CATS_NET_TYPE__IPV6)
					{
						$l_address = $this->get_free_ipv6($l_net_obj);
					} // if
				} // if
			} // if
		} // if

        /* API-Problem */
        if (!strpos($l_address, '.') && !strpos($l_address, '.') && is_numeric($l_address) && $p_status == isys_import_handler_cmdb::C__UPDATE) {
            $l_row = $this->get_ip_by_id($p_category_data['data_id']);
            $l_address = $l_row['isys_cats_net_ip_addresses_list__title'];
        }

		switch ($p_status) {
			case isys_import_handler_cmdb::C__CREATE:
				$p_category_data['data_id'] = $this->create(
					$p_object_id,
                    $this->get_property('hostname'),
                    $l_ip_assignment,
                    $l_address,
                    $this->get_property('primary'),
                    $this->get_property('use_standard_gateway'),
                    $this->get_property('dns_server'),
                    $this->get_property('dns_domain'),
                    $this->get_property('active'),
                    $this->get_property('net_type'),
                    $l_net_obj,
                    $this->get_property('description'),
                    C__RECORD_STATUS__NORMAL,
                    $this->get_property('assigned_port'),
                    $this->get_property('assigned_logical_port'),
                    $this->get_property('ipv6_scope'),
                    $this->get_property('ipv6_assignment')
				);

				if ($p_category_data['data_id']) {
					$l_indicator = true;
				}
				break;

			case isys_import_handler_cmdb::C__UPDATE:
				$l_indicator = $this->save(
					$p_category_data['data_id'],
                    $this->get_property('hostname'),
                    $l_ip_assignment,
                    $l_address,
                    $this->get_property('primary'),
                    $this->get_property('use_standard_gateway'),
                    $this->get_property('dns_server'),
                    $this->get_property('dns_domain'),
                    $this->get_property('active'),
                    $this->get_property('net_type'),
                    $l_net_obj,
                    $this->get_property('description'),
                    C__RECORD_STATUS__NORMAL,
                    $this->get_property('assigned_port'),
                    $this->get_property('assigned_logical_port'),
                    $this->get_property('ipv6_assignment'),
                    $this->get_property('ipv6_scope')
                );
				break;
		}

		return ($l_indicator === true) ? $p_category_data['data_id'] : true;
	}

    /**
     * Compares category data for import.
     *
     * @todo Currently, every transformation (using helper methods) are skipped.
     * If your unique properties needs them, implement it!
     *
     * @param type $p_category_data_values
     * @param type $p_object_category_dataset
     * @param type $p_comparison
     * @param int $p_badness
     * @param type $p_mode
     * @param type $p_category_id
     * @param type $p_unit_key
     * @param type $p_category_data_ids
     * @param type $p_local_export
     * @param type $p_dataset_id_changed
     * @param type $p_dataset_id
     * @param type $p_category_name
     * @param type $p_table
     * @param type $p_cat_multi
     */
    public function compare_category_data(
        &$p_category_data_values,
        &$p_object_category_dataset,
        &$p_used_properties,
        &$p_comparison,
        &$p_badness,
        &$p_mode,
        &$p_category_id,
        &$p_unit_key,
        &$p_category_data_ids,
        &$p_local_export,
        &$p_dataset_id_changed,
        &$p_dataset_id,
        &$p_logger,
        &$p_category_name = null,
        &$p_table = null,
        &$p_cat_multi = null,
		&$p_category_type_id = null,
		&$p_category_ids = null,
		&$p_object_ids = null
    ) {

        if (!empty($p_category_data_values['properties']['assigned_port']['id']))
            $p_category_data_values['properties']['assigned_port']['value'] = $p_category_data_values['properties']['assigned_port']['id'];

        if (!empty($p_category_data_values['properties']['assigned_logical_port']['id']))
            $p_category_data_values['properties']['assigned_logical_port']['value'] = $p_category_data_values['properties']['assigned_logical_port']['id'];

		$l_helper_arr = array();
		$l_objects_setted = false;
		$l_prop_data_setted = false;
		$l_cat_ids_setted = false;
		$l_cat_data_ids_setted = false;
		$l_set_mode_setted = false;

        // Iterate through local data sets:
        foreach ($p_object_category_dataset as $l_dataset_key => $l_dataset) {
            $p_dataset_id_changed = false;
            $p_dataset_id = $l_dataset[$p_table . '__id'];

            $p_logger->debug(
                sprintf('Handle dataset %s.', $p_dataset_id)
            );

            // Test the category data identifier:
            if ($p_mode === isys_import_handler_cmdb::C__USE_IDS &&
                $p_category_data_values['data_id'] !== $p_dataset_id)
            {
                $p_logger->debug('Category data identifier is different.');
                $p_badness[$p_dataset_id]++;
                $p_dataset_id_changed = true;

                if ($p_mode === isys_import_handler_cmdb::C__USE_IDS)
                {
                    continue;
                } //if
            } //if

			if($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES]['net_type']['id'] == C__CATS_NET_TYPE__IPV4)
			{
				$l_import_ip = $p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES]['ipv4_address']['ref_title'];
				$l_ingore_category_keys = array(
					'ipv6_assignment',
					'ipv6_address',
					'ipv6_scope'
				);
			}
			else
			{
				$l_import_ip = $p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES]['ipv6_address']['ref_title'];
				$l_ingore_category_keys = array(
					'ipv4_assignment',
					'ipv4_address',
				);
			}

			if($l_dataset['isys_cats_net_ip_addresses_list__title'] == $l_import_ip)
			{
				// ip found check other properties
				if($p_dataset_id == $l_dataset['isys_catg_ip_list__id'])
				{
					$p_category_data_values['data_id'] = $p_dataset_id;
				}
				else
				{
					$p_badness[$p_dataset_id] = isys_import_handler_cmdb::C__COMPARISON__THRESHOLD+1;
				}
			}

            // Test each property:
			foreach ($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES] as $l_key => $l_value)
            {
				if(in_array($l_key, $l_ingore_category_keys))
				{
					unset($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key]);
					continue;
				}

				$l_local = NULL;

				// Need to unconvert:
				if (isset($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]) &&
					isset($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1])
				)
				{

					if (!class_exists($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]))
					{
						throw new isys_exception_cmdb(
							sprintf(
								'Import failed. Helping class %s for importing data is not available.',
								$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]
							)
						);
					} //if

					if (!array_key_exists($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0], $l_helper_arr))
					{
						$l_helper = new $p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0](
							$l_dataset,
							$this->m_db,
							$p_used_properties[$l_key][C__PROPERTY__DATA],
							$p_used_properties[$l_key][C__PROPERTY__FORMAT],
							$p_used_properties[$l_key][C__PROPERTY__UI]);
						$l_helper_arr[$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]] = $l_helper;
						$l_objects_setted = false;
						$l_prop_data_setted = false;
						$l_cat_ids_setted = false;
						$l_cat_data_ids_setted = false;
						$l_set_mode_setted = false;
					}
					else
					{
						$l_helper = $l_helper_arr[$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]];
						$l_helper->set_row($l_dataset);
						$l_helper->set_database($this->m_db);
						$l_helper->set_reference_info($p_used_properties[$l_key][C__PROPERTY__DATA]);
						$l_helper->set_format_info($p_used_properties[$l_key][C__PROPERTY__FORMAT]);
						$l_helper->set_ui_info($p_used_properties[$l_key][C__PROPERTY__UI]);
					}

					if (!empty($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__UNIT]))
					{
						$l_unit_key = $p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__UNIT];

						if (method_exists($l_helper, 'set_unit_const'))
						{
							$l_helper->set_unit_const($p_used_properties[isys_import_handler_cmdb::C__PROPERTIES][$l_unit_key]['const']);
						} // if
					} // if

					if (method_exists($l_helper, 'set_object_ids') && !$l_objects_setted)
					{
						$l_helper->set_object_ids($p_object_ids);
						$l_objects_setted = true;
					} //if

					if (method_exists($l_helper, 'set_property_data') && !$l_prop_data_setted)
					{
						$l_helper->set_property_data($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES]);
						$l_prop_data_setted = true;
					} //if

					if (method_exists($l_helper, 'set_category_ids') && !$l_cat_ids_setted)
					{
						$l_helper->set_category_ids($p_category_ids);
						$l_cat_ids_setted = true;
					} //if

					if (method_exists($l_helper, 'set_category_data_ids') && !$l_cat_data_ids_setted)
					{
						$l_helper->set_category_data_ids($p_category_data_ids);
						$l_cat_data_ids_setted = true;
					} //if

					if (method_exists($l_helper, 'set_mode') && !$l_set_mode_setted)
					{
						$l_helper->set_mode($p_mode);
						$l_set_mode_setted = true;
					} //if

					$l_helper_method = $p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] . '_import';

					if (!method_exists($l_helper, $l_helper_method))
					{
						$p_logger->warning(
							 sprintf(
								 'Helping method %s for importing data is not available. Method was expected in class %s.',
								 $l_helper_method,
								 $p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]
							 )
						);

						if (isset($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key]['sysid']))
						{
							// Object reference:
							$p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE] = $p_object_ids[$p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key]['id']];
							$p_logger->info('It is an object reference.');
						} else
						{
							// Category reference:
							$l_id_set   = false;
							$l_type_set = false;
							if (is_array($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE]))
							{
								foreach ($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE] as $l_key2 => $l_val)
								{
									if (is_array($l_val))
									{
										foreach ($l_val as $l_key3 => $l_val2)
										{
											if ($l_key3 === 'id')
											{
												$l_id_set = $l_val2;
											} // if

											if ($l_key3 === 'type')
											{
												$l_type_set = $l_val2;
											} // if
										} // foreach
									} else
									{
										if ($l_key2 === 'id')
										{
											$l_id_set = $l_val;
										} // if

										if ($l_key2 === 'type')
										{
											$l_type_set = $l_val;
										} // if
									} // if

									if ($l_id_set && $l_type_set)
									{
										break;
									} // if
								} // foreach
							} // if
							else
							{
								foreach ($p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key] AS $l_key2 => $l_val)
								{
									if ($l_key2 === 'id')
									{
										$l_id_set = $l_val;
									} // if

									if ($l_key2 === 'type')
									{
										$l_type_set = $l_val;
									} // if

									if ($l_id_set && $l_type_set)
									{
										break;
									} // if
								} // foreach
							} // if

							if ($l_id_set && $l_type_set)
							{
								if (!is_numeric($l_type_set))
								{
									$l_type_set = constant($l_type_set);
								} // if

								if (isset($l_category_data_ids[$p_category_type_id][$l_type_set][$l_id_set]))
								{
									$p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE] = $l_category_data_ids[$p_category_type_id][$l_type_set][$l_id_set];
									$p_logger->info('It is a category reference.');
								} else
								{
									$p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE] = NULL;
								} // if
							} // if
						} // if
					} else
					{

						if (isset($p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD_ALIAS]))
							$l_property_field = $p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD_ALIAS];
						else $l_property_field = $p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD];

						// Initiate helper class:
						if (!class_exists($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]))
						{
							$p_logger->debug(
								sprintf(
									'Export helper class does not exist: %s. Skipping.',
									$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]
								)
							);
							continue;
						} // if

						if ($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] == 'connection')
							$l_local = $l_dataset['isys_connection__isys_obj__id'];
						else $l_local = $l_dataset[$l_property_field];

						$l_import = $p_category_data_values['properties'][$l_key][C__DATA__VALUE];

						// Initiate variables to save original unconcerted values:
						$l_import_unconverted = NULL;
						$l_local_unconverted  = NULL;

						// If values has been converted, convert the local value to the right unit:
						if (isset($p_category_data_values['properties'][$l_key][C__DATA__VALUE . '_converted']))
						{
							$l_import_unconverted = $l_import;
							$l_local_unconverted  = $l_helper->$l_helper_method(
								array(
									C__DATA__VALUE => $l_local,
									C__DATA__TAG   => $l_key
								)
							);
							$l_import             = $p_category_data_values['properties'][$l_key][C__DATA__VALUE . '_converted'];
						} else
						{
							if (isset($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1]))
							{
								$l_import = $l_helper->$l_helper_method($l_value);

								// If data can only be retrieved by callback then we have to get the local data by the callback method
								// @todo find a better solution for this
								if ($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] != 'connection' &&
									$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] != 'get_yes_or_no'
								)
								{

									if ($p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0] != 'isys_nagios_service')
									{
										$p_local_export = $l_helper->$p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1]($l_local);
									}
									if (isset($p_local_export))
									{
										$l_local_export_data = NULL;
										if (is_object($p_local_export))
										{
											$l_local_export_data = $p_local_export->get_data();
										} else
										{
											$l_local_export_data = $p_local_export;
										}
										if (count($l_local_export_data) > 0)
										{
											if (is_array($l_local_export_data[0]))
											{
												$l_local_export_data = $l_local_export_data[0];
											}
											if (is_array($l_local_export_data))
											{
												if (isset($l_local_export_data['ref_id']))
												{
													if ($p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] == 'get_ip_reference')
														$l_local = $l_local_export_data['ref_title'];
													else $l_local = $l_local_export_data['ref_id'];
												} else
												{
													$l_local = $l_local_export_data['id'];
												}
											}
										}
									}
									else
									{
										$p_badness[$p_dataset_id]++;
									}

									unset($p_local_export);
								}

								if ($l_import === false)
								{
									$p_logger->warning(
											 sprintf(
												 'Transformation failed (method %s from class %s in category %s).',
												 $l_helper_method,
												 $p_used_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0],
												 $p_category_name
											 )
									);
								} // if

								$p_category_data_values['properties'][$l_key][C__DATA__VALUE] = $l_import;
							} // if
						} // if converted

						if (gettype($l_import) != 'array')
						{
							$l_local_check  = trim((string) $l_local);
							$l_import_check = trim((string) $l_import);

							// Check only if local value is set or import value
							if ((!empty($l_local_check) || !empty($l_import_check)) && $l_local != $l_import)
							{
								$p_logger->debug(
									sprintf(
										'Property %s is different.',
										$l_key
									)
								);
								$p_badness[$p_dataset_id]++;
							}
						}

						unset(
							$l_helper,
							$l_import_unconverted,
							$l_local_unconverted
						);
					} // if
				} else
				{
					// Check normal fields for badness points
					$l_import = $p_category_data_values[isys_import_handler_cmdb::C__PROPERTIES][$l_key][C__DATA__VALUE];
					if (isset($p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD_ALIAS]))
					{
						if (array_key_exists($p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD_ALIAS], $l_dataset))
							$l_local = $l_dataset[$p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD_ALIAS]];
					} else
					{
						$l_local = $l_dataset[$p_used_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD]];
					}

					if ($l_local != $l_import)
					{
						$p_logger->debug(
							sprintf(
								'Property %s is different.',
								$l_key
							)
						);

						$p_badness[$p_dataset_id]++;
					}
				} // if
            } // foreach
				//$l_found = false;


            if ($p_badness[$p_dataset_id] > isys_import_handler_cmdb::C__COMPARISON__THRESHOLD)
            {
                $p_logger->debug(
                    'Dataset differs completly from category data.'
                );
                $p_comparison[isys_import_handler_cmdb::C__COMPARISON__DIFFERENT][$l_dataset_key] = $p_dataset_id;
            }
            // @todo check badness again
            else if ($p_badness[$p_dataset_id] == 0 /*|| ($p_dataset_id_changed && $p_badness[$p_dataset_id] == 1)*/)
            {
                $p_logger->debug(
                    'Dataset and category data are the same.'
                );
                $p_comparison[isys_import_handler_cmdb::C__COMPARISON__SAME][$l_dataset_key] = $p_dataset_id;
            }
            else
            {
                $p_logger->debug(
                    'Dataset differs partly from category data.'
                );
                $p_comparison[isys_import_handler_cmdb::C__COMPARISON__PARTLY][$l_dataset_key] = $p_dataset_id;
            } //if
        } //foreach data set
    } //function


	/**
	 * Save method.
	 *
	 * @param   integer  $p_id
	 * @param   string   $p_hostname
	 * @param   integer  $p_assign
	 * @param   string   $p_address
	 * @param   integer  $p_primary
	 * @param   string   $p_gw
	 * @param   array    $p_dns_server
	 * @param   array    $p_dns_domain
	 * @param   integer  $p_active
	 * @param   integer  $p_net_type
	 * @param   integer  $p_net_connection
	 * @param   string   $p_description
	 * @param   integer  $p_status
	 * @param   integer  $p_port_assignment
	 * @param   integer  $p_log_port_assignment
	 * @param   integer  $p_ipv6_assignment
	 * @param   integer  $p_ipv6_scope
	 * @author  Dennis Stücken<dstuecken@synetics.de>
	 * @author  Van Quyen Hoang<qhoang@synetics.de>
	 * @return  boolean
	 */
	public function save($p_id, $p_hostname, $p_assign, $p_address, $p_primary, $p_gw, $p_dns_server, $p_dns_domain, $p_active, $p_net_type, $p_net_connection, $p_description, $p_status = C__RECORD_STATUS__NORMAL, $p_port_assignment = NULL, $p_log_port_assignment = NULL, $p_ipv6_assignment = null, $p_ipv6_scope = null)
	{
		$l_dao_ip_address = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_ip_addresses', $this->get_database_component());

        $l_data = $this->get_data($p_id)->__to_array();

		if (!$p_assign)
		{
			$p_assign = C__CATP__IP__ASSIGN__STATIC;
		}

		$l_catg = "isys_catg_ip";

		$l_new_ip = true;

		if (empty($p_dns_server) || $p_dns_server < 0)
		{
			$p_dns_server = null;
		} // if

		if (empty($p_dns_domain))
		{
			$p_dns_domain = null;
		} // if

		if ($l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'] > 0)
		{
			$l_net_connection = $l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'];
			$l_ip_address_data = $l_dao_ip_address->get_data($l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'])->get_row();

			$l_new_ip = false;

			if ($l_ip_address_data['isys_cats_net_ip_addresses_list__title'] != $p_address || $l_ip_address_data['isys_cats_net_ip_addresses_list__isys_obj__id'] != $p_net_connection)
			{
				$l_dao_ip_address->save(
					$l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'],
					$p_address,
					$p_net_connection,
					$l_ip_address_data['isys_cats_net_ip_addresses_list__isys_ip_assignment__id'],
					$l_ip_address_data['isys_cats_net_ip_addresses_list__status']);
			} // if
		}
		else
		{
			$l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'] = $l_dao_ip_address->create(
				$p_address,
				$p_net_connection,
				$p_assign);
		} // if

		$l_content = array(
			"hostname" => $p_hostname,
			"primary" => $p_primary,
			"active" => $p_active,
			"description" => $p_description,
			"isys_net_type__id" => $p_net_type,
			"isys_cats_net_ip_addresses_list__id" => $l_data['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'],
			"status" => $p_status,
			"isys_catg_port_list__id" => $p_port_assignment,
			"isys_catg_log_port_list__id" => $p_log_port_assignment,
		);

		switch($p_net_type){
			case C__CATS_NET_TYPE__IPV4:
				$l_content['isys_ip_assignment__id'] = $p_assign;
				break;
			case C__CATS_NET_TYPE__IPV6:
				$l_content['isys_ipv6_assignment__id'] = $p_ipv6_assignment;
				$l_content['isys_ipv6_scope__id'] = $p_ipv6_scope;
		}

		if (is_numeric($p_id))
		{
			if ($p_primary == 1)
			{
				$this->update_primary_hostaddress($p_id);
			} // if

			$l_sql = $this->build_query($l_catg . "_list", $l_content, $p_id);

			// Create implicit relation.
			$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());

			$l_data = $this->get_data($p_id)->__to_array();

			if ($this->update($l_sql) && $this->apply_update())
			{
				if ($l_new_ip)
				{
					$l_net_connection = $l_dao_ip_address->create(
						$p_address,
						$p_net_connection,
						$p_assign,
						C__RECORD_STATUS__NORMAL,
						$l_net_connection);
				} // if

				// Add DNS server.
				$this->clear_dns_server_attachments($p_id);
				if (is_array($p_dns_server) && count($p_dns_server) > 0)
				{
					foreach ($p_dns_server as $l_dns_id)
					{
						$this->attach_dns_server($p_id, $l_dns_id);
					} // foreach
				} // if

				// Add DNS domain.
				$this->clear_dns_domain_attachments($p_id);
				if (is_array($p_dns_domain) && count($p_dns_domain) > 0)
				{
					foreach ($p_dns_domain as $l_domain_id)
					{
						$this->attach_dns_domain($p_id, $l_domain_id);
					} // foreach
				} // if

				if ($p_gw > 0)
				{
					$this->attach_gateway(null, $p_net_connection, $p_id);
				} else{
					$this->attach_gateway(null, $p_net_connection, null);
				}

				$l_relation_dao->handle_relation(
					$p_id, "isys_catg_ip_list",
					C__RELATION_TYPE__IP_ADDRESS,
					$l_data["isys_catg_ip_list__isys_catg_relation_list__id"],
					$p_net_connection,
					$l_data["isys_catg_ip_list__isys_obj__id"]);

				return true;
			} // if
		} // if

		return false;
	} // function


	/**
	 * Create method.
	 *
	 * @param   integer  $p_object_id
	 * @param   string   $p_hostname
	 * @param   integer  $p_assign
	 * @param   string   $p_address
	 * @param   integer  $p_primary
	 * @param   integer  $p_gw
	 * @param   array    $p_dns_server
	 * @param   array    $p_dns_domain
	 * @param   integer  $p_active
	 * @param   integer  $p_net_type
	 * @param   integer  $p_net_connection
	 * @param   string   $p_description
	 * @param   integer  $p_status
	 * @param   integer  $p_port_assignment
	 * @param   integer  $p_log_port_assignment
	 * @param   integer  $p_ipv6_scope
     * @param   integer  $p_ip6_assignment
	 * @return  boolean
	 * @author  Dennis Stücken <dstuecken@synetics.de>
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 */
	public function create($p_object_id, $p_hostname, $p_ip_assignment, $p_address, $p_primary, $p_gw, $p_dns_server, $p_dns_domain, $p_active, $p_net_type, $p_net_connection, $p_description, $p_status = C__RECORD_STATUS__NORMAL, $p_port_assignment = NULL, $p_log_port_assignment = NULL, $p_ipv6_scope = NULL, $p_ip6_assignment = NULL)
	{
		$l_dao_ip_address = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_ip_addresses', $this->get_database_component());

		if (!$p_ip_assignment)
		{
			$p_ip_assignment = C__CATP__IP__ASSIGN__STATIC;
		}

		$l_last_net_list_id = $l_dao_ip_address->create(
			$p_address,
			((!empty($p_net_connection)) ? $p_net_connection : (($p_net_type == C__CATS_NET_TYPE__IPV4) ? C__OBJ__NET_GLOBAL_IPV4 : C__OBJ__NET_GLOBAL_IPV6)),
			$p_ip_assignment,
			C__RECORD_STATUS__NORMAL);

		$l_content = array(
			"isys_obj__id"                        => $p_object_id,
			"hostname"                            => $p_hostname,
			"isys_net_type__id"                   => $p_net_type,
			"primary"                             => $p_primary,
			"active"                              => $p_active,
			"description"                         => $p_description,
			"isys_cats_net_ip_addresses_list__id" => $l_last_net_list_id,
			"status"                              => $p_status,
			"isys_catg_port_list__id"             => $p_port_assignment,
			"isys_catg_log_port_list__id"         => $p_log_port_assignment,
		);

		switch ($p_net_type)
		{
			case C__CATS_NET_TYPE__IPV4:
				$l_content['isys_ip_assignment__id'] = $p_ip_assignment;
				break;
			case C__CATS_NET_TYPE__IPV6:
				$l_content['isys_ipv6_assignment__id'] = $p_ip6_assignment;
				$l_content['isys_ipv6_scope__id']      = $p_ipv6_scope;
		}

		if (is_numeric($p_object_id))
		{
			$l_sql = $this->build_query("isys_catg_ip_list", $l_content, NULL, C__DB_GENERAL__INSERT);

			if ($this->update($l_sql) && $this->apply_update())
			{
				$l_last_id = $this->get_last_insert_id();

				// When the new host address is saved as primary, we have to set all the others to "not-primary".
				if ($p_primary == 1)
				{
					$this->update_primary_hostaddress($l_last_id);
				} // if

				if (!empty($p_dns_server))
				{
					if (count($p_dns_server) > 0)
					{
						foreach ($p_dns_server AS $l_dns_id)
						{
							$this->attach_dns_server($l_last_id, $l_dns_id);
						} // foreach
					} // if
				} // if

				if (!empty($p_dns_domain))
				{
					if (count($p_dns_domain) > 0)
					{
						foreach ($p_dns_domain AS $l_domain_id)
						{
							$this->attach_dns_domain($l_last_id, $l_domain_id);
						} // foreach
					} // if
				} // if

				if ($p_gw > 0)
				{
					$this->attach_gateway(NULL, $p_net_connection, $l_last_id);
				} // if

				// Create implicit relation.
				$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());
				$l_relation_dao->handle_relation(
					$l_last_id,
					"isys_catg_ip_list",
					C__RELATION_TYPE__IP_ADDRESS,
					NULL,
					$p_net_connection,
					$p_object_id);

				return $l_last_id;
			} // if
		} else
		{
			throw new Exception("Object ID not numeric. IP creation failed!");
		} // if

		return false;
	} // function

	/**
	 * Merges posted IPv6 and IPv4 data into one data array so that the addresses could be stored in only one database field.
	 *
	 * @param int $p_net_type Net type (IPv4, IPv6,...)
	 * @return array
	 */
	public function merge_posted_ip_data($p_net_type, $p_key = null, $p_data = null) {
		$l_result = array();

		if($p_data === null)
		{
			$p_data = $_POST;
		} // if

		switch ($p_net_type) {
			case C__CATS_NET_TYPE__IPV4:
				if($p_key === null)
				{
					$p_key = 'C__CATP__IP__ADDRESS_V4';
				} // if

				if (array_key_exists('C__CATP__IP__SUBNETMASK_V4', $p_data)) {
					if (is_array($p_data['C__CATP__IP__SUBNETMASK_V4'])) {
						$l_result[C__IP__SUBNET] = implode('.', $p_data['C__CATP__IP__SUBNETMASK_V4']);
					} else {
						$l_result[C__IP__SUBNET] = $p_data['C__CATP__IP__SUBNETMASK_V4'];
					}

					$l_result[C__IP__SUBNET] = long2ip(ip2long($l_result[C__IP__SUBNET]));
				}

				if (array_key_exists($p_key, $p_data)) {
					if (is_array($p_data[$p_key])) {
						$l_result[C__IP__ADDRESS] = implode('.', $p_data[$p_key]);
					} else {
						$l_result[C__IP__ADDRESS] = $p_data[$p_key];
					}

					// If we enter a "empty" IP-address we don't want it transformed to "0.0.0.0".
					if ($l_result[C__IP__ADDRESS] != '...')
					{
						$l_result[C__IP__ADDRESS] = long2ip(ip2long($l_result[C__IP__ADDRESS]));
					} // if
				}
				break;

			case C__CATS_NET_TYPE__IPV6:
				if($p_key === null)
				{
					$p_key = 'C__CMDB__CATG__IP__IPV6_ADDRESS';
				} // if

				if (array_key_exists('C__CMDB__CATG__IP__IPV6_ASSIGNMENT', $p_data)) {
					$l_result[C__IP__ASSIGNMENT] = $p_data['C__CMDB__CATG__IP__IPV6_ASSIGNMENT'];
				}
				if (array_key_exists('C__CMDB__CATG__IP__IPV6_SCOPE', $p_data)) {
					$l_result[C__IP__IPV6_SCOPE] = $p_data['C__CMDB__CATG__IP__IPV6_SCOPE'];
				}
				if (array_key_exists('C__CMDB__CATG__IP__IPV6_PREFIX', $p_data)) {
					$l_result[C__IP__IPV6_PREFIX] = $p_data['C__CMDB__CATG__IP__IPV6_PREFIX'];
				}
				if (array_key_exists($p_key, $p_data)) {
					$l_result[C__IP__ADDRESS] = isys_helper_ip::validate_ipv6($p_data[$p_key]);
				}
				break;

			case C__CATS_NET_TYPE__IPX:
			case C__CATS_NET_TYPE__AT:
			default:
		}

		return $l_result;
	}

    /**
     * IP-Defaulting
     *
     * @param array $p_data
     * @param type $p_properties
     */
    public function pre_validation_procedure(&$p_data, $p_properties) {
        if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV4)
            $l_ip_data = $this->merge_posted_ip_data($_POST['C__NET__TYPE']);

        // Bugfix for not be able to save empty IP-addresses.
		if ($l_ip_data[C__IP__ADDRESS] == '...')
		{
			$l_ip_data[C__IP__ADDRESS] = '';
		}

        $p_data['ipv4_address'] = $l_ip_data[C__IP__ADDRESS];
    }

	protected function import_validation() {

		switch ($this->get_property('net_type')) {
			case C__CATS_NET_TYPE__IPV4:
				$this->m_sync_catg_data['properties']['address']['value'] = $this->get_property('ipv4_address');
				$this->m_sync_catg_data['properties']['ip_assignment']['value'] = $this->get_property('ipv4_assignment');
				break;
			case C__CATS_NET_TYPE__IPV6:
				$this->m_sync_catg_data['properties']['address']['value'] = $this->get_property('ipv6_address');
				$this->m_sync_catg_data['properties']['ip_assignment']['value'] = $this->get_property('ipv6_assignment');
				break;
			case C__CATS_NET_TYPE__AT:
			case C__CATS_NET_TYPE__IPX:
				break;
			default:
				return FALSE;
		}

		if (!is_numeric($this->m_sync_catg_data['properties']['net']['value'])) {
			//Default it
			if ($this->get_property('net_type') != C__CATS_NET_TYPE__IPV6) {
				$this->m_sync_catg_data['properties']['net']['value'] = C__OBJ__NET_GLOBAL_IPV4;
			} else {
				$this->m_sync_catg_data['properties']['net']['value'] = C__OBJ__NET_GLOBAL_IPV6;
			}
		}

		return TRUE;
	}

	/**
	 * Save element method.
	 *
	 * @param   integer  $p_cat_layer
	 * @param   integer  & $p_status
	 * @param   boolean  $p_create
	 * @return  mixed
	 * @author  Dennis Stücken <dstuecken@synetics.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save_element(&$p_cat_layer, &$p_status, $p_create = false)
	{
		$l_cat = $this->get_general_data();
		if($l_cat === null && !empty($_POST['C__CATG__IP__ID']))
		{
			$l_cat = $this->get_data($_POST['C__CATG__IP__ID'])->get_row();
			if($l_cat && count($l_cat) > 0)
				$p_create = false;
			else $p_create = true;
		}
		elseif ($l_cat === null && isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW)
		{
			$l_cat = $this->get_primary_ip($_GET[C__CMDB__GET__OBJECT])->get_row();
			$l_id = $l_cat['isys_catg_ip_list__id'];
			if($l_cat && count($l_cat) > 0)
				$p_create = false;
			else $p_create = true;
		}
		elseif ($l_cat === null)
		{
			$p_create = true;
		} // if

		$p_status = $l_cat['isys_catg_ip_list__status'];
		$l_port_type = NULL;
		$l_port_id = NULL;

		if(empty($l_id))
		{
			if (isset($_GET[C__CMDB__GET__CATLEVEL]) && $_GET[C__CMDB__GET__CATLEVEL] > 0)
			{
			    $l_id = $_GET[C__CMDB__GET__CATLEVEL];
			}
			elseif (!empty($_POST['C__CATG__IP__ID']))
			{
				$l_id = $_POST['C__CATG__IP__ID'];
		    } // if
		} // if
		//Check which network address type is selected and assign its corresponding address values.
		$l_ip_data = $this->merge_posted_ip_data($_POST['C__NET__TYPE']);

		// Bugfix for not be able to save empty IP-addresses.
		if ($l_ip_data[C__IP__ADDRESS] == '...')
		{
			$l_ip_data[C__IP__ADDRESS] = '';
		} // if

		// Dont save on overview category if values are empty.
		if (isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW &&
			($l_ip_data[C__IP__ADDRESS] == '' || $l_ip_data[C__IP__ADDRESS] == '0.0.0.0') &&
			($l_ip_data[C__IP__SUBNET] == '' || $l_ip_data[C__IP__SUBNET] == '0.0.0.0') &&
			$_POST['C__CATG__IP__NET__HIDDEN'] == C__OBJ__NET_GLOBAL_IPV4 &&
			$_POST['C__CATP__IP__DNS_DOMAIN__HIDDEN'] == '' &&
			$_POST['C__CATP__IP__HOSTNAME'] == '' &&
			$_POST['C__CATG__IP__ASSIGNED_DNS_SERVER__HIDDEN'] == '[]' &&
			$_POST['C__CATP__IP__DNS_DOMAIN__HIDDEN'] == '' &&
			$_POST['C__CATP__IP__ACTIVE'] == '1' &&
			$_POST['C__CATP__IP__PRIMARY'] == '1'
		) {
			return null;
		}

		// We check if a layer3 net has been assigned - If now, we assign the global v4 or v6 (depends on the net type).
		if (empty($_POST['C__CATG__IP__NET__HIDDEN']))
		{
			if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV6)
			{
				$_POST['C__CATG__IP__NET__HIDDEN'] = C__OBJ__NET_GLOBAL_IPV6;
			}
			else
			{
				$_POST['C__CATG__IP__NET__HIDDEN'] = C__OBJ__NET_GLOBAL_IPV4;
			} // if
		} // if

		// Port assignment.
		if (isset($_POST["C__CATG__IP__ASSIGNED_PORTS"]) && $_POST["C__CATG__IP__ASSIGNED_PORTS"] != -1) {
			$l_port_type = substr($_POST["C__CATG__IP__ASSIGNED_PORTS"], (strpos($_POST["C__CATG__IP__ASSIGNED_PORTS"], '_') + 1), strlen($_POST["C__CATG__IP__ASSIGNED_PORTS"]));

			if ($l_port_type == 'C__CMDB__SUBCAT__NETWORK_PORT') {
				$l_port_id = substr($_POST["C__CATG__IP__ASSIGNED_PORTS"], 0, (strpos($_POST["C__CATG__IP__ASSIGNED_PORTS"], '_')));
				$l_log_port_id = NULL;
			} elseif ($l_port_type == 'C__CMDB__SUBCAT__NETWORK_INTERFACE_L') {
				$l_port_id = NULL;
				$l_log_port_id = substr($_POST["C__CATG__IP__ASSIGNED_PORTS"], 0, (strpos($_POST["C__CATG__IP__ASSIGNED_PORTS"], '_')));
			}
		}

		$l_ipv6_assignment = null;
		if (array_key_exists('C__CMDB__CATG__IP__IPV6_ASSIGNMENT', $_POST)) {
			$l_ipv6_assignment = $_POST['C__CMDB__CATG__IP__IPV6_ASSIGNMENT'];
		}
		$l_ipv6_scope = null;

		if (array_key_exists('C__CMDB__CATG__IP__IPV6_SCOPE', $_POST))
		{
			$l_ipv6_scope = $_POST['C__CMDB__CATG__IP__IPV6_SCOPE'];
		} // if

		// Before we create or save the host-address, we check if we are forced to create a new DHCP (reserved) area.
		if (! empty($l_ip_data[C__IP__ADDRESS]))
		{
			// We know that we have a IP address and a DHCP (v4/v6) or DHCP reserved (v4/v6) assignment.
			$l_dhcp_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_dhcp', $this->get_database_component());

			// We can not handle IPv4 and IPv6 the same way.
			if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV4 && ($_POST['C__CATP__IP__ASSIGN'] == C__CATP__IP__ASSIGN__DHCP_RESERVED || $_POST['C__CATP__IP__ASSIGN'] == C__CATP__IP__ASSIGN__DHCP))
			{
				$l_type = C__NET__DHCP_DYNAMIC;

				if ($_POST['C__CATP__IP__ASSIGN'] == C__CATP__IP__ASSIGN__DHCP_RESERVED)
				{
					$l_type = C__NET__DHCP_RESERVED;
				}

				$l_dhcp_dao->check_and_merge_new_dhcp_range_inside_existing(
					$_POST['C__CATG__IP__NET__HIDDEN'],
					$l_type,
					$l_ip_data[C__IP__ADDRESS]);
			}
			else if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV6 && ($_POST['C__CMDB__CATG__IP__IPV6_ASSIGNMENT'] == C__CMDB__CATG__IP__DHCPV6 || $_POST['C__CMDB__CATG__IP__IPV6_ASSIGNMENT'] == C__CMDB__CATG__IP__DHCPV6_RESERVED))
			{
				// Handle IPv6 addresses here.
				$l_type = C__NET__DHCPV6__DHCPV6;

				if ($_POST['C__CMDB__CATG__IP__IPV6_ASSIGNMENT'] == C__CMDB__CATG__IP__DHCPV6_RESERVED)
				{
					$l_type = C__NET__DHCPV6__DHCPV6_RESERVED;
				} // if

				$l_dhcp_dao->check_and_merge_new_dhcpv6_range_inside_existing(
					$_POST['C__CATG__IP__NET__HIDDEN'],
					$l_type,
					$l_ip_data[C__IP__ADDRESS]);
			} // if
		} // if

		if ($p_create)
		{
			$l_return = $this->create(
				$_GET[C__CMDB__GET__OBJECT],
				$_POST['C__CATP__IP__HOSTNAME'],
				($_POST['C__NET__TYPE'] != C__CATS_NET_TYPE__IPV6) ? $_POST['C__CATP__IP__ASSIGN'] : $l_ipv6_assignment,
				$l_ip_data[C__IP__ADDRESS],
				$_POST['C__CATP__IP__PRIMARY'],
				$_POST['C__CATG__IP__GW__CHECK'],
				isys_format_json::decode($_POST['C__CATG__IP__ASSIGNED_DNS_SERVER__HIDDEN']),
				explode(',', $_POST['C__CATP__IP__DNS_DOMAIN__HIDDEN']),
				$_POST['C__CATP__IP__ACTIVE'],
				$_POST['C__NET__TYPE'],
				$_POST['C__CATG__IP__NET__HIDDEN'],
				$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()],
				C__RECORD_STATUS__NORMAL,
				$l_port_id,
				$l_log_port_id,
				$l_ipv6_scope,
				$l_ipv6_assignment);

			$p_cat_layer = NULL;
		}
		else
		{
			if ($l_id)
			{
				$this->save(
					$l_id,
					$_POST['C__CATP__IP__HOSTNAME'],
					$_POST['C__CATP__IP__ASSIGN'],
					$l_ip_data[C__IP__ADDRESS],
					$_POST['C__CATP__IP__PRIMARY'],
					$_POST['C__CATG__IP__GW__CHECK'],
					isys_format_json::decode($_POST['C__CATG__IP__ASSIGNED_DNS_SERVER__HIDDEN']),
					explode(',', $_POST['C__CATP__IP__DNS_DOMAIN__HIDDEN']),
					$_POST['C__CATP__IP__ACTIVE'],
					$_POST['C__NET__TYPE'],
					$_POST['C__CATG__IP__NET__HIDDEN'],
					$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()],
					C__RECORD_STATUS__NORMAL,
					$l_port_id,
					$l_log_port_id,
					$l_ipv6_assignment,
					$l_ipv6_scope);
			} // if
		} // if

		return ($l_return > 0) ? $l_return : null;
	} // function


	/**
	 * Returns an ip entry by the ip address (Can exclude one ip entry and one object id).
	 *
	 * @param   string   $p_ip_address
	 * @param   integer  $p_exclude_catg_list_id
	 * @param   integer  $p_exclude_object_id
	 * @param   integer  $p_assigned_net
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_ip_by_address($p_ip_address, $p_exclude_catg_list_id = null, $p_exclude_object_id = null, $p_assigned_net = null, $p_status = C__RECORD_STATUS__NORMAL) {

		if (($l_ipv6 = isys_helper_ip::validate_ipv6($p_ip_address))) {
			$p_ip_address = $l_ipv6;
			$l_table_alias = 'ipv6';
		} else{
			$l_table_alias = 'ipv4';
		}

		$l_sql = " AND ((".$l_table_alias.".isys_cats_net_ip_addresses_list__title = " . $this->convert_sql_text($p_ip_address) . ") " .
					"AND (isys_catg_ip_list__status = " . C__RECORD_STATUS__NORMAL . "))";

		if (!empty($p_exclude_object_id)) {
			$l_sql .= " AND (isys_obj__id != " . $this->convert_sql_id($p_exclude_object_id) . ")";
		} // if

		if (!empty($p_exclude_catg_list_id)) {
			$l_sql .= " AND (isys_catg_ip_list__id != " . $this->convert_sql_id($p_exclude_catg_list_id) . ")";
		} // if

		if (!empty($p_assigned_net)) {
			$l_sql .= " AND (".$l_table_alias.".isys_cats_net_ip_addresses_list__isys_obj__id = " . $this->convert_sql_id($p_assigned_net) . ")";
		} // if

		return $this->get_data(
			null,
			null,
			$l_sql,
			null,
			$p_status);
	}


	/**
	 * Validates user data.
	 *
	 * @return  boolean
	 */
	public function validate_user_data ()
	{
        $l_arrTomAdditional = array();

		if (parent::validate_user_data() === false)
		{
			$l_arrTomAdditional = $this->get_additional_rules();
		} // if

		assert('array_key_exists("C__NET__TYPE", $_POST)');
		$l_ip_data = $this->merge_posted_ip_data($_POST['C__NET__TYPE']);

		// If we receive "..." it's an empty IP-address.
		if ($l_ip_data[C__IP__ADDRESS] == '...')
		{
			$l_ip_data[C__IP__ADDRESS] = '';
		} // if

		// @todo What about the other types?!
		if (!empty($l_ip_data[C__IP__ADDRESS]) && ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV4 || $_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV6))
		{
			$l_formtag = null;

			if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV4)
			{
				$l_formtag = 'C__CATP__IP__ADDRESS_V4';
			}
			else if ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV6)
			{
				$l_formtag = 'C__CMDB__CATG__IP__IPV6_ADDRESS';
			} // if

			switch ($_POST['C__NET__TYPE'])
			{
				case C__CATS_NET_TYPE__IPV4:
					if (!filter_var($l_ip_data[C__IP__ADDRESS], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4))
					{
						$l_arrTomAdditional[$l_formtag]['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
					} // if
					break;

				case C__CATS_NET_TYPE__IPV6:
					if (!filter_var($l_ip_data[C__IP__ADDRESS], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6))
					{
						$l_arrTomAdditional[$l_formtag]['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
					} // if
					break;
			} // switch
		} // if

		if (isys_settings::get('cmdb.unique.hostname') && !empty($_POST["C__CATP__IP__HOSTNAME"]))
		{
			$l_host = $this->get_data(
				null,
				null,
				" ".
				"AND (".
					"isys_catg_ip_list__hostname = " . $this->convert_sql_text($_POST["C__CATP__IP__HOSTNAME"]) . " ".
					"AND isys_catg_ip_list__isys_obj__id != " . $this->convert_sql_id($_GET[C__CMDB__GET__OBJECT]) . " ".
					"AND ".
						"(".
							"ipv4.isys_cats_net_ip_addresses_list__isys_obj__id = " . $this->convert_sql_id($_POST["C__CATG__IP__NET__HIDDEN"]) .
								" OR ".
							"ipv6.isys_cats_net_ip_addresses_list__isys_obj__id = " . $this->convert_sql_id($_POST["C__CATG__IP__NET__HIDDEN"]) .
						")".
					")",
				null,
				C__RECORD_STATUS__NORMAL);

			if ($l_host->num_rows() > 0)
			{
				$l_arrTomAdditional["C__CATP__IP__HOSTNAME"]["p_strInfoIconError"] = sprintf(_L('LC__CMDB__HOSTNAME__ALREADY_ASSIGNED'), $_POST["C__CATP__IP__HOSTNAME"]);
			} // if
		} // if

		if ($_GET["C__CATP__IP__PRIMARY"] > 0)
		{
			$l_ips = $this->get_primary_ip($_GET[C__CMDB__GET__OBJECT]);

			if ($l_ips->num_rows() > 0)
			{
				$l_ip = $l_ips->get_row();

				$l_arrTomAdditional["C__CATP__IP__PRIMARY"]["p_strInfoIconError"] = sprintf(_L("LC__CMDB__IP__PRIMARY_EXISTS"), $l_ip["isys_cats_net_ip_addresses_list__title"]);
			} // if
		} // if

		if (isset($l_arrTomAdditional['C__CATG__IP__ASSIGNED_PORTS']))
		{
			$l_port_id  = substr($_POST['C__CATG__IP__ASSIGNED_PORTS'], 0, strpos($_POST['C__CATG__IP__ASSIGNED_PORTS'], '_'));
			$l_category = substr($_POST['C__CATG__IP__ASSIGNED_PORTS'], strpos($_POST['C__CATG__IP__ASSIGNED_PORTS'], '_') + 1, strlen($_POST['C__CATG__IP__ASSIGNED_PORTS']));
			if (is_numeric($l_port_id) && is_string($l_category))
			{
				unset($l_arrTomAdditional['C__CATG__IP__ASSIGNED_PORTS']);
			}
		}

        $l_fieldname = ($_POST['C__NET__TYPE'] == C__CATS_NET_TYPE__IPV4) ? 'C__CATP__IP__ADDRESS_V4[]' : 'C__CMDB__CATG__IP__IPV6_ADDRESS';

		if ($l_ip_data[C__IP__ADDRESS] && isys_settings::get('cmdb.unique.ip-address'))
		{
	        $l_catLevel = $this->in_use($_POST['C__CATG__IP__NET__HIDDEN'], $l_ip_data[C__IP__ADDRESS], $_GET[C__CMDB__GET__CATLEVEL]);

	        if ($l_catLevel)
	        {
	            $l_row = $this->get_data($l_catLevel)->get_row();
				if($l_row['isys_catg_ip_list__isys_obj__id'] != $_GET[C__CMDB__GET__OBJECT])
				{
					$l_arrTomAdditional[$l_fieldname]["p_strInfoIconError"] = (isys_settings::get('cmdb.unique.ip-address')) ?
							_L('LC__CATG__IP__UNIQUE_IP_WARNING', array($l_row['isys_obj__title'], $l_row['isys_obj__id'])) :
							_L("LC__CMDB__IP__ALREADY_ASSIGNED", $l_ip["isys_obj__title"]);
				} // if
	        } // if
		} // if

		if (count($l_arrTomAdditional) > 0)
		{
			$this->set_additional_rules($l_arrTomAdditional);
            $this->set_validation(false);

            return false;
		} // if

		$this->set_validation(true);
		return true;
	} // function

    /**
     * Check whether an ip-address is
     * in use or not.
     *
     * @author Selcuk Kekec <skekec@synetics.de>
     * @param type $p_netID     IP of the net
     * @param type $p_ipAddress     IP-Address
     * @param type $p_catToIgnore       CatLevel-ID to ignore
     * @param type $p_ignoreGlobals     Switch to ignore the global NET
     * @return boolean
     */
    public function in_use($p_netID, $p_ipAddress, $p_catToIgnore, $p_ignoreGlobals=TRUE) {
        /* Ignore empty ip-addresses */
        if ($p_ipAddress == "")
            return false;

        $l_return = false;
        $l_condition = '';

        if ($p_ignoreGlobals && in_array($p_netID, array(C__OBJ__NET_GLOBAL_IPV4, C__OBJ__NET_GLOBAL_IPV6))) return false;

        $l_netInfo = $this->retrieve("SELECT isys_cats_net_list__isys_net_type__id FROM isys_cats_net_list WHERE isys_cats_net_list__isys_obj__id = ".$this->convert_sql_id($p_netID))->get_row_value('isys_cats_net_list__isys_net_type__id');

        /* Status-Handling */
        $l_condition .= ' AND isys_catg_ip_list__status = '.C__RECORD_STATUS__NORMAL.' AND isys_obj__status = '.C__RECORD_STATUS__NORMAL.' ';

        if ($p_catToIgnore)
                $l_condition = ' AND isys_catg_ip_list__id != ' . $this->convert_sql_id($p_catToIgnore);

        if ($l_netInfo == C__CATS_NET_TYPE__IPV4)
        {
            $l_condition .=
                ' AND '.
                '('.
                    'ipv4.isys_cats_net_ip_addresses_list__title = ' . $this->convert_sql_text($p_ipAddress) . ' ' .
                    'OR '.
                    'ipv4.isys_cats_net_ip_addresses_list__ip_address_long = ' . $this->convert_sql_text(isys_helper_ip::ip2long($p_ipAddress)) .
                ') ' .
                'AND ipv4.isys_cats_net_ip_addresses_list__isys_obj__id = ' . $this->convert_sql_id($p_netID);
        }
        else if ($l_netInfo == C__CATS_NET_TYPE__IPV6)
        {
            $l_condition .=
                ' AND ipv6.isys_cats_net_ip_addresses_list__title = ' . $this->convert_sql_text($p_ipAddress) .
                ' AND ipv6.isys_cats_net_ip_addresses_list__isys_obj__id = ' . $this->convert_sql_id($p_netID);
        } // if

        $l_res = $this->get_data(null, null, $l_condition, null, C__RECORD_STATUS__NORMAL);

        if (count($l_res) > 0) {
            $l_row = $l_res->get_row();

            $l_return = $l_row['isys_catg_ip_list__id'];
        } // if

        return $l_return;
    } // function

	/**
	 * Get primary ip only.
	 *
	 * @param   integer  $p_object_id
	 * @return  isys_component_dao_result
	 */
	public function get_primary_ip ($p_object_id)
	{
		return $this->get_ips_by_obj_id($p_object_id, true);
	} // function
	/**
	 * Get primary ip as string
	 *
	 * @param   integer  $p_object_id
	 * @return  isys_component_dao_result
	 */
	public function get_primary_ip_as_string ($p_object_id)
	{
		$l_ip = $this->get_ips_by_obj_id($p_object_id, true)->get_row();
		return @$l_ip['isys_cats_net_ip_addresses_list__title'];
	} // function

	/**
	 * Delete all IPs in a port.
	 *
	 * @param   integer  $p_port_id
	 * @param   integer  $p_status
	 * @return  boolean
	 */
	public function delete_ips ($p_port_id, $p_status = C__RECORD_STATUS__NORMAL)
	{
		$l_ips = $this->get_ips_by_port_id($p_port_id);
		while ($l_row = $l_ips->get_row())
		{
			$l_sql = 'DELETE FROM isys_catg_ip_list
				WHERE isys_catg_ip_list__id = ' . $this->convert_sql_int($l_row["isys_catg_ip_list__id"]) . ' ';

			if ($p_status)
			{
				$l_sql .= ' AND isys_catg_ip_list__status = ' . $this->convert_sql_int($p_status);
			} // if

			return ($this->update($l_sql . ";") && $this->apply_update());
		} // while

		return true;
	} // function


	/**
	 * Method resetting the IP addresses of given objects.
	 *
	 * @param   mixed  $p_obj_id  May be a single ID or an array of IDs.
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function empty_ip_addresses_from_obj ($p_obj_id)
	{
		$l_sql = 'SELECT isys_catg_ip_list__isys_cats_net_ip_addresses_list__id
			FROM isys_catg_ip_list
			WHERE TRUE ';

		if (is_array($p_obj_id) && count($p_obj_id) > 0)
		{
			$l_sql .= 'AND isys_catg_ip_list__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ';';
		}
		elseif($p_obj_id > 0)
		{
			$l_sql .= 'AND isys_catg_ip_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ';';
		}
		else
		{
			return true;
		} // if

		$l_res = $this->retrieve($l_sql);

		if ($l_res->num_rows() > 0)
		{
			$l_ip_address_id = array();

			while ($l_row = $l_res->get_row())
			{
				$l_ip_address_id[] = $l_row['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'];
			} // while

			if (count($l_ip_address_id))
			{
				$l_sql = 'UPDATE isys_cats_net_ip_addresses_list
					SET isys_cats_net_ip_addresses_list__title = "",
					isys_cats_net_ip_addresses_list__ip_address_long = 0
					WHERE isys_cats_net_ip_addresses_list__id ' . $this->prepare_in_condition($l_ip_address_id);

				return ($this->update($l_sql) && $this->apply_update());
			} // if
		} // if

		// Nothing to empty!
		return true;
	} // function


	/**
	 * Receive IPs by Port ID.
	 *
	 * @param   integer  $p_port_id
	 * @param   boolean  $p_primary_only
	 * @return  isys_component_dao_result
	 */
	public function get_ips_by_port_id ($p_port_id, $p_primary_only = false)
	{
		return $this->get_ips_by_obj_id(null, $p_primary_only, $p_port_id);
	} // function


	/**
	 * Returns all ips connected to table $p_table_name.
	 *
	 * @param string $p_table_name
	 * @param int $p_id
	 * @param int $p_obj_id
	 * @param boolean $p_primary_only
	 * @return isys_component_dao_result
	 */
	public function get_ips_by_connection_table($p_table_name = "isys_catg_port_list", $p_id = NULL, $p_obj_id = NULL, $p_primary_only = false, $p_short_fields = false) {
		$l_query = "SELECT * FROM isys_catg_ip_list " .
			"INNER JOIN isys_cats_net_ip_addresses_list ".
			"ON isys_cats_net_ip_addresses_list__id = isys_catg_ip_list__isys_cats_net_ip_addresses_list__id ".
			"INNER JOIN isys_catg_ip_list_2_" . $p_table_name . " " .
			"ON ";

		if (!$p_short_fields) {
			$l_query .= "isys_catg_ip_list_2_" . $p_table_name . "__isys_catg_ip_list__id = " .
				"isys_catg_ip_list__id  ";
		} else {
			$l_query .= "isys_catg_ip_list_2_" . $p_table_name . ".isys_catg_ip_list__id = " .
				"isys_catg_ip_list.isys_catg_ip_list__id  ";
		}

		$l_query .= "WHERE TRUE";

		if (!empty($p_obj_id)) {
			$l_query .= " AND (isys_catg_ip_list__isys_obj__id = " . $p_obj_id . ")";
		}

		if ($p_primary_only) {
			$l_query .= " AND (isys_catg_ip_list__primary = 1)";
		}

		if (!empty($p_id)) {
			if (!$p_short_fields) {
				$l_query .= " AND (isys_catg_ip_list_2_" . $p_table_name . "__" . $p_table_name . "__id = '" . $p_id . "')";
			} else {
				$l_query .= " AND (isys_catg_ip_list_2_" . $p_table_name . "." . $p_table_name . "__id = '" . $p_id . "')";
			}
		}

		return $this->retrieve($l_query);
	}


	/**
	 * Gets all IPs over all Ports of an object given by its id.
	 *
	 * @param   integer   $p_objID
	 * @param   boolean   $p_primary_only
	 * @param   boolean   $p_join_port_connection
	 * @param   integer   $p_port_id
	 * @param   string   $p_condition
	 * @return  isys_component_dao_result  The result set
	 * @author  Dennis Bluemer <dbluemer@synetcis.de>
	 * @author  Dennis Stuecken <dstuecken@synetics.de>
	 */
	public function get_ips_by_obj_id($p_objID, $p_primary_only = false, $p_unused_parameter = false, $p_port_id = null, $p_condition = '') {

		$l_query = 'SELECT * FROM isys_catg_ip_list
			INNER JOIN isys_cats_net_ip_addresses_list ON isys_catg_ip_list__isys_cats_net_ip_addresses_list__id = isys_cats_net_ip_addresses_list__id
			INNER JOIN isys_cats_net_list ON isys_cats_net_list__isys_obj__id = isys_cats_net_ip_addresses_list__isys_obj__id
			WHERE TRUE ' . $p_condition;

		if ($p_objID)
		{
			$l_query .= " AND isys_catg_ip_list__isys_obj__id = " . $this->convert_sql_id($p_objID);
		} // if

		if ($p_primary_only)
		{
			$l_query .= " AND isys_catg_ip_list__primary = 1";
		} // if

		if (!empty($p_port_id))
		{
			$l_query .= ' AND isys_catg_ip_list__isys_catg_port_list__id = ' . $this->convert_sql_id($p_port_id);
		} // if

		if ($p_primary_only)
		{
			$l_query .= " LIMIT 1";
		} // if

		return $this->retrieve($l_query . ';');
	} // function

	/**
	 * Gets all IPs over all Ports of an object given by its id
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_router_list_id
	 * @param   integer  $p_record_status
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@synetcis.de>
	 */
	public function get_ips_for_router_list_by_obj_id ($p_obj_id = null, $p_router_list_id = null, $p_record_status = C__RECORD_STATUS__NORMAL)
	{
		$l_sql = 'SELECT router.* FROM isys_catg_ip_list AS ip
			LEFT JOIN isys_catg_ip_list_2_isys_cats_router_list AS router ON ip.isys_catg_ip_list__id = router.isys_catg_ip_list__id
			WHERE TRUE ';

		if ($p_obj_id !== null)
		{
			$l_sql .= 'AND ip.isys_catg_ip_list__isys_obj__id = ' . $this->convert_sql_id(intval($p_obj_id)) . ' ';
		} // if

		if ($p_router_list_id !== null)
		{
			$l_sql .= 'AND router.isys_cats_router_list__id = ' . $this->convert_sql_id(intval($p_router_list_id)) . ' ';
		} // if

		if ($p_record_status > 0)
		{
			$l_sql .= 'AND ip.isys_catg_ip_list__status = ' . $this->convert_sql_id(intval($p_record_status));
		} // if

		return $this->retrieve($l_sql . ';');
	} // function


	public function getObjIDsByIP($p_ip) {
		$l_result = $this->get_ip_by_address($p_ip);
		$l_objIDs = array();
		while ($l_row = $l_result->get_row()) {
			$l_objIDs[] = $l_row;
		}
		return $l_objIDs;
	} // function


	public function getObjIDsByHostName($p_hostname) {
		$l_query = "SELECT DISTINCT isys_catg_ip_list__isys_obj__id as 'id' " .
					"FROM isys_catg_ip_list " .
					"WHERE isys_catg_ip_list__hostname = '" . $p_hostname . "'";
		$l_result = $this->retrieve($l_query);
		$l_objIDs = array();

		while ($l_row = $l_result->get_row()) {
			$l_objIDs[] = $l_row;
		}
		return $l_objIDs;
	} // function


	/**
	 * Checks if an ip address belongs to the net object. $p_ip_address should be an ipv4 string.
	 *
	 * @param   string   $p_ip_address
	 * @param   integer  $p_net_object
	 * @return  boolean
	 */
	public function is_ip_inside_net($p_ip_address, $p_net_object)
	{
		$l_net_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net', $this->m_db);
		$l_data = $l_net_dao->get_data(NULL, $p_net_object)->__to_array();

		$l_range_from = isys_helper_ip::ip2long($l_data["isys_cats_net_list__dhcp_range_from"]);
		$l_range_to = isys_helper_ip::ip2long($l_data["isys_cats_net_list__dhcp_range_to"]);
		$l_ip = isys_helper_ip::ip2long($p_ip_address);

		return ($l_range_from <= $l_ip && $l_range_to >= $l_ip);
	} // function


	/**
	 * Returns an entry of the isys_catg_ip_list, by a given ID.
	 *
	 * @param   integer  $p_id
	 * @return  array
	 */
	public function get_ip_by_id($p_id)
	{
		$l_query = 'SELECT * FROM isys_catg_ip_list
			INNER JOIN isys_cats_net_ip_addresses_list ON isys_catg_ip_list__isys_cats_net_ip_addresses_list__id = isys_cats_net_ip_addresses_list__id
			WHERE isys_catg_ip_list__id = ' . $this->convert_sql_id($p_id) . ';';
		return $this->retrieve($l_query)->get_row();
	} // function


	/**
	 * A method, which bundles the handle_ajax_request and handle_preselection.
	 *
	 * @param   integer  $p_context
	 * @param   array    $p_parameters
	 * @return  string  A JSON Encoded array with all the contents of the second list.
	 * @return  array   A PHP Array with the preselections for category, first- and second list.
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function object_browser($p_context, array $p_parameters)
	{
		switch ($p_context)
		{
			case isys_popup_browser_object_ng::C__CALL_CONTEXT__REQUEST:
				// Handle Ajax-Request.
				$l_return = array();

				$l_obj = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_ip', $this->m_db);
				$l_objects = $l_obj->get_ips_by_obj_id($_GET[C__CMDB__GET__OBJECT]);

				if ($l_objects->num_rows() > 0)
				{
					while ($l_row = $l_objects->get_row())
					{
						$l_return[] = array(
							'__checkbox__' => $l_row["isys_catg_ip_list__id"],
							isys_glob_utf8_encode(_L('LC__CATG__IP_ADDRESS')) => isys_glob_utf8_encode($l_row["isys_cats_net_ip_addresses_list__title"])
						);
					} // while
				} // if

				return json_encode($l_return);
				break;

			case isys_popup_browser_object_ng::C__CALL_CONTEXT__PREPARATION:
				// Preselection
				$l_return = array(
					'category' => array(),
					'first' => array(),
					'second' => array()
				);

				$p_preselection = $p_parameters['preselection'];

				// When we get a JSON string, we modify it to an comma separated list.
				if (isys_format_json::is_json($p_preselection))
				{
					$p_preselection = implode(',', isys_format_json::decode($p_preselection, true));
				}

				if (!empty($p_preselection) && is_string($p_preselection)) {
					$l_sql = "SELECT isys_obj__isys_obj_type__id, isys_catg_ip_list__id, isys_cats_net_ip_addresses_list__title, isys_obj_type__title " .
						"FROM isys_catg_ip_list " .
						"INNER JOIN isys_cats_net_ip_addresses_list ON isys_catg_ip_list__isys_cats_net_ip_addresses_list__id = isys_cats_net_ip_addresses_list__id " .
						"LEFT JOIN isys_obj ON isys_obj__id = isys_catg_ip_list__isys_obj__id " .
						"LEFT JOIN isys_obj_type ON isys_obj_type__id = isys_obj__isys_obj_type__id " .
						"WHERE isys_catg_ip_list__id IN (" . $p_preselection . ")";

					$l_res = $this->retrieve($l_sql);

					if ($l_res->num_rows() > 1) {
						while ($l_row = $l_res->get_row()) {
							// Prepare return data.
							$l_return['category'][] = $l_row['isys_obj__isys_obj_type__id'];
							$l_return['second'][] = array(
								isys_glob_utf8_encode($l_row['isys_catg_ip_list__id']),
								isys_glob_utf8_encode($l_row['isys_cats_net_ip_addresses_list__title']),
								isys_glob_utf8_encode(_L($l_row['isys_obj_type__title'])),
							); // $l_line;
						}
					} // if
				} // if

				return $l_return;
				break;
		} // switch
	} // function


	/**
	 * Formats the title of the object for the object browser.
	 *
	 * @param   integer  $p_ip_id
	 * @param   boolean  $p_plain
	 * @return  string
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function format_selection($p_ip_id, $p_plain = false)
	{
		// We need a DAO for the object name.
		$l_dao_ip = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_ip', $this->m_db);
		$l_quick_info = new isys_ajax_handler_quick_info();

		$l_row = $l_dao_ip->get_ip_by_id($p_ip_id);

		$p_object_type = $l_dao_ip->get_objTypeID($l_row["isys_catg_ip_list__isys_obj__id"]);

		if (!empty($p_ip_id))
		{
			$l_editmode = ($_POST[C__GET__NAVMODE] == C__NAVMODE__EDIT ||
				isys_glob_get_param("editMode") == C__EDITMODE__ON ||
				isset($this->m_params["edit"])) &&
				!isset($this->m_params["plain"]);

			$l_title = _L($l_dao_ip->get_objtype_name_by_id_as_string($p_object_type)) .
				" >> " . $l_dao_ip->get_obj_name_by_id_as_string($l_row["isys_catg_ip_list__isys_obj__id"]) .
				" >> " . $l_row["isys_cats_net_ip_addresses_list__title"];

			if (!$l_editmode && !$p_plain)
			{
				return $l_quick_info->get_quick_info(
					$l_row["isys_catg_ip_list__isys_obj__id"],
					$l_title,
					C__LINK__OBJECT);
			}
			else
			{
				return $l_title;
			} // if
		} // if

		return _L("LC__CMDB__BROWSER_OBJECT__NONE_SELECTED");
	} // function


	/**
	 * Gets assigned dns domains assigned to the host address.
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_id
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 * @return  isys_component_dao_result
	 */
	public function get_assigned_dns_domain ($p_obj_id = null, $p_id = null)
	{

		if (empty($p_obj_id) && empty($p_id))
		{
			return false;
		}

		$l_sql = 'SELECT dnstable.isys_net_dns_domain__id, dnstable.isys_net_dns_domain__title
			FROM isys_catg_ip_list_2_isys_net_dns_domain AS main
			INNER JOIN isys_net_dns_domain dnstable ON main.isys_net_dns_domain__id = dnstable.isys_net_dns_domain__id';

		if ($p_obj_id > 0)
		{
			$l_condition = ' WHERE main.isys_catg_ip_list__id = (SELECT isys_catg_ip_list__id FROM isys_catg_ip_list WHERE isys_catg_ip_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ' ORDER BY isys_catg_ip_list__primary DESC LIMIT 1)';
		} // if

		if ($p_id > 0)
		{
			$l_condition = ' WHERE main.isys_catg_ip_list__id = ' . $this->convert_sql_id($p_id);
		} // if

		return $this->retrieve($l_sql . $l_condition . ';');
	} // function

	/**
	 * Gets assigned dns server for the host address
	 *
	 * @param int $p_cat_id
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 * @return array
	 */
	public function get_assigned_dns_server($p_cat_id) {

		$l_arr = array();

		$l_sql = 'SELECT isys_catg_ip_list__id__dns FROM isys_catg_ip_list_2_isys_catg_ip_list ' .
			'WHERE isys_catg_ip_list__id = ' . $this->convert_sql_id($p_cat_id);

		$l_res = $this->retrieve($l_sql);

		if ($l_res && $l_res->num_rows() > 0) {
			while ($l_row = $l_res->get_row()) {
				$l_arr[] = $l_row['isys_catg_ip_list__id__dns'];
			}
		}
		return $l_arr;
	}

	/**
	 * Deletes dns server connection for the specified category entry id
	 *
	 * @param int $p_id
	 * @return bool
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function clear_dns_server_attachments($p_id) {
		if (empty($p_id))
			return;

		try {
			$l_sql = 'DELETE FROM isys_catg_ip_list_2_isys_catg_ip_list WHERE isys_catg_ip_list__id = ' . $this->convert_sql_id($p_id);
			$this->update($l_sql);
		} catch (Exception $e) {
			throw new Exception('Error while clearing attachments.');
		}
		return $this->apply_update();
	}

	/**
	 * Deletes dns domain connection for the specified category entry id
	 *
	 * @param int $p_id
	 * @return bool
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function clear_dns_domain_attachments($p_id) {
		if (empty($p_id))
			return;

		try {
			$l_sql = 'DELETE FROM isys_catg_ip_list_2_isys_net_dns_domain WHERE isys_catg_ip_list__id = ' . $this->convert_sql_id($p_id);
			$this->update($l_sql);
		} catch (Exception $e) {
			throw new Exception('Error while clearing attachments.');
		}
		return $this->apply_update();
	}

	/**
	 * Creates new dns server connection with the specified object id
	 *
	 * @param int $p_cat_id
	 * @param int $p_obj_id
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 * @return bool
	 */
	public function attach_dns_server($p_cat_id, $p_cat_dns_server_id) {
		if (empty($p_cat_id) || empty($p_cat_dns_server_id))
			return;

		$l_insert = 'INSERT INTO isys_catg_ip_list_2_isys_catg_ip_list (isys_catg_ip_list__id, isys_catg_ip_list__id__dns) VALUES ';

		$l_insert.='(' . $this->convert_sql_id($p_cat_id) . ', ' . $this->convert_sql_id($p_cat_dns_server_id) . ')';

		return ($this->update($l_insert) && $this->apply_update());
	}

	/**
	 * Creates new dns domain connection with the specified domain id
	 *
	 * @param int $p_cat_id
	 * @param int $p_dns_domain_id
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 * @return bool
	 */
	public function attach_dns_domain($p_cat_id, $p_dns_domain_id) {
		if (empty($p_cat_id) || empty($p_dns_domain_id))
			return;

		$l_insert = 'INSERT INTO isys_catg_ip_list_2_isys_net_dns_domain (isys_catg_ip_list__id, isys_net_dns_domain__id) VALUES ';

		$l_insert.='(' . $this->convert_sql_id($p_cat_id) . ', ' . $this->convert_sql_id($p_dns_domain_id) . ')';

		return ($this->update($l_insert) && $this->apply_update());
	}

	/**
	 * Sets the default gateway of the net
	 *
	 * @param int $p_net_id
	 * @param int $p_net_obj_id
	 * @param int $p_cat_id
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 * @return bool
	 */
	public function attach_gateway($p_net_id = NULL, $p_net_obj_id = NULL, $p_cat_id) {

		$l_update = 'UPDATE isys_cats_net_list SET isys_cats_net_list__isys_catg_ip_list__id = ' . $this->convert_sql_id($p_cat_id) . ' ';

		if ($p_net_id > 0)
			$l_update .= 'WHERE isys_cats_net_list__id = ' . $this->convert_sql_id($p_net_id);
		elseif ($p_net_obj_id)
			$l_update .= 'WHERE isys_cats_net_list__isys_obj__id = ' . $this->convert_sql_id($p_net_obj_id);

		return ($this->update($l_update) && $this->apply_update());
	}

	/**
	 * Gets active hostaddress.
	 *
	 * @param   integer  $p_obj_id
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 * @return  isys_component_dao_result
	 */
	public function get_active_ip_by_object_id($p_obj_id = NULL) {
		$l_sql = 'SELECT isys_catg_ip_list__id ' .
			'FROM isys_catg_ip_list ' .
			'WHERE isys_catg_ip_list__active = 1 ' .
			'AND isys_catg_ip_list__status = ' . C__RECORD_STATUS__NORMAL . ' ';

		if (!empty($p_obj_id)) {
			$l_sql .= ' AND isys_catg_ip_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id);
		} // function

		return $this->retrieve($l_sql);
	}

// function

	/**
	 * Gets primary hostaddress.
	 *
	 * @param   integer  $p_obj_id
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 * @return  isys_component_dao_result
	 */
	public function get_primary_ip_by_object_id($p_obj_id = NULL) {
		$l_sql = 'SELECT isys_catg_ip_list__id ' .
			'FROM isys_catg_ip_list ' .
			'WHERE isys_catg_ip_list__primary = 1 ' .
			'AND isys_catg_ip_list__status = ' . C__RECORD_STATUS__NORMAL . ' ';

		if (!empty($p_obj_id)) {
			$l_sql .= ' AND isys_catg_ip_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id);
		} // if

		return $this->retrieve($l_sql);
	} // function


	/**
	 * Calculates the next free ip.
	 *
	 * @param   integer  $p_net_obj_id object id of the net
	 * @param   integer  $p_assign_type_id ip assign type id
	 * @author  Van Quyen Hoang <qhoang@i-doit.de>
	 * @return  string
	 */
	public function get_free_ip ($p_net_obj_id, $p_assign_type_id)
	{
		$l_dao_ip_address = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_ip_addresses', $this->m_db);
		$l_used_ips_res = $l_dao_ip_address->get_data(null, $p_net_obj_id);

		$l_ip_free = false;

		while ($l_row = $l_used_ips_res->get_row())
		{
			// It is very necessary to check, if the server, which holds this IP (server, swicht, ...) has the status "normal".
			if ($this->get_object_status_by_id($l_row['isys_catg_ip_list__isys_obj__id']) == C__RECORD_STATUS__NORMAL && $l_row['isys_catg_ip_list__status'] == C__RECORD_STATUS__NORMAL)
			{
				$l_used_ips[$l_row['isys_cats_net_ip_addresses_list__title']] = true;
			} // if
		} // while

		$l_net_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net', $this->m_db);
		$l_dhcp_range_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_dhcp', $this->m_db);

		switch ($p_assign_type_id)
		{
			case C__CATP__IP__ASSIGN__UNNUMBERED:
				return '';
				break;

			case C__CATP__IP__ASSIGN__DHCP:
			case C__CATP__IP__ASSIGN__DHCP_RESERVED:
				if ($p_assign_type_id != C__CATP__IP__ASSIGN__DHCP)
				{
					$l_res = $l_dhcp_range_dao->get_data(
						null,
						$p_net_obj_id,
						" AND isys_net_dhcp_type__const = 'C__NET__DHCP_RESERVED' ",
						null,
						C__RECORD_STATUS__NORMAL);
				}
				else
				{
					$l_res = $l_dhcp_range_dao->get_data(
						null,
						$p_net_obj_id,
						" AND isys_net_dhcp_type__const = 'C__NET__DHCP_DYNAMIC' ",
						null,
						C__RECORD_STATUS__NORMAL);
				} // if

                while ($l_row = $l_res->get_row())
				{
					$l_range_from = $l_row['isys_cats_net_dhcp_list__range_from_long'];
					$l_range_to = $l_row['isys_cats_net_dhcp_list__range_to_long'];

					for ($i = $l_range_from; $i <= $l_range_to; $i++)
					{
						$l_ip_free = isys_helper_ip::long2ip($i);

						if (!isset($l_used_ips[$l_ip_free]))
						{
							return $l_ip_free;
						} // if
					} // for
				} // while

			// No break here, because we continue to get "the first free" IP-address if no DHCP ranges are set.
			default:
				$l_data = $l_net_dao->get_data(NULL, $p_net_obj_id)->get_row();

				$l_range_from = $l_data["isys_cats_net_list__address_range_from"];
				$l_range_to = $l_data["isys_cats_net_list__address_range_to"];

                if ($l_range_from && $l_range_to)
                {
                    $l_min = isys_helper_ip::ip2long($l_range_from);
                    $l_max = isys_helper_ip::ip2long($l_range_to);

                    // Iterate through ip address range.
                    for ($i = $l_min; $i <= $l_max; $i++)
                    {
                        $l_ip_free = isys_helper_ip::long2ip($i);

                        // Additionally we have to go sure to not slip into an DHCP area.
                        $l_inside_dhcp = (bool) $l_dhcp_range_dao->get_data(
                            null,
                            $p_net_obj_id,
                            " AND " . (int) $i . " BETWEEN isys_cats_net_dhcp_list__range_from_long AND isys_cats_net_dhcp_list__range_to_long",
                            null,
                            C__RECORD_STATUS__NORMAL)->num_rows();

                        if (!isset($l_used_ips[$l_ip_free]) && $l_inside_dhcp === false)
                        {
                            break;
                        } // if
                    } // for
                }

				break;
		} // switch

		return $l_ip_free;
	} // function


	/**
	 * With this method you can change the IP-assignment ID by giving an IP range as parameter.
	 *
	 * @param   integer  $p_net_id         The Layer3-Net object ID
	 * @param   integer  $p_ip_assignment  The new IP-assignment ID
	 * @param   string   $p_from
	 * @param   string   $p_to
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function update_ip_assignment_by_ip_range($p_net_id, $p_ip_assignment, $p_from, $p_to = null)
	{
		$l_net_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net', $this->m_db);
		$l_net_row = $l_net_dao->get_data(null, $p_net_id)->get_row();

		// This is a bugfix, because we don't update the IP assignments for IPv6 yet.
		if ($l_net_row['isys_cats_net_list__isys_net_type__id'] == C__CATS_NET_TYPE__IPV6)
		{
			return true;
		}

		$l_id = array();

		if (empty($p_from))
		{
			return false;
		} // if

		// If we only get one IP, we set the other one so we don't have to prepare two queries.
		if ($p_to === null || empty($p_to))
		{
			$p_to = $p_from;
		} // if

		$l_sql = 'SELECT isys_cats_net_ip_addresses_list__id FROM isys_cats_net_ip_addresses_list ' .
			'WHERE isys_cats_net_ip_addresses_list__isys_obj__id = ' . $this->convert_sql_int($p_net_id) . ' ' .
			'AND isys_cats_net_ip_addresses_list__ip_address_long BETWEEN ' .
			isys_helper_ip::ip2long($p_from) . ' AND ' . isys_helper_ip::ip2long($p_to) . ';';

		$l_res = $this->retrieve($l_sql);

		while ($l_row = $l_res->get_row())
		{
			$l_id[] = $l_row['isys_cats_net_ip_addresses_list__id'];
		} // while

		if (count($l_id) > 0)
		{
			$l_sql = 'UPDATE isys_catg_ip_list SET ' .
				'isys_catg_ip_list__isys_ip_assignment__id = ' . $this->convert_sql_int($p_ip_assignment) . ' ' .
				'WHERE isys_catg_ip_list__isys_cats_net_ip_addresses_list__id IN (' . implode(', ', $l_id) . ');';

			$this->update($l_sql);
			if ($this->apply_update())
			{
				return true;
			} // if
		} // if

		return false;
	} // function


	/**
	 * Inside this method, we set the given host-address as primary and all the others as non-primary.
	 *
	 * @param   integer  $p_catg_id
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 * @return  boolean
	 */
	public function update_primary_hostaddress($p_catg_id)
	{
		$l_sql = "SELECT isys_catg_ip_list__isys_obj__id FROM isys_catg_ip_list " .
			"WHERE isys_catg_ip_list__id = " . $this->convert_sql_int($p_catg_id) . ";";

		$l_obj_id = $this->retrieve($l_sql)->get_row_value('isys_catg_ip_list__isys_obj__id');

		$l_sql = "UPDATE isys_catg_ip_list SET " .
			"isys_catg_ip_list__primary = '0' " .
			"WHERE isys_catg_ip_list__isys_obj__id = " . $this->convert_sql_int($l_obj_id) . " " .
			"AND isys_catg_ip_list__id != " . $this->convert_sql_int($p_catg_id) . ";";

		return ($this->update($l_sql) && $this->apply_update());
	} // function


	/**
	 * Builds an array with minimal requirement for the sync function
	 *
	 * @param $p_data
	 * @return array
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function parse_import_array($p_data){

		return
			array(
				'data_id' => $p_data['data_id'],
				'properties' => array(
					'net_type' => array(
						'value' => $p_data['net_type']
					),
					'primary' => array(
						'value' => $p_data['primary']
					),
					'active' => array(
						'value' => $p_data['active']
					),
					'net' => array(
						'value' => $p_data['net']
					),
					'ipv4_assignment' => array(
						'value' => $p_data['ipv4_assignment']
					),
					'ipv4_address' => array(
						'value' => $p_data['ipv4_address']
					),
					'ipv6_assignment' => array(
						'value' => $p_data['ipv6_assignment']
					),
					'ipv6_address' => array(
						'value' => $p_data['ipv6_address']
					),
					'hostname' => array(
						'value' => $p_data['hostname']
					),
					'assigned_port' => array(
						'value' => $p_data['assigned_port']
					),
					'assigned_logical_port' => array(
						'value' => $p_data['assigned_logical_port']
					),
					'description' => array(
						'value' => $p_data['description']
					)
				)
			);
	} // function

	/**
	 * Reassigns an ip address to the specified net
	 *
	 * @param $p_ip_id
	 * @param $p_new_net_obj
	 * @return bool
	 */
	public function reassign_ip($p_object_id, $p_address, $p_type, $p_new_net_obj)
	{
		/**
		 * @var $l_dao_relation isys_cmdb_dao_category_g_relation
		 */
		$l_dao_relation = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->m_db);

		$l_res = $this->get_ip_info_by_address($p_address, $p_type);
		while($l_ip_data = $l_res->get_row()){
			$l_catg_id = $l_ip_data['isys_catg_ip_list__id'];
			$l_relation_id = $l_ip_data['isys_catg_ip_list__isys_catg_relation_list__id'];
			$l_cats_id = $l_ip_data['isys_cats_net_ip_addresses_list__id'];
			$l_obj_id = $l_ip_data['isys_catg_ip_list__isys_obj__id'];

			if($l_obj_id == $p_object_id) continue;

			$l_update = 'UPDATE isys_cats_net_ip_addresses_list SET '.
				'isys_cats_net_ip_addresses_list__isys_obj__id = '.$this->convert_sql_id($p_new_net_obj) . ' ' .
				'WHERE isys_cats_net_ip_addresses_list__id = '.$this->convert_sql_id($l_cats_id);

			if($this->update($l_update) && $this->apply_update())
			{
				$l_dao_relation->handle_relation(
					$l_catg_id,
					'isys_catg_ip_list',
					C__RELATION_TYPE__IP_ADDRESS,
					$l_relation_id,
					$p_new_net_obj,
					$l_obj_id
				);
			} // if
		} // while
	} // function

	public function get_ip_info_by_address($p_address, $p_type)
	{
		switch($p_type)
		{
			case C__CATS_NET_TYPE__IPV6:
				$l_condition = 'WHERE isys_cats_net_ip_addresses_list__title = '.$this->convert_sql_text(isys_helper_ip::validate_ipv6($p_address));
				break;
			case C__CATS_NET_TYPE__IPV4:
			default:
				$l_condition = 'WHERE isys_cats_net_ip_addresses_list__ip_address_long = '.$this->convert_sql_int(isys_helper_ip::ip2long($p_address));
				break;
		} // switch

		$l_sql = 'SELECT * FROM isys_cats_net_ip_addresses_list '.
			'INNER JOIN isys_catg_ip_list ON isys_catg_ip_list__isys_cats_net_ip_addresses_list__id = isys_cats_net_ip_addresses_list__id '.
			$l_condition;

		return $this->retrieve($l_sql);
	} // function


// ################################
// ### Functions for ipv4 START ###
// ################################


	/**
	 * Checks if the specified ip is in use.
	 *
	 * @param   integer  $p_net_obj_id
	 * @param   string   $p_ip_address
	 * @param   integer  $p_object_id
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 * @return  boolean
	 */
	public function ip_already_in_use($p_net_obj_id, $p_ip_address, $p_object_id = NULL)
	{
		$l_sql = "SELECT isys_cats_net_ip_addresses_list__id
			FROM isys_cats_net_ip_addresses_list
			LEFT JOIN isys_catg_ip_list ON isys_catg_ip_list__isys_cats_net_ip_addresses_list__id = isys_cats_net_ip_addresses_list__id
			LEFT JOIN isys_obj AS net ON net.isys_obj__id = isys_cats_net_ip_addresses_list__isys_obj__id
			LEFT JOIN isys_obj AS obj ON obj.isys_obj__id = isys_catg_ip_list__isys_obj__id
			WHERE isys_cats_net_ip_addresses_list__isys_obj__id = " . $this->convert_sql_id($p_net_obj_id) . "
			AND isys_cats_net_ip_addresses_list__title = " . $this->convert_sql_text($p_ip_address) . "
			AND (net.isys_obj__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . "
			AND isys_cats_net_ip_addresses_list__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . "
			AND isys_catg_ip_list__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . "
			AND obj.isys_obj__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . ')';

		if($p_object_id !== null)
		{
			$l_sql .= " AND isys_catg_ip_list__isys_obj__id != ".$this->convert_sql_id($p_object_id);
		} // if

		return ($this->retrieve($l_sql . ";")->num_rows() > 0);
	} // function


    /**
     * Calculates ip range.
     *
     * @deprecated
     * @param   string  $p_net_address
     * @param   string  $p_subnet_mask
     * @return  array
     * @author  Van Quyen Hoang <qhoang@synetics.de>
     * @todo    Wait until next release to remove, this is used in 0.9.9-9 migration.
     */
    public function calc_ip_range($p_net_address, $p_subnet_mask)
    {
	    return isys_helper_ip::calc_ip_range($p_net_address, $p_subnet_mask);
	} // function

// ################################
// ### Functions for ipv6 START ###
// ################################

	/**
	 * Gets next free ipv6 address from the specified net Object.
	 *
	 * @param   integer  $p_net_obj
	 * @param   string   $p_range_from
	 * @param   string   $p_range_to
	 * @return  mixed  string with free IP address or boolean false.
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 */
	public function get_free_ipv6($p_net_obj, $p_range_from = null, $p_range_to = null)
	{
		$l_dao_ip_list = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net_ip_addresses', $this->m_db);
		$l_dao_net = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_net', $this->m_db);

		$l_data = $l_dao_net->get_data(NULL, $p_net_obj)->get_row();
		$l_assigned_ip_list = $l_dao_ip_list->get_assigned_ips_as_array($p_net_obj);

		// When setted, we use the given FROM and TO values from the parameters.
		$l_range_from = ($p_range_from !== null) ? $p_range_from : $l_data['isys_cats_net_list__address_range_from'];
		$l_range_to = ($p_range_to !== null) ? $p_range_to : $l_data['isys_cats_net_list__address_range_to'];

		$l_cidr_suffix = $l_data['isys_cats_net_list__cidr_suffix'];

		$l_current_ip_arr = explode(':', $l_range_from);
		$l_counter = count($l_current_ip_arr) - 1;
		$l_found = false;
		$l_max_dec = hexdec('ffff');
		$l_dec = 0;

		if($l_cidr_suffix == 128){
			if(count($l_assigned_ip_list) > 0){
				return false;
			} else{
				return isys_helper_ip::validate_ipv6(implode(':', $l_current_ip_arr));
			}
		} else{
			while (!$l_found && $l_counter >= 0)
			{
				if ($l_current_ip_arr[$l_counter] != 'ffff')
				{
					while ($l_dec < $l_max_dec && !$l_found)
					{
						$l_current_ip = implode(':', $l_current_ip_arr);

						if (!in_array($l_current_ip, $l_assigned_ip_list))
						{
							$l_found = true;
							continue;
						} // if

						$l_dec = hexdec($l_current_ip_arr[$l_counter]);
						$l_dec = $l_dec + 1;
						$l_current_ip_arr[$l_counter] = dechex($l_dec);

						$l_hex_length = strlen($l_current_ip_arr[$l_counter]);
						$l_zeros = '';

						while ($l_hex_length < 4)
						{
							$l_zeros .= '0';
							$l_hex_length++;
						} // while

						$l_current_ip_arr[$l_counter] = $l_zeros . $l_current_ip_arr[$l_counter];
					} // while
				} // if

				$l_counter--;
			} // while

		}

		if ($l_found && isys_helper_ip::is_ipv6_in_range($l_current_ip, $l_range_from, $l_range_to))
		{
			return isys_helper_ip::validate_ipv6($l_current_ip);
		}
		else
		{
			return false;
		} // if
	} // function

    /**
     * SignalSlot-Method to guarantee unique ips
     *
     * @author Selcuk Kekec <skekec@synetics.de>
     * @param isys_cmdb_dao $p_cmdb_dao
     * @param type $p_direction
     * @param array $p_objectIDs
     */
    public function unique_handling(isys_cmdb_dao $p_cmdb_dao, $p_direction, array $p_objectIDs) {
        global $g_error;

        $l_ips = array();
        $l_dao = new self($p_cmdb_dao->get_database_component());

        /* ? Recycle-Mode ? */
        if ($p_direction == 2 && $_POST['cRecStatus'] == C__RECORD_STATUS__ARCHIVED && count($p_objectIDs)) {

            foreach ($p_objectIDs as $l_objectID) {
                $l_tmp = $l_dao->get_object($l_objectID)->get_row();
                $l_object_title = $l_tmp['isys_obj__title'];
                $l_data = $l_dao->get_data(NULL, $l_objectID, null, null, C__RECORD_STATUS__NORMAL);

                /* Do we have ip addresses to handle */
                if (count($l_data)) {
                    while ($l_row = $l_data->get_row()) {
                        /* Is this ip already in use */
                        $l_catLevel = $l_dao->in_use($l_row['isys_cats_net_ip_addresses_list__isys_obj__id'], /* Net */
                                                     $l_row['isys_cats_net_ip_addresses_list__title'], /* IP-Address */
                                                     $l_row['isys_catg_ip_list__id'], /* Catg-ID to ignore */
                                                     !isys_settings::get('cmdb.unique.ip-address')); /* GlobalNet ignore switch */

                        if ($l_catLevel) {
                            /* Here we have an ip that is detected as duplicate and needs special-handling */
                            $l_dao->update_catlevel($l_row['isys_catg_ip_list__id'], C__RECORD_STATUS__ARCHIVED);
                            $l_ips[$l_object_title][] = $l_row['isys_cats_net_ip_addresses_list__title'];
                        }
                    }
                }
            }

            if (count($l_ips)) {
                $l_strInfo = _L('LC__CMDB__UNIQUE__IPS__ARCHIVED_ENTRIES')."<br><br>";

                foreach ($l_ips AS $l_object_title => $l_dupeIPs) {
                    $l_strInfo .= "<b>".$l_object_title . '</b><br>';
                    $l_strInfo .= "<ul><li>".implode("</li><li>", $l_dupeIPs)."</li></ul>";
                }

                $g_error = $l_strInfo;
            }
        }
    }
} // class
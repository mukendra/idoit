<?php

/**
 * i-doit
 *
 * DAO: global category for applications.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Dennis Stuecken <dstuecken@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_application extends isys_cmdb_dao_category_global
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'application';

    /**
     * Is category multi-valued or single-valued?
     * @var  boolean
     */
    protected $m_multivalued = true;


	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function properties ()
	{
		return array(
			'application' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__APPLICATION_OBJ_APPLICATION',
						C__PROPERTY__INFO__DESCRIPTION => 'The application object'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_connection__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_connection',
							'isys_connection__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_OBJ_APPLICATION',
						C__PROPERTY__UI__PARAMS => array(
							'catFilter' => 'C__CATS__SERVICE;C__CATS__APPLICATION;C__CATS__LICENCE;C__CATS__DATABASE_SCHEMA;C__CATS__CLUSTER_SERVICE;C__CATS__DBMS;C__CATS__DATABASE_INSTANCE;C__CATS__MIDDLEWARE'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'connection'
						)
					)
				)),
			'assigned_license' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__LIC_ASSIGN__LICENSE',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned licence for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_cats_lic_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_lic_list',
							'isys_cats_lic_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__LIC_ASSIGN__LICENSE',
						C__PROPERTY__UI__PARAMS => array(
							isys_popup_browser_object_ng::C__CAT_FILTER => 'C__CATS__LICENCE',
							'secondSelection' => true,
							'secondList' => 'isys_cmdb_dao_category_s_lic::object_browser',
							'secondListFormat' => 'isys_cmdb_dao_category_s_lic::format_selection',
							'readOnly' => true
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_license'
						)
					)
				)),
			'assigned_database_schema' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__DATABASE_SCHEMA',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned database schema for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_catg_relation_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_database_access_list',
							'isys_cats_database_access_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_DATABASE_SCHEMATA',
						C__PROPERTY__UI__PARAMS => array(
							isys_popup_browser_object_ng::C__CAT_FILTER => 'C__CATS__DATABASE_SCHEMA',
							'p_strPopupType' => 'browser_object_ng',
							'p_strValue' => new isys_callback(array('isys_cmdb_dao_category_g_application', 'callback_property_assigned_database_schema')),
							'p_strSelectedID' => ''
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_database_schema'
						)
					)
				)),
			'assigned_it_service' => array_replace_recursive(isys_cmdb_dao_category_pattern::object_browser(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__IT_SERVICE',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned it service for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_catg_relation_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_its_components_list',
							'isys_catg_its_components_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_IT_SERVICE',
						C__PROPERTY__UI__PARAMS => array(
							isys_popup_browser_object_ng::C__CAT_FILTER => 'C__CATG__IT_SERVICE_RELATIONS;C__CATG__IT_SERVICE_COMPONENTS',
							'p_strSelectedID' => new isys_callback(array('isys_cmdb_dao_category_g_application', 'callback_property_assigned_it_service')),
							'multiselection' => true
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_it_service'
						)
					)
				)),
			'assigned_variant' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__APPLICATION_VARIANT__VARIANT',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned variant for the application assignment'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_cats_app_variant_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_app_variant_list',
							'isys_cats_app_variant_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_VARIANT__VARIANT',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_application', 'callback_property_assigned_variant'))
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => true,
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_property_assigned_variant'
						)
					)
				)),
			'bequest_nagios_services' => array_replace_recursive(isys_cmdb_dao_category_pattern::dialog(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__APPLICATION_BEQUEST_NAGIOS_SERVICES',
						C__PROPERTY__INFO__DESCRIPTION => 'Bequest nagios services'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__bequest_nagios_services'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_BEQUEST_NAGIOS_SERVICES',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => serialize(get_smarty_arr_YES_NO()),
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => 1
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_yes_or_no'
						)
					)
				)),
			'description' => array_replace_recursive(isys_cmdb_dao_category_pattern::commentary(), array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__description'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__APPLICATION
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				))
		);
	} // function

    /**
	 * Abstract method for retrieving the dynamic properties of every category dao.
	 *
	 * @author  Dennis Stuecken <dstuecken@i-doit.de>
	 * @return  array
	 */
	protected function dynamic_properties()
	{
		return array(
			'_variant' => array(
				C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__APPLICATION_VARIANT__VARIANT',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned variant for the application assignment'
                ),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						$this,
						'dynamic_property_collected_variants'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true
				)
			)
		);
	} // function

    /**
     * Used for displaying all variants
     * in our object lists
     *
     * @author Selcuk Kekec <skekec@i-doit.de>
     * @global type $g_comp_database
     * @param type $p_row
     * @return string HTML LIST
     */
    public function dynamic_property_collected_variants($p_row){
        global $g_comp_database;

        $l_strOut = "<ul><li>";
        $l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_application', $g_comp_database);
        $l_collected_variants = $l_dao->get_collected_variants($p_row['isys_obj__id']);

        if (is_array($l_collected_variants) && count($l_collected_variants))
		{
            $l_strOut .= implode('</li><li>', $l_collected_variants);
        } // if

        $l_strOut .= "</li></ul>";

        return $l_strOut;
    } // function

	/**
	 * Callback method for property assigned_it_service
	 *
	 * @param isys_request $p_request
	 * @return null|int
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function callback_property_assigned_it_service (isys_request $p_request)
	{
		global $g_comp_database;

		$l_return = null;
		$l_its_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_it_service_components', $g_comp_database);
		$l_data = $p_request->get_row();

		$l_sql = 'SELECT isys_catg_relation_list__isys_obj__id FROM isys_catg_relation_list WHERE isys_catg_relation_list__id = '.$l_its_dao->convert_sql_id($l_data['isys_catg_application_list__isys_catg_relation_list__id']);
		$l_rel_res = $l_its_dao->retrieve($l_sql);

		if($l_rel_res->num_rows() > 0)
		{
			$l_rel_data = $l_rel_res->get_row_value('isys_catg_relation_list__isys_obj__id');
			$l_its_res = $l_its_dao
						  ->get_data(null, null, "AND isys_connection__isys_obj__id = " . $l_its_dao->convert_sql_id($l_rel_data), null, C__RECORD_STATUS__NORMAL);
			while($l_its_data = $l_its_res->get_row())
			{
				$l_return[] = $l_its_data['isys_obj__id'];
			}
		} // if

		return $l_return;
	} // function

	/**
	 * Callback method for property assigned_database_schema
	 *
	 * @param isys_request $p_request
	 * @return null|int
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function callback_property_assigned_database_schema(isys_request $p_request)
	{
		global $g_comp_database;

		$l_return = null;
		$l_dbs_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_database_access', $g_comp_database);
		$l_data = $p_request->get_row();
		$l_sql = 'SELECT isys_catg_relation_list__isys_obj__id FROM isys_catg_relation_list WHERE isys_catg_relation_list__id = '.$l_dbs_dao->convert_sql_id($l_data['isys_catg_application_list__isys_catg_relation_list__id']);
		$l_rel_res = $l_dbs_dao->retrieve($l_sql);

		if($l_rel_res->num_rows() > 0)
		{
			$l_rel_data = $l_rel_res->get_row_value('isys_catg_relation_list__isys_obj__id');
			$l_dbs_data = $l_dbs_dao
						  ->get_data(null, null, "AND isys_connection__isys_obj__id = " . $l_dbs_dao->convert_sql_id($l_rel_data), null, C__RECORD_STATUS__NORMAL)
						  ->get_row();

			$l_return = $l_dbs_data['isys_obj__id'];
		} // if

		return $l_return;
	} // function

    /**
     * Get all available variants
     * used by a specific object
     *
     * @author Selcuk Kekec <skekec@i-doit.de>
     * @param type $p_object_id
     * @return array array(variant_id => variant_title, ...)
     */
    public function get_collected_variants($p_object_id) {
        $l_return = array();
		$l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_application', $this->m_db);

		$l_sql = 'SELECT * FROM isys_catg_application_list '.
                    "INNER JOIN isys_cats_app_variant_list ON isys_catg_application_list__isys_cats_app_variant_list__id = isys_cats_app_variant_list__id ".
                        "WHERE isys_catg_application_list__isys_obj__id  = ".$l_dao->convert_sql_id($p_object_id).";";
		$l_res = $l_dao->retrieve($l_sql);

		if (count($l_res) > 0)
		{
			while (($l_row = $l_res->get_row()))
			{
				$l_return[$l_row['isys_cats_app_variant_list__id']] = $l_row['isys_cats_app_variant_list__variant'];
			} // while
		} // if

		return $l_return;
    } // function


	/**
	 * Callback method for property assigned_variant.
	 *
	 * @param   isys_request  $p_request
	 * @return  string
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function callback_property_assigned_variant (isys_request $p_request)
	{
		global $g_comp_database;

		return isys_factory::get_instance('isys_cmdb_dao_category_g_application', $g_comp_database)
			->get_assigned_variant($p_request->get_category_data_id());
	} // function


	/**
	 * Gets all variants from the assigned application object.
	 *
	 * @param   integer  $p_cat_id
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_assigned_variant ($p_cat_id)
	{
		$l_return = array();
		$l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_application', $this->m_db);

		$l_sql = 'SELECT *
			FROM isys_cats_app_variant_list
			WHERE isys_cats_app_variant_list__isys_obj__id = (
				SELECT isys_connection__isys_obj__id FROM isys_catg_application_list
				INNER JOIN isys_connection ON isys_connection__id = isys_catg_application_list__isys_connection__id
				WHERE isys_catg_application_list__id = ' . $l_dao->convert_sql_id($p_cat_id) . '
			);';
		$l_res = $l_dao->retrieve($l_sql);

		if (count($l_res) > 0)
		{
			while (($l_row = $l_res->get_row()))
			{
				$l_return[$l_row['isys_cats_app_variant_list__id']] = $l_row['isys_cats_app_variant_list__variant'];
			} // while
		} // if

		return $l_return;
	} // function


    /**
     * Synchronizes properties from an import with the database.
     *
     * @param array $p_category_data Values of category data to be saved.
     * @param int $p_object_id Current object identifier (from database)
     * @param int $p_status Decision whether category data should be created or
     * just updated.
     *
     * @return mixed Returns category data identifier (int) on success, true
     * (bool) if nothing had to be done, otherwise false.
     */
	public function sync ($p_category_data, $p_object_id, $p_status)
	{
		assert('is_array($p_category_data) && count($p_category_data) > 0');
		assert('is_numeric($p_object_id) && $p_object_id >= 0');
		assert('is_numeric($p_status)');

		$this->m_sync_catg_data = $p_category_data;

		switch ($p_status)
		{
			case isys_import_handler_cmdb::C__CREATE:
				$p_category_data['data_id'] = $this->create(
					$p_object_id,
					C__RECORD_STATUS__NORMAL,
					$this->get_property('application'),
					$this->get_property('description'),
					$this->get_property('assigned_license'),
					$this->get_property('assigned_database_schema'),
					$this->get_property('assigned_it_service'),
					$this->get_property('assigned_variant'),
					$this->get_property('bequest_nagios_services'));

				if ($p_category_data['data_id'] === false)
				{
					return false;
				} // if
				break;

			case isys_import_handler_cmdb::C__UPDATE:
				$l_status = $this->save(
					$p_category_data['data_id'],
					C__RECORD_STATUS__NORMAL,
					$this->get_property('application'),
					$this->get_property('description'),
					$this->get_property('assigned_license'),
					$this->get_property('assigned_database_schema'),
					$this->get_property('assigned_it_service'),
					$this->get_property('assigned_variant'),
					$this->get_property('bequest_nagios_services'));

				if ($l_status === false)
				{
					return false;
				} // if
				break;

			default:
				return true;
		} // switch

		return $p_category_data['data_id'];
	} // function


	/**
	 * Return Category Data - Note: Cannot use generic method because of the second left join.
	 *
	 * @param   integer  $p_catg_list_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   array    $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_data($p_catg_list_id = null, $p_obj_id = null, $p_condition = "", $p_filter = null, $p_status = null)
	{
		$l_sql = 'SELECT * FROM isys_catg_application_list
			LEFT JOIN isys_connection ON isys_connection__id = isys_catg_application_list__isys_connection__id
			LEFT JOIN isys_obj ON isys_connection__isys_obj__id = isys_obj__id
			LEFT JOIN isys_obj_type ON isys_obj__isys_obj_type__id = isys_obj_type__id
			LEFT JOIN isys_cats_application_list ON isys_cats_application_list__isys_obj__id = isys_obj__id
			LEFT JOIN isys_application_manufacturer ON isys_cats_application_list__isys_application_manufacturer__id = isys_application_manufacturer__id
			LEFT JOIN isys_cats_app_variant_list ON isys_cats_app_variant_list__id = isys_catg_application_list__isys_cats_app_variant_list__id
			WHERE TRUE ' . $p_condition . ' ' . $this->prepare_filter($p_filter);

		if ($p_obj_id !== null)
		{
			$l_sql .= ' ' . $this->get_object_condition($p_obj_id);
		} // if

		if ($p_catg_list_id !== null)
		{
			$l_sql .= " AND isys_catg_application_list__id = " . $this->convert_sql_id($p_catg_list_id);
		} // if

		if ($p_status !== null)
		{
			$l_sql .= " AND isys_catg_application_list__status = " . $this->convert_sql_int($p_status);
		} // if

		return $this->retrieve($l_sql);
	} // function

	/**
	 * Return Category Data - Note: Cannot use generic method because of the second left join.
	 *
	 * @param   integer  $p_catg_list_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   array    $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_data_ng($p_catg_list_id = null, $p_obj_id = null, $p_condition = "", $p_filter = null, $p_status = null)
	{
		$l_sql = 'SELECT * FROM isys_catg_application_list
			INNER JOIN isys_obj ON isys_catg_application_list__isys_obj__id = isys_obj__id
			LEFT JOIN isys_connection ON isys_connection__id = isys_catg_application_list__isys_connection__id
			LEFT JOIN isys_cats_application_list ON isys_cats_application_list__isys_obj__id = isys_obj__id
			LEFT JOIN isys_cats_lic_list ON isys_catg_application_list__isys_cats_lic_list__id = isys_cats_lic_list__id
			LEFT JOIN isys_application_manufacturer ON isys_cats_application_list__isys_application_manufacturer__id = isys_application_manufacturer__id
			WHERE TRUE ' . $p_condition . ' ' . $this->prepare_filter($p_filter) . ' ';

		if ($p_obj_id !== null)
		{
			$l_sql .= ' ' . $this->get_object_condition($p_obj_id);
		} // if

		if ($p_catg_list_id !== null)
		{
			$l_sql .= "AND isys_catg_application_list__id = " . $this->convert_sql_id($p_catg_list_id) . " ";
		} // if

		if ($p_status !== null)
		{
			$l_sql .= "AND isys_catg_application_list__status = " . $this->convert_sql_int($p_status) . " ";
		} // if

		return $this->retrieve($l_sql);
	} // function


	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition ($p_obj_id = null)
	{
		if (!empty($p_obj_id))
		{
			if (is_array($p_obj_id))
			{
				return ' AND (isys_catg_application_list__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ') ';
			}
			else
			{
				return ' AND (isys_catg_application_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ') ';
			} // if
		} // if
	} // function


	/**
	 * @param $p_string
	 * @return bool|string
	 */
	public function parse_manufacturer ($p_string)
	{
		if (stristr($p_string, "windows"))
		{
			return "Microsoft";
		} // if

		if (stristr($p_string, ".net"))
		{
			return "Microsoft";
		} // if

		$l_manufacturer = array(
			"microsoft", "suse", "google",
			"novel", "vmware", "apple",
			"redhat", "mcaffee", "norton",
			"nullsoft", "synetics", "sap",
			"adobe", "Conexant", "ibm",
			"intel", "ati", "ericsson",
			"nokia", "blackberry"
		);

		if (preg_match("/^(" . implode("|", $l_manufacturer) . ").*?$/si", $p_string, $l_reg))
		{
			return $l_reg[1];
		} // if

		return false;
	} // function


	/**
	 * Import-Handler for this category
	 * @author Dennis Stuecken <dstuecken@i-doit.org>
	 */
	public function import ($p_data)
	{
		global $g_comp_registry;

		$l_ids = array();
		$l_logb_active = $g_comp_registry->__get("[Root]/Idoit/Constants/H_INVENTORY__LOGBOOK_ACTIVE");

		$l_dao_logb = new isys_module_logbook();
		$l_category_title = $this->get_category_by_const_as_string($this->get_category_const());

		$l_list_id = 0;

		if (count($p_data) > 0)
		{
			// Iterate through Applications.
			foreach ($p_data as $l_application)
			{
				verbose(".", false);

				// Create and check for application or operating system.
				if (!isset($l_application["type"]) && empty($l_application["type"]))
				{
					$l_application["type"] = C__OBJTYPE__APPLICATION;
				} // if

				$l_objid = $this->get_obj_id_by_title($l_application["name"], $l_application["type"], C__RECORD_STATUS__NORMAL);

				if (!$l_objid)
				{
					$l_objid = $this->insert_new_obj(
						$l_application["type"],
						false,
						$l_application["name"],
						ISYS_NULL,
						C__RECORD_STATUS__NORMAL
					);
				} // if

				$l_description = "";
				$l_install_path = null;
				$l_manufacturer = null;
				$l_release = null;

				// Get application version.
				if (isset($l_application["version"]) && $l_application["version"] != '')
				{
					$l_description = $l_application["name"] . "\n" . "Version: " . $l_application["version"] . "\n";
					$l_release = $l_application["version"];
				} // if

				// Get service pack (for microsoft operating systems).
				if (isset($l_application["servicepack"]) && $l_application["servicepack"] != '')
				{
					$l_description .= "Service Pack: " . $l_application["servicepack"] . "\n";
				} // if

				// Get manufacturer.
				if (($l_manufacturer = $this->parse_manufacturer($l_application["name"])))
				{
					$l_manufacturer = isys_import::check_dialog("isys_application_manufacturer", $l_manufacturer);
				} // if

				if (isset($l_application['installlocation']) && $l_application['installlocation'] != '')
				{
					$l_install_path = $l_application['installlocation'];
				} // if

				// Save those information into specific category application.
				$l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_application', $this->m_db);
				$l_data = $l_dao->get_data(null, $l_objid)->__to_array();

				if ($l_objid)
				{
					if($l_data['isys_cats_application_list__id'])
					{
						$l_dao->save(
							$l_data["isys_cats_application_list__id"],
							C__RECORD_STATUS__NORMAL,
							null,
							$l_manufacturer,
							$l_release,
							$l_description,
							null,
							null,
							$l_install_path
						);
					}
					else
					{
						$l_dao->create(
							$l_objid,
							C__RECORD_STATUS__NORMAL,
							null,
							$l_manufacturer,
							$l_release,
							$l_description,
							null,
							null,
							$l_install_path
						);
					}
				} // if

				// Get client's install location.
				if (isset($l_application["installlocation"]) && !empty($l_application["installlocation"]))
				{
					$l_description .= "Path: " . $l_application["installlocation"] . "\n";
				} // if

				// Create application connection.
				$this->create(
					$_GET[C__CMDB__GET__OBJECT],
					C__RECORD_STATUS__NORMAL,
					$l_objid,
					$l_description);

				if (isset($l_logb_active) && $l_logb_active)
				{
					$l_category_values[isys_import_handler_cmdb::C__PROPERTIES] = array('application' => array('value' => $l_objid));

					$l_changes[$l_category_title] = $l_dao_logb->prepare_changes($this, null, $l_category_values);

					if (count($l_changes) > 0)
					{
						$this->set_arrLogbookEntries($l_changes);
					} // if
				} // if

				$l_ids[] = $l_list_id;
			} // foreach
		} // if

		return $l_ids;
	} // function


	/**
	 * Return associated objects to given application object.
	 *
	 * @param   integer  $p_application_obj__id
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_assigned_objects ($p_application_obj__id, $p_status = C__RECORD_STATUS__NORMAL)
	{
		$l_sql = 'SELECT * FROM isys_catg_application_list
			INNER JOIN isys_connection ON isys_connection__id = isys_catg_application_list__isys_connection__id
			INNER JOIN isys_obj ON isys_catg_application_list__isys_obj__id = isys_obj__id
			INNER JOIN isys_obj_type ON isys_obj__isys_obj_type__id = isys_obj_type__id
			INNER JOIN isys_catg_relation_list ON isys_catg_relation_list__id = isys_catg_application_list__isys_catg_relation_list__id
			LEFT OUTER JOIN isys_catg_ip_list ON isys_catg_ip_list__isys_obj__id = isys_obj__id
			WHERE isys_connection__isys_obj__id = ' . $this->convert_sql_id($p_application_obj__id) . '
			' . $this->get_status_condition($p_status) . '
			GROUP BY isys_obj__id ORDER BY isys_obj__title;';

		return $this->retrieve($l_sql);
	} // function


	public function get_assigned_objects_and_relations($p_cat_id = null, $p_application_obj__id, $p_status = C__RECORD_STATUS__NORMAL, $p_condition=null) {

		$l_sql = "SELECT isys_catg_application_list__id,
						 main.isys_obj__id AS main_obj_id,
						 main.isys_obj__title AS main_obj_title,
                         main.isys_obj__status AS main_obj_status,
						 rel_object.isys_obj__id AS rel_obj_id,
						 rel_object.isys_obj__title AS rel_obj_title,
						 master.isys_obj__title as master_title,
						 slave.isys_obj__title as slave_title,
						 isys_catg_relation_list__isys_relation_type__id,
						 isys_cats_app_variant_list__variant ".

					"FROM isys_catg_application_list ".

					"INNER JOIN isys_connection ON ".
					"isys_connection__id = isys_catg_application_list__isys_connection__id ".

					"INNER JOIN isys_obj AS main ON ".
					"isys_catg_application_list__isys_obj__id = main.isys_obj__id ".

					"INNER JOIN isys_catg_relation_list ON ".
					"isys_catg_relation_list__id = isys_catg_application_list__isys_catg_relation_list__id ".

					"INNER JOIN isys_obj AS rel_object ON ".
					"isys_catg_relation_list__isys_obj__id = rel_object.isys_obj__id ".

					"INNER JOIN isys_obj AS master ON ".
					"isys_catg_relation_list__isys_obj__id__master = master.isys_obj__id ".

					"INNER JOIN isys_obj AS slave ON ".
					"isys_catg_relation_list__isys_obj__id__slave = slave.isys_obj__id ".

					"LEFT JOIN isys_cats_app_variant_list ON ".
					"isys_catg_application_list__isys_cats_app_variant_list__id = isys_cats_app_variant_list__id ".

					"WHERE isys_connection__isys_obj__id = '".$p_application_obj__id."' ";

		$l_sql .= "AND isys_catg_application_list__status = '".$p_status."' ";

		if(!empty($p_cat_id)){
			$l_sql .= "AND isys_catg_application_list__id = ".$this->convert_sql_id($p_cat_id);
		}

        if (!empty($p_condition)) {
            $l_sql .= " ".$p_condition;
        }

		return $this->retrieve($l_sql);
	}


	/**
	 *
	 * @param   integer  $p_objID
	 * @return  isys_component_dao_result
	 */
	public function get_applications($p_objID) {
		$l_sql = 'SELECT * FROM isys_catg_application_list
			INNER JOIN isys_connection ON isys_connection__id = isys_catg_application_list__isys_connection__id
			INNER JOIN isys_obj ON isys_connection__isys_obj__id = isys_obj__id
			WHERE isys_catg_application_list__isys_obj__id = ' . $this->convert_sql_id($p_objID) . '
			ORDER BY isys_obj__isys_obj_type__id;';

		return $this->retrieve($l_sql);
	}


	/**
	 * Save global category application element.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  &$p_intOldRecStatus
	 * @param   boolean  $p_create
	 * @throws  isys_exception_dao
	 * @return  int|null
	 * @author  Dennis Bluemer <dbluemer@i-doit.org>
	 */
	public function save_element(&$p_cat_level, &$p_intOldRecStatus, $p_create = false)
	{
		$l_intErrorCode = -1;

		if (isys_glob_get_param(C__CMDB__GET__CATLEVEL) == 0 &&
			isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW &&
			isys_glob_get_param(C__GET__NAVMODE) == C__NAVMODE__SAVE) {
			$p_create = true;
		}

		if ($p_create)
		{
			// Overview page and no input was given
			if (isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW && empty($_POST['C__CATG__APPLICATION_OBJ_APPLICATION__HIDDEN']))
			{
				return null;
			} // if

			$l_id = $this->create(
				$_GET[C__CMDB__GET__OBJECT],
				C__RECORD_STATUS__NORMAL,
				$_POST['C__CATG__APPLICATION_OBJ_APPLICATION__HIDDEN'],
				$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()],
				$_POST["C__CATG__LIC_ASSIGN__LICENSE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_DATABASE_SCHEMATA__HIDDEN"],
				$_POST["C__CATG__APPLICATION_IT_SERVICE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_VARIANT__VARIANT"],
				$_POST["C__CATG__APPLICATION_BEQUEST_NAGIOS_SERVICES"]
			);

			$this->m_strLogbookSQL = $this->get_last_query();

			if ($l_id)
			{
				$l_catdata['isys_catg_application_list__id'] = $l_id;
				$l_bRet = true;
				$p_cat_level = null;
			}
			else
			{
				throw new isys_exception_dao("Could not create category element application");
			} // if
		}
		else
		{
			$l_catdata = $this->get_general_data();
			$p_intOldRecStatus = $l_catdata["isys_catg_application_list__status"];

			$l_bRet = $this->save(
				$l_catdata['isys_catg_application_list__id'],
				C__RECORD_STATUS__NORMAL,
				$_POST['C__CATG__APPLICATION_OBJ_APPLICATION__HIDDEN'],
				$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()],
				$_POST["C__CATG__LIC_ASSIGN__LICENSE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_DATABASE_SCHEMATA__HIDDEN"],
				$_POST["C__CATG__APPLICATION_IT_SERVICE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_VARIANT__VARIANT"],
				$_POST["C__CATG__APPLICATION_BEQUEST_NAGIOS_SERVICES"]
			);

			$this->m_strLogbookSQL = $this->get_last_query();
		} // if

		if ($p_create)
		{
			return $l_catdata["isys_catg_application_list__id"];
		} // if

		return ($l_bRet == true) ? null : $l_intErrorCode;
	} // function

	/**
	 * Executes the query to save the category entry given by its ID $p_cat_level
	 *
	 * @param   int      $p_cat_level
	 * @param   int      $p_newRecStatus
	 * @param   int      $p_connectedObjID
	 * @param   String   $p_description
	 * @param            $p_licence
	 * @param            $p_database_schemata_obj
	 * @param            $p_it_service_obj
	 * @param   null     $p_variant
	 * @param   integer  $p_bequest_nagios_services
	 * @return  boolean true, if transaction executed successfully, else false
	 */
	public function save($p_cat_level, $p_newRecStatus, $p_connectedObjID, $p_description, $p_licence, $p_database_schemata_obj, $p_it_service_obj, $p_variant = null, $p_bequest_nagios_services = null)
	{
		$l_old_data = $this->get_data($p_cat_level)->get_row();

		// Update isys_connection
		$l_connection = new isys_cmdb_dao_connection($this->get_database_component());
		$l_connection->update_connection($l_old_data["isys_catg_application_list__isys_connection__id"], $p_connectedObjID);
		$p_it_service_obj = (is_array($p_it_service_obj))? $p_it_service_obj: trim($p_it_service_obj);

		if(isys_format_json::is_json_array($p_it_service_obj)){
			$p_it_service_obj = isys_format_json::decode($p_it_service_obj);
		} // if

		// Update software assignment
		$l_strSql = "UPDATE isys_catg_application_list SET ".
			"isys_catg_application_list__description					= ".$this->convert_sql_text($p_description).", ".
			"isys_catg_application_list__status 						= ".$this->convert_sql_id($p_newRecStatus).", ".
			"isys_catg_application_list__isys_cats_app_variant_list__id	= ".$this->convert_sql_id($p_variant) . ", " .
			"isys_catg_application_list__isys_cats_lic_list__id			= ".$this->convert_sql_id($p_licence) .", ".
			"isys_catg_application_list__bequest_nagios_services		= ".$this->convert_sql_boolean($p_bequest_nagios_services) ." ".
			"WHERE isys_catg_application_list__id 						= ".$this->convert_sql_id($p_cat_level);

		if ($this->update($l_strSql))
		{
			if($this->apply_update())
			{
				// Handle relation
				$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());
				$l_data = $this->get_data($p_cat_level)->__to_array();

				$l_relation_dao->handle_relation($p_cat_level, "isys_catg_application_list", C__RELATION_TYPE__SOFTWARE, $l_data["isys_catg_application_list__isys_catg_relation_list__id"], $l_data["isys_catg_application_list__isys_obj__id"], $p_connectedObjID);

				if($p_connectedObjID > 0){
					$l_data = $this->get_data($l_data["isys_catg_application_list__id"])->__to_array();

					if($l_data["isys_catg_application_list__isys_catg_relation_list__id"] != ""){
						$l_rel_data = $l_relation_dao->get_data($l_data["isys_catg_application_list__isys_catg_relation_list__id"])->__to_array();
						$l_dao_dbms_access = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_database_access', $this->get_database_component());
						$l_dao_its_comp = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_it_service_components', $this->get_database_component());

						if($p_database_schemata_obj > 0){
							$l_dbms_res = $l_dao_dbms_access->get_data(null, null, "AND isys_connection__isys_obj__id = ".$l_dao_dbms_access->convert_sql_id($l_rel_data["isys_catg_relation_list__isys_obj__id"]), null, C__RECORD_STATUS__NORMAL);
							if($l_dbms_res->num_rows() < 1){
								$l_dao_dbms_access->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
							} else{
								if($l_dao_dbms_access->delete_connection($l_rel_data["isys_catg_relation_list__isys_obj__id"])){
									$l_dao_dbms_access->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
								}
							}
						} else{
							$l_dao_dbms_access->delete_connection($l_rel_data["isys_catg_relation_list__isys_obj__id"]);
						}

						if(is_array($p_it_service_obj) && count($p_it_service_obj) > 0)
						{
							foreach($p_it_service_obj AS $l_it_serv_obj_id)
							{
								$l_it_service_res = $l_dao_its_comp->get_data(null, $l_it_serv_obj_id, "AND isys_connection__isys_obj__id = ".$l_dao_its_comp->convert_sql_id($l_rel_data["isys_catg_relation_list__isys_obj__id"]), null, C__RECORD_STATUS__NORMAL);

								if($l_it_service_res->num_rows() < 1){
									$l_dao_its_comp->create($l_it_serv_obj_id, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
								} else{
									if($l_dao_its_comp->remove_component($l_it_serv_obj_id, $l_rel_data["isys_catg_relation_list__isys_obj__id"])){
										$l_dao_its_comp->create($l_it_serv_obj_id, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
									}
								}
							}
						} else{
							$l_dao_its_comp->remove_component($p_it_service_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"]);
						}
					}
				}

				return true;
			} else{
				return false;
			}
		} else{
			return false;
		}

	}


	/**
	 * Executes the query to create the category entry for object referenced by $p_objID.
	 *
	 * @param   integer  $p_objID
	 * @param   integer  $p_newRecStatus
	 * @param   integer  $p_connectedObjID
	 * @param   string   $p_description
	 * @param   integer  $p_licence
	 * @param   integer  $p_database_schemata_obj
	 * @param   integer  $p_it_service_obj
	 * @param   integer  $p_variant
	 * @param   integer  $p_bequest_nagios_services
	 * @return  mixed  integer with the newly created ID on success, otherwise boolean false.
	 * @author  Dennis Bluemer <dbluemer@i-doit.org>
	 */
	public function create ($p_objID, $p_newRecStatus, $p_connectedObjID, $p_description, $p_licence = null, $p_database_schemata_obj = null, $p_it_service_obj = null, $p_variant = null, $p_bequest_nagios_services = 1)
	{
		$l_connection = isys_factory::get_instance('isys_cmdb_dao_connection', $this->m_db);

		$l_sql = "INSERT INTO isys_catg_application_list SET
			isys_catg_application_list__isys_connection__id = " . $this->convert_sql_id($l_connection->add_connection($p_connectedObjID)) . ",
			isys_catg_application_list__isys_obj__id = " . $this->convert_sql_id($p_objID) . ",
			isys_catg_application_list__description = " . $this->convert_sql_text($p_description) . ",
			isys_catg_application_list__status = " . $this->convert_sql_id($p_newRecStatus) . ",
			isys_catg_application_list__isys_cats_app_variant_list__id = " . $this->convert_sql_id($p_variant) . ",
			isys_catg_application_list__isys_cats_lic_list__id = " . $this->convert_sql_id($p_licence) . ",
			isys_catg_application_list__bequest_nagios_services = " . $this->convert_sql_boolean($p_bequest_nagios_services) . ";";

		if ($this->update($l_sql) && $this->apply_update())
		{
			$l_last_id = $this->get_last_insert_id();

			// Handle software relation.
			$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());
			$l_relation_dao->handle_relation(
				$l_last_id,
				"isys_catg_application_list",
				C__RELATION_TYPE__SOFTWARE,
				null,
				$p_objID,
				$p_connectedObjID);

			if ($p_connectedObjID > 0)
			{
				$l_data = $this->get_data($l_last_id)->get_row();

				if ($l_data["isys_catg_application_list__isys_catg_relation_list__id"] != "")
				{
					$l_rel_data = $l_relation_dao->get_data($l_data["isys_catg_application_list__isys_catg_relation_list__id"])->get_row();

					if ($p_database_schemata_obj > 0)
					{
						$l_dao_dbms_access = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_database_access', $this->get_database_component());
						$l_dao_dbms_access->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
					} // if

					if(isys_format_json::is_json_array($p_it_service_obj)){
						$p_it_service_obj = isys_format_json::decode($p_it_service_obj);
					} // if

					if (is_array($p_it_service_obj) && count($p_it_service_obj) > 0)
					{
						$l_dao_its_comp = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_it_service_components', $this->get_database_component());
						foreach($p_it_service_obj AS $l_it_serv_obj_id)
						{
							$l_dao_its_comp->create($l_it_serv_obj_id, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
						} // foreach
					} // if
				} // if
			} // if

			return $l_last_id;
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Set Status for category entry.
	 *
	 * @param   integer  $p_cat_id
	 * @param   integer  $p_status
	 * @return  boolean
	 */
	public function set_status($p_cat_id, $p_status)
	{
		$l_sql = 'UPDATE isys_catg_application_list SET isys_catg_application_list__status = ' . $this->convert_sql_id($p_status) . '
			WHERE isys_catg_application_list__id = ' . $this->convert_sql_id($p_cat_id) . ';';

		return ($this->update($l_sql) && $this->apply_update());
	} // function


	/**
	 * Deletes connection between application and object.
	 *
	 * @param   integer  $p_cat_level
	 * @return  boolean
	 * @throws  isys_exception_cmdb
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function delete ($p_cat_level)
	{

		$l_catdata = $this->get_data($p_cat_level)->get_row();

		isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component())
			->delete_relation($l_catdata["isys_catg_application_list__isys_catg_relation_list__id"]);

		$this->update('DELETE FROM isys_catg_application_list WHERE isys_catg_application_list__id = ' . $this->convert_sql_id($p_cat_level) . ';');

		if ($this->apply_update())
		{
			return true;
		}
		else
		{
			throw new isys_exception_cmdb("Could not delete id '". $p_cat_level . "' in table isys_catg_application_list.");
		} // if
	} // function


	/**
	 * Builds an array with minimal requirements for the sync function.
	 *
	 * @param   array  $p_data
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function parse_import_array ($p_data)
	{
		return array(
			'data_id' => $p_data['data_id'],
			'properties' => array(
				'application' => array(
					'value' => $p_data['application']
				),
				'assigned_license' => array(
					'value' => $p_data['assigned_license']
				),
				'description' => array(
					'value' => $p_data['description']
				)
			)
		);
	} // function
} // class
?>
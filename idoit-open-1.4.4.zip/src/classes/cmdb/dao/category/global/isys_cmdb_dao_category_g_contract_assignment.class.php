<?php

/**
 * i-doit
 * DAO: global category for contract assignments.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Van Quyen Hoang <qhoang@synetics.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_contract_assignment extends isys_cmdb_dao_category_global
{
	/**
	 * Category's name. Will be used for the identifier, constant, main table, and many more.
	 * @var  string
	 */
	protected $m_category = 'contract_assignment';

	/**
	 * Is category multi-valued or single-valued?
	 * @var  boolean
	 */
	protected $m_multivalued = true;


	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 */
	protected function properties()
	{
		return array(
			'connected_contract' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CONTRACT_ASSIGNMENT__CONNECTED_CONTRACT',
						C__PROPERTY__INFO__DESCRIPTION => 'Assigned contract'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_contract_assignment_list__isys_connection__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_connection',
							'isys_connection__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__CONTRACT_ASSIGNMENT__CONNECTED_CONTRACTS',
						C__PROPERTY__UI__PARAMS => array(
							'typeFilter' => 'C__OBJTYPE__MAINTENANCE'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'connection'
						)
					)
				)
			),
			'contract_start' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::date(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CONTRACT_ASSIGNMENT__CONTRACT_START',
						C__PROPERTY__INFO__DESCRIPTION => 'Contract begin'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_contract_assignment_list__contract_start'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_START'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			),
			'contract_end' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::date(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CONTRACT_ASSIGNMENT__CONTRACT_END',
						C__PROPERTY__INFO__DESCRIPTION => 'Contract end'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_contract_assignment_list__contract_end'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_END'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			),
			'reaction_rate' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog_plus(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__CONTRACT__REACTION_RATE',
						C__PROPERTY__INFO__DESCRIPTION => 'Reaction rate'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_contract_assignment_list__reaction_rate__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_contract_reaction_rate',
							'isys_contract_reaction_rate__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__CONTRACT_ASSIGNMENT__REACTION_RATE',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_contract_reaction_rate'
						)
					)
				)
			),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__LOGBOOK__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_contract_assignment_list__description'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__CONTRACT_ASSIGNMENT
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			)
		);
	} // function


	/**
	 * Method for retrieving the dynamic properties of this category.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function dynamic_properties()
	{
		return array(
			'_assigned_contract' => array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__CONTRACT_ASSIGNMENT',
					C__PROPERTY__INFO__DESCRIPTION => 'Contract assignment'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array($this, 'dynamic_property_callback_assigned_contract')
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true
				)
			)
		);
	} // function


	/**
	 * Dynamic property handling for getting the assigned contracts.
	 *
	 * @param   array  $p_row
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function dynamic_property_callback_assigned_contract ($p_row)
	{
		global $g_comp_database;

		$l_quickinfo = new isys_ajax_handler_quick_info();
		$l_contract_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_contract', $g_comp_database);
		$l_contract_res = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_contract_assignment', $g_comp_database)
			->get_data(null, $p_row['isys_obj__id'], '', null, C__RECORD_STATUS__NORMAL);

		if (count($l_contract_res) > 0)
		{
			$l_return = array();

			while ($l_contract_row = $l_contract_res->get_row())
			{
				if ($l_contract_row['isys_connection__isys_obj__id'] !== null && $l_contract_row['isys_connection__isys_obj__id'] > 0)
				{
				$l_contract = $l_contract_dao->get_data(null, $l_contract_row['isys_connection__isys_obj__id'])->get_row();

					if ($l_contract === false)
					{
						// This happenes, if the contract category is not filled.
						$l_contract_obj_row = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao', $g_comp_database)->get_object($l_contract_row['isys_connection__isys_obj__id'], true)->get_row();

				$l_return[] = $l_quickinfo->get_quick_info(
							$l_contract_obj_row['isys_obj__id'],
							_L($l_contract_obj_row['isys_obj_type__title']) . ' &raquo; ' . $l_contract_obj_row['isys_obj__title'],
							C__LINK__OBJECT);
					}
					else
					{
						$l_return[] = $l_quickinfo->get_quick_info(
					$l_contract['isys_obj__id'],
					_L($l_contract_dao->get_objtype_name_by_id_as_string($l_contract['isys_obj__isys_obj_type__id'])) . ' &raquo; ' . $l_contract['isys_obj__title'] . ' (' . _L($l_contract['isys_contract_type__title']) . ')',
					C__LINK__OBJECT);
					} // if
				} // if
			} // while

			return '<ul><li>' . implode('</li><li>', $l_return) . '</li></ul>';
		} // if

		return C__GUI_VALUE__NA;
	} // function


	/**
	 * Return Category Data.
	 *
	 * @param   integer  $p_catg_list_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   string   $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_data($p_catg_list_id = null, $p_obj_id = null, $p_condition = "", $p_filter = null, $p_status = null)
	{
		$l_sql = 'SELECT * FROM isys_catg_contract_assignment_list
			INNER JOIN isys_obj ON isys_catg_contract_assignment_list__isys_obj__id = isys_obj__id
			LEFT JOIN isys_connection ON isys_connection__id = isys_catg_contract_assignment_list.isys_catg_contract_assignment_list__isys_connection__id
			LEFT JOIN isys_cats_contract_list ON isys_cats_contract_list__isys_obj__id = isys_connection__isys_obj__id
			WHERE TRUE ' . $p_condition . ' ' . $this->prepare_filter($p_filter);

		if ($p_obj_id !== null)
		{
			$l_sql .= $this->get_object_condition($p_obj_id);
		} // if

		if ($p_catg_list_id !== null)
		{
			$l_sql .= ' AND isys_catg_contract_assignment_list__id = ' . $this->convert_sql_id($p_catg_list_id);
		} // if

		if ($p_status !== null)
		{
			$l_sql .= ' AND isys_catg_contract_assignment_list__status = ' . $this->convert_sql_int($p_status);
		} // if

		return $this->retrieve($l_sql);
	} // function


	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition($p_obj_id = null){
		$l_sql = '';

		if (!empty($p_obj_id)) {
			if(is_array($p_obj_id)){
				$l_sql = ' AND (isys_catg_contract_assignment_list__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ') ';
			} else{
				$l_sql = ' AND (isys_catg_contract_assignment_list__isys_obj__id = '.$this->convert_sql_id($p_obj_id).') ';
			}
		}
		return $l_sql;
	}

	/**
	 * Synchronizes properties from an import with the database.
	 *
	 * @param   array    $p_category_data  Values of category data to be saved.
	 * @param   integer  $p_object_id      Current object identifier (from database)
	 * @param   integer  $p_status         Decision whether category data should be created or just updated.
	 * @return  mixed  Returns category data identifier (int) on success, true (bool) if nothing had to be done, otherwise false.
	 */
	public function sync($p_category_data, $p_object_id, $p_status)
	{
		assert('is_array($p_category_data) && count($p_category_data) > 0');
		assert('is_numeric($p_object_id) && $p_object_id >= 0');
		assert('is_numeric($p_status)');
		$this->m_sync_catg_data = $p_category_data;
		$l_indicator = false;

		switch ($p_status)
		{
			case isys_import_handler_cmdb::C__CREATE:
				if (($p_category_data['data_id'] = $this->create(
					$p_object_id,
					C__RECORD_STATUS__NORMAL,
					$this->get_property('contract_start'),
					$this->get_property('contract_end'),
					$this->get_property('connected_contract'),
					$this->get_property('description'),
					$this->get_property('reaction_rate')))
				)
				{
					$l_indicator = true;
				}
				break;
			case isys_import_handler_cmdb::C__UPDATE:
				$l_indicator = $this->save(
					$p_category_data['data_id'],
					C__RECORD_STATUS__NORMAL,
					$this->get_property('contract_start'),
					$this->get_property('contract_end'),
					$this->get_property('contract_number'),
					$this->get_property('connected_contract'),
					$this->get_property('description'),
					$this->get_property('reaction_rate')
				);
				break;
		}

		return ($l_indicator === true) ? $p_category_data['data_id'] : false;
	} // function


	/**
	 * Save global category contract assignment.
	 *
	 * @param    integer  $p_cat_level
	 * @param    integer  & $p_intOldRecStatus
	 * @return   mixed
	 * @version  Van Quyen Hoang <qhoang@synetics.org>
	 */
	public function save_element(&$p_cat_level, &$p_intOldRecStatus)
	{
		if ($_GET[C__CMDB__GET__CATLEVEL] != - 1 && $_GET[C__CMDB__GET__CATLEVEL] > 0)
		{
			$l_ret = $this->save(
				$_GET[C__CMDB__GET__CATLEVEL],
				$p_intOldRecStatus,
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_START__HIDDEN'],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_END__HIDDEN'],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONNECTED_CONTRACTS__HIDDEN'],
				$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__REACTION_RATE']
			);
		}
		else
		{
			$l_ret = $this->create(
				$_GET[C__CMDB__GET__OBJECT],
				C__RECORD_STATUS__NORMAL,
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_START__HIDDEN'],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONTRACT_END__HIDDEN'],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__CONNECTED_CONTRACTS__HIDDEN'],
				$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()],
				$_POST['C__CATG__CONTRACT_ASSIGNMENT__REACTION_RATE']
			);
			$p_cat_level = - 1;
		} // if

		return $l_ret;
	} // function


	/**
	 * Creates new category entry.
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_rec_status
	 * @param   null     $p_contract_start
	 * @param   null     $p_contract_end
	 * @param   integer  $p_connected_contract
	 * @param   string   $p_description
	 * @return  mixed
	 */
	public function create($p_obj_id, $p_rec_status = C__RECORD_STATUS__NORMAL, $p_contract_start = null, $p_contract_end = null, $p_connected_contract = null, $p_description = '', $p_reaction_rate = null)
	{
		$l_dao_connection = new isys_cmdb_dao_connection($this->m_db);

		$l_sql = 'INSERT INTO isys_catg_contract_assignment_list (
				isys_catg_contract_assignment_list__isys_obj__id,
				isys_catg_contract_assignment_list__contract_start,
				isys_catg_contract_assignment_list__contract_end,
				isys_catg_contract_assignment_list__isys_connection__id,
				isys_catg_contract_assignment_list__reaction_rate__id,
				isys_catg_contract_assignment_list__description,
				isys_catg_contract_assignment_list__status) ' .
			'VALUES( ' .
			$this->convert_sql_id($p_obj_id) . ', ' .
			$this->convert_sql_datetime($p_contract_start) . ', ' .
			$this->convert_sql_datetime($p_contract_end) . ', ' .
			$this->convert_sql_id($l_dao_connection->add_connection($p_connected_contract)) . ', ' .
			$this->convert_sql_id($p_reaction_rate) . ', ' .
			$this->convert_sql_text($p_description) . ', ' .
			$this->convert_sql_int($p_rec_status) .
			')';

		if ($this->update($l_sql) && $this->apply_update())
		{
			$l_id = $this->get_last_insert_id();
			/* Create implicit relation */
			$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->m_db);
			$l_relation_dao->handle_relation($l_id, "isys_catg_contract_assignment_list", C__RELATION_TYPE__CONTRACT, null, $p_connected_contract, $p_obj_id);
			return $l_id;
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Updates existing category entry.
	 *
	 * @param   integer  $p_cat_id
	 * @param   integer  $p_rec_status
	 * @param   null     $p_contract_start
	 * @param   null     $p_contract_end
	 * @param   integer  $p_connected_contract
	 * @param   string   $p_description
	 * @return  boolean
	 */
	public function save($p_cat_id, $p_rec_status = C__RECORD_STATUS__NORMAL, $p_contract_start = null, $p_contract_end = null, $p_connected_contract = null, $p_description = '', $p_reaction_rate = null)
	{
		$l_dao_connection = new isys_cmdb_dao_connection($this->m_db);
		$l_sql = 'SELECT isys_catg_contract_assignment_list__isys_obj__id,
					isys_catg_contract_assignment_list__isys_connection__id,
					isys_catg_contract_assignment_list__isys_catg_relation_list__id FROM isys_catg_contract_assignment_list ' .
			'WHERE isys_catg_contract_assignment_list__id = ' . $this->convert_sql_id($p_cat_id);
		$l_catdata = $this->retrieve($l_sql)->get_row();
		$l_connection_id = $l_catdata['isys_catg_contract_assignment_list__isys_connection__id'];

		if (empty($l_connection_id))
		{
			$l_connection_id = $l_dao_connection->add_connection($p_connected_contract);
		}
		else
		{
			$l_dao_connection->update_connection($l_connection_id, $p_connected_contract);
		} // if

		$l_sql = 'UPDATE isys_catg_contract_assignment_list ' .
			'SET ' .
			'isys_catg_contract_assignment_list__contract_start = ' . $this->convert_sql_datetime($p_contract_start) . ', ' .
			'isys_catg_contract_assignment_list__contract_end = ' . $this->convert_sql_datetime($p_contract_end) . ', ' .
			'isys_catg_contract_assignment_list__isys_connection__id = ' . $this->convert_sql_id($l_connection_id) . ', ' .
			'isys_catg_contract_assignment_list__reaction_rate__id = ' . $this->convert_sql_id($p_reaction_rate) . ', ' .
			'isys_catg_contract_assignment_list__description = ' . $this->convert_sql_text($p_description) . ' ' .
			'WHERE isys_catg_contract_assignment_list__id = ' . $this->convert_sql_id($p_cat_id);

		if ($this->update($l_sql) && $this->apply_update())
		{
			$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->m_db);
			$l_relation_dao->handle_relation($p_cat_id, "isys_catg_contract_assignment_list", C__RELATION_TYPE__CONTRACT, $l_catdata['isys_catg_contract_assignment_list__isys_catg_relation_list__id'], $p_connected_contract, $l_catdata['isys_catg_contract_assignment_list__isys_obj__id']);
			return true;
		}
		else
		{
			return false;
		} // if
	} // function
} // class
?>
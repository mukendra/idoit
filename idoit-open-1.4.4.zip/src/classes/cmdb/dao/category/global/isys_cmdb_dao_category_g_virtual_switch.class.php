<?php

/**
 * i-doit
 *
 * DAO: global category for virtual switches
 *
 * @package i-doit
 * @subpackage CMDB_Categories
 * @author Dennis Bluemer <dbluemer@i-doit.org>
 * @copyright synetics GmbH
 * @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_virtual_switch
    extends isys_cmdb_dao_category_global {

    /**
     * Category's name. Will be used for the identifier, constant, main table,
     * and many more.
     *
     * @var string
     */
    protected $m_category = 'virtual_switch';

    /**
     * Is category multi-valued or single-valued?
     *
     * @var bool
     */
    protected $m_multivalued = true;

    /**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 */
	protected function properties()
	{
		return array(
			'title' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__TITLE',
						C__PROPERTY__INFO__DESCRIPTION => 'Title'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_switch_list__title'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VSWITCH_TITLE'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)),
			'ports' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__VIRTUAL_SWITCH__PORTS',
						C__PROPERTY__INFO__DESCRIPTION => 'assigned ports'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_switch_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_virtual_switch_2_port',
							'isys_virtual_switch_2_port__isys_catg_virtual_switch_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VSWITCH_PORTS',
						C__PROPERTY__UI__PLACEHOLDER => 'LC__CMDB__CATG__VIRTUAL_SWITCH__PORTS_PLACEHOLDER',
						C__PROPERTY__UI__EMPTYMESSAGE => 'LC__CMDB__CATG__VIRTUAL_SWITCH__PORTS_EMPTY',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_virtual_switch', 'callback_property_ports')),
							'p_bDbFieldNN' => 1,
							'p_bLinklist' => 1,
							'tab' => 20
						)
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'ports'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)),
			'portgroup' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__VSWITCH__PORT_GROUPS',
						C__PROPERTY__INFO__DESCRIPTION => 'assigned portgroups'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_virtual_port_group__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_virtual_port_group',
							'isys_virtual_port_group__isys_catg_virtual_switch_list__id'
						)
					),
					// How the heck can we assign the values to the UI???
					/*C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VSWITCH_PORTS',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_virtual_switch', '')),
							'p_bDbFieldNN' => 1,
							'p_bLinklist' => 1,
							'tab' => 20
						)
					),*/
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'portgroups'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			),
			'serviceconsoleports' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__VSWITCH__SERVICE_CONSOLE_PORTS',
						C__PROPERTY__INFO__DESCRIPTION => 'assigned service console ports'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_service_console_port__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_service_console_port',
							'isys_service_console_port__isys_catg_virtual_switch_list__id'
						)
					),
					// How the heck can we assign the values to the UI???
					/*C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VSWITCH_PORTS',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_virtual_switch', '')),
							'p_bDbFieldNN' => 1,
							'p_bLinklist' => 1,
							'tab' => 20
						)
					),*/
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'serviceconsoleports'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			),
			'vmkernelports' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__VSWITCH__VMKERNEL_PORTS',
						C__PROPERTY__INFO__DESCRIPTION => 'assigned vmkernel ports'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_vmkernel_port__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_vmkernel_port',
							'isys_vmkernel_port__isys_catg_virtual_switch_list__id'
						)
					),
					// How the heck can we assign the values to the UI???
					/*C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__VSWITCH_PORTS',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_g_virtual_switch', '')),
							'p_bDbFieldNN' => 1,
							'p_bLinklist' => 1,
							'tab' => 20
						)
					),*/
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'vmkernelports'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				)
			),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'categories description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_virtual_switch_list__description',
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__VIRTUAL_SWITCH,
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				))
		);
	} // function

	/**
	 * Callback method for the ports dialog-field.
	 *
	 * @param   isys_request  $p_request
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@synetics.de>
	 */
	public function callback_property_ports(isys_request $p_request)
	{
		$l_obj_id = $p_request->get_object_id();

		$l_res = $this->get_ports($l_obj_id);

		while($l_row = $l_res->get_row()){
			$l_return[$l_row['isys_catg_port_list__id']] = $l_row['isys_catg_port_list__title'];
		}

		return $l_return;
	} // function

    /**
     * Synchronizes properties from an import with the database.
     *
     * @param array $p_category_data Values of category data to be saved.
     * @param int $p_object_id Current object identifier (from database)
     * @param int $p_status Decision whether category data should be created or
     * just updated.
     *
     * @return mixed Returns category data identifier (int) on success, true
     * (bool) if nothing had to be done, otherwise false.
     */
    public function sync($p_category_data, $p_object_id, $p_status) {
        assert('is_array($p_category_data) && count($p_category_data) > 0');
        assert('is_numeric($p_object_id) && $p_object_id >= 0');
        assert('is_numeric($p_status)');
        $this->m_sync_catg_data = $p_category_data;
        $l_indicator = FALSE;

        switch ($p_status) {
            case isys_import_handler_cmdb::C__CREATE:
                if (($p_category_data['data_id'] = $this->create($p_object_id, C__RECORD_STATUS__NORMAL,
					$this->get_property('title'), $this->get_property('description'))))
				{
                    $l_indicator = TRUE;

                    $l_ports = $this->get_property('ports');
                    $this->attach_ports($p_category_data['data_id'], $l_ports);

                    $l_port_groups = $this->get_property('portgroup');
                    $this->attach_port_groups($p_category_data['data_id'], $l_port_groups);

                    $l_serviceconsoleports = $this->get_property('serviceconsoleports');
                	$this->attach_service_console_ports($p_category_data['data_id'], $l_serviceconsoleports);

                	$l_vmkernelports = $this->get_property('vmkernelports');
                	$this->attach_vmkernel_ports($p_category_data['data_id'], $l_vmkernelports);
                }
                break;
            case isys_import_handler_cmdb::C__UPDATE:
                $l_indicator = $this->save($p_category_data['data_id'], C__RECORD_STATUS__NORMAL, $this->get_property('title'), $this->get_property('description'));

                $l_ports = $this->get_property('ports');
                $this->attach_ports($p_category_data['data_id'], $l_ports);

                $l_port_groups = $this->get_property('portgroup');
                $this->attach_port_groups($p_category_data['data_id'], $l_port_groups);

                $l_serviceconsoleports = $this->get_property('serviceconsoleports');
                $this->attach_service_console_ports($p_category_data['data_id'], $l_serviceconsoleports);

                $l_vmkernelports = $this->get_property('vmkernelports');
                $this->attach_vmkernel_ports($p_category_data['data_id'], $l_vmkernelports);

                break;
        } // switch
        return ($l_indicator === TRUE) ? $p_category_data['data_id'] : FALSE;
    } // function

	/**
     * Fetches category's data from database.
     *
     * @param int $p_catg_list_id (optional) List's identifier
     * @param int $p_obj_id (optional) Object's identifier
     * @param string $p_condition (optional) Condition
     * @param mixed $p_filter (optional) Filter string or array
     * @param int $p_status (optional) Status
     *
     * @return isys_component_dao_result
     */
	public function get_data($p_catg_list_id=null, $p_obj_id=null, $p_condition='', $p_filter=null, $p_status=null) {
		$p_condition .= $this->prepare_filter($p_filter);

		$l_sql = "SELECT * FROM isys_catg_virtual_switch_list ".
					"INNER JOIN isys_obj ON ".
						"isys_obj__id = ".
						"isys_catg_virtual_switch_list__isys_obj__id ".
				 	"WHERE TRUE ";

		$l_sql .= $p_condition;

		if (!empty($p_obj_id))
		{
			$l_sql .= $this->get_object_condition($p_obj_id);
		} // if

		if (!empty($p_catg_list_id))
		{
			$l_sql .= " AND (isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_catg_list_id).")";
		} // if

		if (!empty($p_status))
		{
			$l_sql .= " AND (isys_catg_virtual_switch_list__status = '{$p_status}')";
		} // if

		return $this->retrieve($l_sql);
	}

	/**
     * Fetches information about the service console ports from database.
     *
     * @param int $p_vswitchID Virtual switch's identifier
     *
     * @return isys_component_dao_result
     */
	public function get_service_console_ports($p_vswitchID) {
		$l_query = "SELECT * FROM isys_service_console_port ".
				   "LEFT JOIN isys_catg_ip_list ON isys_catg_ip_list__id = isys_service_console_port__isys_catg_ip_list__id ".
				   "LEFT JOIN isys_cats_net_ip_addresses_list ON isys_cats_net_ip_addresses_list__id = isys_catg_ip_list__isys_cats_net_ip_addresses_list__id ".
				   "WHERE isys_service_console_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_vswitchID);

		return $this->retrieve($l_query);
	}


	public function get_vmkernel_ports($p_vswitchID) {
		$l_query = "SELECT * FROM isys_vmkernel_port ".
				   "LEFT JOIN isys_catg_ip_list ON isys_catg_ip_list__id = isys_vmkernel_port__isys_catg_ip_list__id ".
				   "LEFT JOIN isys_cats_net_ip_addresses_list ON isys_cats_net_ip_addresses_list__id = isys_catg_ip_list__isys_cats_net_ip_addresses_list__id ".
				   "WHERE isys_vmkernel_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_vswitchID);

		return $this->retrieve($l_query);
	}


	public function get_port_groups($p_vswitchID) {
		$l_query = "SELECT * FROM isys_virtual_port_group ".
				   "WHERE isys_virtual_port_group__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_vswitchID);

		return $this->retrieve($l_query);
	}


	public function attach_ports($p_catlevel, $p_arPorts) {
		$l_update = "DELETE FROM isys_virtual_switch_2_port WHERE ".
					"isys_virtual_switch_2_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_catlevel);

		if (!$this->update($l_update))
			return false;

		if (count($p_arPorts) == 0)
			return true;

		$l_update = "INSERT INTO isys_virtual_switch_2_port ".
					"(isys_virtual_switch_2_port__isys_catg_virtual_switch_list__id, ".
					"isys_virtual_switch_2_port__isys_catg_port_list__id) ".
					"VALUES ";
		$l_is_correct = false;
		foreach ($p_arPorts as $l_port)
		{
			if($l_port)
			{
				$l_update .= '('.$this->convert_sql_id($p_catlevel).", ".$this->convert_sql_id($l_port).'), ';
				$l_is_correct = true;
			} // if
		} // foreach

		$l_update = rtrim($l_update, ", ");

		if(!$l_is_correct)
			return false;

		if (!$this->update($l_update))
			return false;

		return true;
	} // function


	public function attach_service_console_ports($p_catlevel, $p_scps) {
		$l_update = "DELETE FROM isys_service_console_port WHERE ".
					"isys_service_console_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_catlevel);

		if (!$this->update($l_update))
			return false;

		if (count($p_scps) == 0)
			return true;

		$l_update = "INSERT INTO isys_service_console_port ".
					"(isys_service_console_port__isys_catg_virtual_switch_list__id, ".
					"isys_service_console_port__isys_catg_ip_list__id, ".
					"isys_service_console_port__title) ".
					"VALUES ";
		$l_exe = false;
		foreach ($p_scps as $l_scp)
		{
			if(!empty($l_scp[1]) && $l_scp[1] > 0)
			{
				$l_update .= '('.$this->convert_sql_id($p_catlevel).', '.
								 $this->convert_sql_id($l_scp[1]).', '.
								 $this->convert_sql_text($l_scp[0]).'), ';
				$l_exe = true;
			} // if
		} // foreach

		if(!$l_exe)
			return false;

		$l_update = rtrim($l_update, ", ");

		if (!$this->update($l_update))
			return false;

		return true;
	} // function


	public function attach_vmkernel_ports($p_catlevel, $p_vmks) {
		$l_update = "DELETE FROM isys_vmkernel_port WHERE ".
					"isys_vmkernel_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_catlevel);

		if (!$this->update($l_update))
			return false;

		if (count($p_vmks) == 0)
			return true;

		$l_update = "INSERT INTO isys_vmkernel_port ".
					"(isys_vmkernel_port__isys_catg_virtual_switch_list__id, ".
					"isys_vmkernel_port__isys_catg_ip_list__id, ".
					"isys_vmkernel_port__title) ".
					"VALUES ";
		$l_exe = false;
		foreach ($p_vmks as $l_vmk)
		{
			if(!empty($l_vmk[1]) && $l_vmk[1] > 0)
			{
				$l_update .= "(".$this->convert_sql_id($p_catlevel).", ".
								 $this->convert_sql_id($l_vmk[1]).", ".
								 $this->convert_sql_text($l_vmk[0])."), ";
				$l_exe = true;
			} // if
		} // foreach

		if(!$l_exe)
			return false;

		$l_update = rtrim($l_update, ", ");

		if (!$this->update($l_update))
			return false;

		return true;
	} // function


	public function attach_port_groups($p_catlevel, $p_pgs) {
		$l_update = "DELETE FROM isys_virtual_port_group WHERE ".
					"isys_virtual_port_group__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_catlevel);

		if (!$this->update($l_update))
			return false;

		if (count($p_pgs) == 0)
			return true;

		$l_update = "INSERT INTO isys_virtual_port_group ".
					"(isys_virtual_port_group__isys_catg_virtual_switch_list__id, ".
					"isys_virtual_port_group__title, ".
					"isys_virtual_port_group__vlanid) ".
					"VALUES ";
		$l_exe = false;
		foreach ($p_pgs as $l_vmk)
		{
			if(!empty($l_vmk[0]))
			{
				$l_update .= "(".$this->convert_sql_id($p_catlevel).", ".
								 $this->convert_sql_text($l_vmk[0]).", ".
								 $this->convert_sql_text($l_vmk[1])."), ";
				$l_exe = true;
			} // if
		} // foreach

		if(!$l_exe)
			return false;

		$l_update = rtrim($l_update, ", ");

		if (!$this->update($l_update))
			return false;

		return true;
	} // function


	public function save_element(&$p_cat_level, &$p_intOldRecStatus) {
		$l_post_keys = array_keys($_POST);

		if (!empty($_POST['C__CATG__VSWITCH_PORTS__selected_values']))
			$l_ports = explode(',', $_POST['C__CATG__VSWITCH_PORTS__selected_values']);
		else
			$l_ports = array();


		$l_arPG = array();
		for ($i=0; $i<count($_POST); $i++)
		{
			if (strpos($l_post_keys[$i], 'C__CATG__VSWITCH_PG_NAME_') !== false)
			{
				$l_arPG[] = array($_POST[$l_post_keys[$i]],
								  $_POST[substr($l_post_keys[$i], 0, -6).'VLANID'.substr($l_post_keys[$i], strrpos($l_post_keys[$i], '_'))]);
			} // if
		} // for


		$l_arSCP = array();
		for ($i=0; $i<count($_POST); $i++)
		{
			if (strpos($l_post_keys[$i], 'C__CATG__VSWITCH_SCP_NAME_') !== false)
			{
				$l_arSCP[] = array($_POST[$l_post_keys[$i]],
								   $_POST[substr($l_post_keys[$i], 0, -6).'ADDRESS'.substr($l_post_keys[$i], strrpos($l_post_keys[$i], '_'))]);
			} // if
		} // for


		$l_arVMK = array();
		for ($i=0; $i<count($_POST); $i++)
		{
			if (strpos($l_post_keys[$i], 'C__CATG__VSWITCH_VMK_NAME_') !== false)
			{
				$l_arVMK[] = array($_POST[$l_post_keys[$i]],
								   $_POST[substr($l_post_keys[$i], 0, -6).'ADDRESS'.substr($l_post_keys[$i], strrpos($l_post_keys[$i], '_'))]);
			} // if
		} // for

		if ($_GET[C__CMDB__GET__CATLEVEL] != -1 && $_GET[C__CMDB__GET__CATLEVEL] > 0)
		{
			$l_ret = $this->save($_GET[C__CMDB__GET__CATLEVEL],
								 C__RECORD_STATUS__NORMAL,
								 $_POST[C__CATG__VSWITCH_TITLE],
								 $_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()]);

			$this->attach_ports($_GET[C__CMDB__GET__CATLEVEL], $l_ports);
			$this->attach_port_groups($_GET[C__CMDB__GET__CATLEVEL], $l_arPG);
			$this->attach_service_console_ports($_GET[C__CMDB__GET__CATLEVEL], $l_arSCP);
			$this->attach_vmkernel_ports($_GET[C__CMDB__GET__CATLEVEL], $l_arVMK);
		}
		else
		{
			$l_ret = $this->create($_GET[C__CMDB__GET__OBJECT],
								   C__RECORD_STATUS__NORMAL,
								   $_POST[C__CATG__VSWITCH_TITLE],
								   $_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()]);

			$this->attach_ports($l_ret, $l_ports);
			$this->attach_port_groups($l_ret, $l_arPG);
			$this->attach_service_console_ports($l_ret, $l_arSCP);
			$this->attach_vmkernel_ports($l_ret, $l_arVMK);
			$p_cat_level = null;
		} // if

		return $l_ret;
	} // function

	/**
	 * Executes the operations to create the category entry for the object referenced by isys_obj__id $p_objID
	 *
	 * @param int $p_objID
	 * @param int $p_recStatus
	 * @param String $p_title
	 * @param String $p_description
	 * @return int the newly created ID or false
	 * @author Dennis Bluemer <dbluemer@i-doit.org>
	 */
	public function create($p_objID, $p_recStatus, $p_title, $p_description) {
		$l_update = "INSERT INTO isys_catg_virtual_switch_list SET ".
					"isys_catg_virtual_switch_list__isys_obj__id = ".$this->convert_sql_id($p_objID).", ".
					"isys_catg_virtual_switch_list__status = ".$this->convert_sql_id($p_recStatus).", ".
					"isys_catg_virtual_switch_list__title = ".$this->convert_sql_text($p_title).", ".
					"isys_catg_virtual_switch_list__description = ".$this->convert_sql_text($p_description);

		if ($this->update($l_update) && $this->apply_update())
			return $this->get_last_insert_id();
		else
			return false;
	} // function


	/**
	 * Executes the operations to save the category entry referenced bv its ID $p_cat_level
	 *
	 * @param int $p_cat_level
	 * @param int $p_recStatus
	 * @param String $p_title
	 * @param String $p_description
	 * @return boolean true, if operations executed successfully, else false
	 * @author Dennis Bluemer <dbluemer@i-doit.org>
	 */
	public function save($p_cat_level, $p_recStatus, $p_title, $p_description) {
		$l_update = "UPDATE isys_catg_virtual_switch_list SET ".
					"isys_catg_virtual_switch_list__status = ".$this->convert_sql_id($p_recStatus).", ".
					"isys_catg_virtual_switch_list__title = ".$this->convert_sql_text($p_title).", ".
					"isys_catg_virtual_switch_list__description = ".$this->convert_sql_text($p_description).
					"WHERE isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_cat_level);

		if ($this->update($l_update))
			return $this->apply_update();
		else
			return false;
	} // function

	public function get_ports($p_objID, $p_status = null) {
		$l_query = "SELECT * FROM isys_catg_port_list WHERE isys_catg_port_list__isys_obj__id = ".$this->convert_sql_id($p_objID);

		if(!is_null($p_status))
		{
			$l_query .= " AND isys_catg_port_list__status = ".$this->convert_sql_int($p_status);
		} // if

		return $this->retrieve($l_query);
	} // function


	public function get_connected_ports($p_vswitchID) {
		$l_query = "SELECT * FROM isys_virtual_switch_2_port WHERE isys_virtual_switch_2_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_vswitchID);

		$l_res = $this->retrieve($l_query);
		$l_ports = array();
		while ($l_row = $l_res->get_row())
		{
			$l_ports[] = $l_row['isys_virtual_switch_2_port__isys_catg_port_list__id'];
		} // while

		return $l_ports;
	} // function


	public function get_assigned_ports($p_vswitchID) {
		$l_query = "SELECT * FROM isys_virtual_switch_2_port ".
				   "INNER JOIN isys_catg_port_list ON isys_catg_port_list__id = isys_virtual_switch_2_port__isys_catg_port_list__id ".
				   "WHERE isys_virtual_switch_2_port__isys_catg_virtual_switch_list__id = ".$this->convert_sql_id($p_vswitchID);

		return $this->retrieve($l_query);
	} // function


	public function get_connected_clients($p_objID, $p_pgName) {
		$l_query = "SELECT isys_obj__id, isys_obj__isys_obj_type__id, isys_obj__title FROM isys_virtual_device_host ".
				   "INNER JOIN isys_catg_virtual_device_list ON isys_catg_virtual_device_list__id = isys_virtual_device_host__isys_catg_virtual_device_list__id ".
				   "INNER JOIN isys_obj ON isys_obj__id = isys_catg_virtual_device_list__isys_obj__id ".
				   "INNER JOIN isys_catg_virtual_machine_list ON isys_catg_virtual_machine_list__isys_obj__id = isys_obj__id ".
				   "INNER JOIN isys_connection ON isys_connection__id = isys_catg_virtual_machine_list__isys_connection__id ".
				   "WHERE isys_virtual_device_host__switch_port_group = ".$this->convert_sql_text($p_pgName)." ".
				   "AND isys_connection__isys_obj__id = ".$this->convert_sql_id($p_objID)." ".
				   "AND isys_catg_virtual_machine_list__vm = ".$this->convert_sql_id(C__VM__GUEST);

		return $this->retrieve($l_query);
	} // function


	/**
	 * Adds new port group.
	 *
	 * @param int $p_catlevel
	 * @param string $p_title
	 * @param string $p_vlanid
	 * @return bool
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function add_port_group($p_catlevel, $p_title, $p_vlanid){
		$l_update = "INSERT INTO isys_virtual_port_group ".
					"(isys_virtual_port_group__isys_catg_virtual_switch_list__id, ".
					"isys_virtual_port_group__title, ".
					"isys_virtual_port_group__vlanid) ".
					"VALUES ";

		$l_update .= "(".$this->convert_sql_id($p_catlevel).", ".
						 $this->convert_sql_text($p_title).", ".
						 $this->convert_sql_text($p_vlanid).") ";

		if (!$this->update($l_update))
			return false;

		return $this->apply_update();
	} // function

} // class

?>
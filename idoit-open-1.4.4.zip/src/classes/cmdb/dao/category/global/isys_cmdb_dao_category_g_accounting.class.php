<?php

/**
 * i-doit
 *
 * DAO: global category for accounting
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Dennis Bluemer <dbluemer@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_accounting extends isys_cmdb_dao_category_global
{
	/**
	 * Category's name. Will be used for the identifier, constant, main table, and many more.
	 * @var  string
	 */
	protected $m_category = 'accounting';

	/**
	 * Category entry is purgable
	 * @var bool
	 */
	protected $m_is_purgable = true;

	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function properties()
	{
		return array(
			'inventory_no' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__ACCOUNTING_INVENTORY_NO',
						C__PROPERTY__INFO__DESCRIPTION => 'Inventory number'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__inventory_no'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_INVENTORY_NO'
					)
				)),
			'account' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog_plus(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__ACCOUNTING_ACCOUNT',
						C__PROPERTY__INFO__DESCRIPTION => 'Account'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__isys_account__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_account',
							'isys_account__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING__ACCOUNT',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_account'
						)
					)
				)),
			'acquirementdate' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::date(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_AQUIRE',
						C__PROPERTY__INFO__DESCRIPTION => 'Acquirement date'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__acquirementdate'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_ACQUIRE'
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'date'
						)
					)
				)),
			'contact' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_PURCHASED_AT',
						C__PROPERTY__INFO__DESCRIPTION => 'Purchased at'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__isys_contact__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_contact',
							'isys_contact__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__PURCHASE_CONTACT',
						C__PROPERTY__UI__PARAMS => array(
							'multiselection' => true,
							'catFilter' => 'C__CATS__PERSON;C__CATS__PERSON_GROUP;C__CATS__ORGANIZATION',
							'p_strSelectedID' => new isys_callback(array('isys_cmdb_dao_category_g_accounting', 'callback_property_contact'))
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => true,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__SEARCH => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'contact'
						)
					)
				)),
			'price' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::money(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_PRICE',
						C__PROPERTY__INFO__DESCRIPTION => 'Cash value / Price'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__price'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_PRICE'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__REPORT => true
					)
				)),
			'operation_expense' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::money(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__ACCOUNTING__OPERATION_EXPENSE',
						C__PROPERTY__INFO__DESCRIPTION => 'Operational expense'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__operation_expense'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING__OPERATION_EXPENSE'
					),
				)),
			'operation_expense_interval' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__ACCOUNTING__OPERATION_EXPENSE__UNIT',
						C__PROPERTY__INFO__DESCRIPTION => 'Interval unit of expense'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__isys_interval__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_interval',
							'isys_interval__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING__OPERATION_EXPENSE_INTERVAL',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_interval'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false
					)
				)),
			'invoice_no' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_INVOICE_NO',
						C__PROPERTY__INFO__DESCRIPTION => 'Invoice no.'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__invoice_no'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_INVOICE_NO'
					)
				)),
			'order_no' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_ORDER_NO',
						C__PROPERTY__INFO__DESCRIPTION => 'Order no.'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__order_no'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_ORDER_NO'
					)
				)),
			'guarantee_period' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::int(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_GUARANTEE_PERIOD',
						C__PROPERTY__INFO__DESCRIPTION => 'Period of warranty'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__guarantee_period'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_GUARANTEE_PERIOD'
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'timeperiod',
                            array(NULL),
						),
						C__PROPERTY__FORMAT__UNIT => 'guarantee_period_unit'
					)
				)),
			'guarantee_period_unit' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_GUARANTEE_PERIOD_UNIT',
						C__PROPERTY__INFO__DESCRIPTION => 'guarantee period unit field'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__isys_guarantee_period_unit__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_guarantee_period_unit',
							'isys_guarantee_period_unit__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__ACCOUNTING_GUARANTEE_PERIOD_UNIT',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_guarantee_period_unit'
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false
					)
				)),
			'guarantee_period_status'  => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_GUARANTEE_STATUS',
						C__PROPERTY__INFO__DESCRIPTION => 'Order no.'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__id'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__VALIDATION => false,
						C__PROPERTY__PROVIDES__IMPORT => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__EXPORT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'get_guarantee_status'
						)
					)
				)),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__description'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__ACCOUNTING
					)
				))
		);
	} // function


	/**
	 * Dynamic property price
	 *
	 * @return array
	 */
	protected function dynamic_properties()
	{
		return array(
			'_price' => array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_PRICE',
					C__PROPERTY__INFO__DESCRIPTION => 'Cash value / Price'
				),
				C__PROPERTY__DATA => array(
					C__PROPERTY__DATA__FIELD => 'isys_catg_accounting_list__price'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						$this,
						'dynamic_property_callback_price'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true,
					C__PROPERTY__PROVIDES__REPORT => true
				)
			)
		);
	} // function

	/**
	 * Dynamic property handling for price
	 *
	 * @param   array  $p_row
	 * @return  string
	 */
	public function dynamic_property_callback_price($p_row){
		global $g_comp_database;

		$l_return = null;
		if(!empty($p_row['isys_catg_accounting_list__price']))
		{
			$l_arSessData = $_SESSION["session_data"];
			$l_objLoc = isys_locale::get($g_comp_database, $l_arSessData['isys_user_session__isys_obj__id']);
			// Decimal seperator from the user configuration.
			$l_monetary = $l_objLoc->fmt_monetary($p_row['isys_catg_accounting_list__price']);
			$l_monetary_tmp = explode(" ", $l_monetary);
			$l_return = $l_monetary_tmp[0] . ' ' . $l_monetary_tmp[1];
		} // if
		return $l_return;
	} // function

	/**
	 * Callback method for the device dialog-field.
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @param   isys_request  $p_request
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function callback_property_contact(isys_request $p_request)
	{
		global $g_comp_database;
		$l_return = array();

		/**
		 * IDE Typehinting.
		 * @var  $l_accounting_dao  isys_cmdb_dao_category_g_accounting
		 */
		$l_accounting_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_accounting', $g_comp_database)
			->get_data(null, $p_request->get_object_id())
			->get_row();

		/**
		 * IDE Typehinting.
		 * @var  $l_person_dao  isys_cmdb_dao_category_g_contact
		 */
		$l_person_res = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_contact', $g_comp_database)
			->get_assigned_contacts_by_relation_id($l_accounting_dao["isys_catg_accounting_list__isys_contact__id"]);

		while ($l_row = $l_person_res->get_row())
		{
			$l_return[] = $l_row['isys_obj__id'];
		} // while

		return $l_return;
	} // function


	/**
	 * Method for calculating the guarantee status.
	 *
	 * @param   string   $p_acquirementdate
	 * @param   integer  $p_guarantee_period
	 * @param   mixed    $p_guarantee_period_unit
	 * @return  mixed
	 */
	public function calculate_guarantee_status($p_acquirementdate, $p_guarantee_period, $p_guarantee_period_unit)
	{
		if (is_numeric($p_guarantee_period) && $p_guarantee_period_unit != '')
		{
			$l_period_unit = (!is_numeric($p_guarantee_period_unit)) ? constant($p_guarantee_period_unit) : $p_guarantee_period_unit;

			switch ($l_period_unit)
			{
				case C__GUARANTEE_PERIOD_UNIT_DAYS:
					$l_guarantee_enddate = strtotime("+{$p_guarantee_period} days", $p_acquirementdate);
					break;

				case C__GUARANTEE_PERIOD_UNIT_WEEKS:
					$l_guarantee_enddate = strtotime("+{$p_guarantee_period} weeks", $p_acquirementdate);
					break;

				case C__GUARANTEE_PERIOD_UNIT_MONTH:
					$l_guarantee_enddate = strtotime("+{$p_guarantee_period} months", $p_acquirementdate);
					break;

				case C__GUARANTEE_PERIOD_UNIT_YEARS:
					$l_guarantee_enddate = strtotime("+{$p_guarantee_period} years", $p_acquirementdate);
					break;

				default:
					$l_guarantee_enddate = 0;
					break;
			} // switch

			if (time() < $l_guarantee_enddate)
			{
                $l_guarantee_enddate_OBJ = new DateTime();
                $l_guarantee_enddate_OBJ->setTimestamp($l_guarantee_enddate);
                $l_date_diff = (array) date_diff(new DateTime(), $l_guarantee_enddate_OBJ);

				$l_calc_result = array();

				if ($l_date_diff["y"] > 0)
				{
					$l_calc_result[] = $l_date_diff["y"] . ' ' . ($l_date_diff["y"] == 1 ?  _L("LC__UNIVERSAL__YEAR") : _L("LC__UNIVERSAL__YEARS"));
				} // if

				if ($l_date_diff["m"] > 0)
				{
					$l_calc_result[] = $l_date_diff["m"] . ' ' . ($l_date_diff["m"] == 1 ?  _L("LC__UNIVERSAL__MONTH") : _L("LC__UNIVERSAL__MONTHS"));
				} // if

				if ($l_date_diff["w"] > 0)
				{
					$l_calc_result[] = $l_date_diff["w"] . ' ' . ($l_date_diff["w"] == 1 ?  _L("LC__UNIVERSAL__WEEK") : _L("LC__UNIVERSAL__WEEKS"));
				} // if

				if ($l_date_diff["d"] > 0)
				{
					$l_calc_result[] = $l_date_diff["d"] . ' ' . ($l_date_diff["d"] == 1 ?  _L("LC__UNIVERSAL__DAY") : _L("LC__UNIVERSAL__DAYS"));
				} // if

				// Rendering a nice output!
				if (count($l_calc_result) > 1)
				{
					$l_calc_result = implode(', ', array_slice($l_calc_result, 0, -1)) . ' ' . _L('LC__UNIVERSAL__AND') . ' ' . end($l_calc_result);
				}
				else
				{
					$l_calc_result = current($l_calc_result);
				} // if
			}
			else
			{
				if ($p_guarantee_period > 0)
				{
					$l_calc_result = _L("LC__UNIVERSAL__GUARANTEE_EXPIRED");
				} // if
			} // if

			return $l_calc_result;
		}
		else
		{
			return false;
		} // if
	} // function
} // class
<?php

/**
 * i-doit
 *
 * DAO: global category for graphics
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Dennis Stuecken <dstuecken@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_g_graphic extends isys_cmdb_dao_category_global
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'graphic';

    /**
     * Is category multi-valued or single-valued?
     * @var  boolean
     */
    protected $m_multivalued = true;


	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function properties()
	{
		return array(
			'title' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::text(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__TITLE',
						C__PROPERTY__INFO__DESCRIPTION => 'Title'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_graphic_list__title'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__GRAPHIC_TITLE'
					)
				)
			),
			'manufacturer' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog_plus(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__MANUFACTURE',
						C__PROPERTY__INFO__DESCRIPTION => 'Manufacturer'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_graphic_list__isys_graphic_manufacturer__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_graphic_manufacturer',
							'isys_graphic_manufacturer__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__GRAPHIC_MANUFACTURER',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_graphic_manufacturer',
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => '-1'
					)
				)
			),
			'memory' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::float(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__MEMORY',
						C__PROPERTY__INFO__DESCRIPTION => 'Memory'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_graphic_list__memory'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__GRAPHIC_MEMORY'
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'convert',
							array('memory')
						),
						C__PROPERTY__FORMAT__UNIT => 'unit'
					)
				)
			),
			'unit' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog_plus(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CATG__MEMORY_UNIT',
						C__PROPERTY__INFO__DESCRIPTION => 'Unit'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_graphic_list__isys_memory_unit__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_memory_unit',
							'isys_memory_unit__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__GRAPHIC_MEMORY_UNIT',
						C__PROPERTY__UI__PARAMS => array(
							'p_strTable' => 'isys_memory_unit',
							'p_bDbFieldNN' => 1
						),
						C__PROPERTY__UI__DEFAULT => C__MEMORY_UNIT__B
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__SEARCH => false
					)
				)
			),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__LOGBOOK__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_graphic_list__description'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__GRAPHIC
					)
				)
			)
		);
	} // function


    public function sync($p_category_data, $p_object_id, $p_status)
    {
	    assert('is_array($p_category_data) && count($p_category_data) > 0');
	    assert('is_numeric($p_object_id) && $p_object_id >= 0');
	    assert('is_numeric($p_status)');
	    $this->m_sync_catg_data = $p_category_data;
	    $l_indicator = FALSE;

	    switch ($p_status)
	    {
		    case isys_import_handler_cmdb::C__CREATE:
			    if (($p_category_data['data_id'] = $this->create(
				    $p_object_id,
				    C__RECORD_STATUS__NORMAL,
				    $this->get_property('title'),
				    $this->get_property('manufacturer'),
				    $this->get_property('memory'),
				    $this->get_property('unit'),
				    $this->get_property('description')))
			    )
			    {
				    $l_indicator = TRUE;
			    }
			    break;
		    case isys_import_handler_cmdb::C__UPDATE:
			    $l_indicator = $this->save(
				    $p_category_data['data_id'],
				    C__RECORD_STATUS__NORMAL,
				    $this->get_property('title'),
				    $this->get_property('manufacturer'),
				    $this->get_property('memory'),
				    $this->get_property('unit'),
				    $this->get_property('description'));
			    break;
	    }
	    return ($l_indicator === TRUE) ? $p_category_data['data_id'] : FALSE;
    }

	/**
	 * Return Category Data
	 *
	 * @param [int $p_id]
	 * @param [int $p_obj_id]
	 * @param [string $p_condition]
	 *
	 * @return isys_component_dao_result
	 */
	public function get_data($p_catg_list_id=NULL, $p_obj_id=NULL, $p_condition="", $p_filter=NULL, $p_status=NULL) {
		$p_condition .= $this->prepare_filter($p_filter);

		$l_sql = "SELECT * FROM isys_catg_graphic_list ".
					"INNER JOIN isys_obj ".
						"ON ".
						"isys_catg_graphic_list__isys_obj__id = ".
						"isys_obj__id ".
					"LEFT JOIN isys_memory_unit ".
						"ON ".
						"isys_memory_unit__id = ".
						"isys_catg_graphic_list__isys_memory_unit__id ".
					"LEFT JOIN isys_graphic_manufacturer ".
						"ON ".
						"isys_graphic_manufacturer__id = ".
						"isys_catg_graphic_list__isys_graphic_manufacturer__id ".

					"WHERE TRUE ";

		$l_sql .= $p_condition;

		if (!empty($p_obj_id)) {
			$l_sql .= $this->get_object_condition($p_obj_id);
		}

		if (!empty($p_catg_list_id)) {
			$l_sql .= " AND (isys_catg_graphic_list__id = ".$this->convert_sql_id($p_catg_list_id).")";
		}

		if (!empty($p_status)) {
			$l_sql .= " AND (isys_catg_graphic_list__status = '{$p_status}')";
		}

		return $this->retrieve($l_sql);
	}


	/**
	 * Import-Handler for this category
	 * @author Dennis Stuecken <dstuecken@i-doit.org>
	 */
	public function import($p_data) {
		global $g_comp_registry;

		if (count($p_data) > 0) {

			$l_dao_logb = new isys_module_logbook();
			$l_category_title = $this->get_category_by_const_as_string($this->get_category_const());
			$l_logb_active = $g_comp_registry->__get("[Root]/Idoit/Constants/H_INVENTORY__LOGBOOK_ACTIVE");

			/* Iterate through Graphic-Adapters */
			foreach ($p_data as $l_graphic) {
				/* Save / Create */
				$l_status	= -1;
				/* Cat-New: 0, Cat-Save: ? */
				$l_cat 		= -1;

				/* Prepare additional _POST variables */

				/* !empty() checks are done inside isys_import::check_dialog, so they are not needed here */
				$_POST["C__CATG__GRAPHIC_MANUFACTURER"] =
					isys_import::check_dialog("isys_graphic_manufacturer", $l_graphic["manufacturer"]);

				/* Use MB as default unit, if memory_unit is empty */
				if (empty($l_graphic["memory_unit"])) {
					$_POST["C__CATG__GRAPHIC_MEMORY_UNIT"] =
						isys_import::check_dialog("isys_memory_unit", "MB");
				} else {
					$_POST["C__CATG__GRAPHIC_MEMORY_UNIT"] =
						isys_import::check_dialog("isys_memory_unit", $l_graphic["memory_unit"]);
				}

				$_POST['C__CATG__GRAPHIC_MEMORY'] = $l_graphic["memory"];
				$_POST['C__CATG__GRAPHIC_TITLE'] = $l_graphic["name"];

				$l_ids[] = $this->save_element($l_cat, $l_status, true);

				if(isset($l_logb_active) && $l_logb_active){
					$l_category_values[isys_import_handler_cmdb::C__PROPERTIES] = array('title' => array('value' => $l_graphic["name"]),
																						'memory' => array('value' => $l_graphic["memory"]),
																						'manufacturer' => array('title_lang' => $l_graphic["manufacturer"]),
																						'unit' => array('title_lang' => (isset($l_graphic["memory_unit"])? $l_graphic["memory_unit"]: 'MB')));

					$l_changes[$l_category_title] = $l_dao_logb->prepare_changes($this, NULL, $l_category_values);
					if(count($l_changes) > 0)
						$this->set_arrLogbookEntries($l_changes);
				}
			}
		}

		return $l_ids;
	}

	/**
	 * Executes the query to create the category entry.
	 *
	 * @param   integer  $p_object_id
	 * @param   integer  $p_status
	 * @param   string   $p_title
	 * @param   integer  $p_manufacturer_id
	 * @param   string   $p_memory
	 * @param   integer  $p_memory_unit_id
	 * @param   string   $p_description
	 * @return  mixed
	 */
	public function create($p_object_id, $p_status, $p_title, $p_manufacturer_id, $p_memory, $p_memory_unit_id, $p_description)
	{
		$p_memory = isys_convert::memory($p_memory, $p_memory_unit_id);

		$l_sql = "INSERT INTO isys_catg_graphic_list SET " .
			"isys_catg_graphic_list__memory = '" . $p_memory . "', " .
			"isys_catg_graphic_list__isys_memory_unit__id = " . $this->convert_sql_id($p_memory_unit_id) . ", " .
			"isys_catg_graphic_list__title = " . $this->convert_sql_text($p_title) . ", " .
			"isys_catg_graphic_list__isys_graphic_manufacturer__id = " . $this->convert_sql_id($p_manufacturer_id) . ", " .
			"isys_catg_graphic_list__status = " . $this->convert_sql_id($p_status) . ", " .
			"isys_catg_graphic_list__description = " . $this->convert_sql_text($p_description) . ", " .
			"isys_catg_graphic_list__isys_obj__id = " . $this->convert_sql_id($p_object_id);

		if ($this->update($l_sql) && $this->apply_update())
		{
			return $this->get_last_insert_id();
		} // if

		return false;
	} // function


	/**
	 * Executes the query to save the category entry given by its ID $p_cat_level.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  $p_status
	 * @param   string   $p_title
	 * @param   string   $p_manufacturer_id
	 * @param   string   $p_memory
	 * @param   string   $p_memory_unit_id
	 * @param   string   $p_description
	 * @return  boolean
	 */
	public function save($p_cat_level, $p_status, $p_title, $p_manufacturer_id, $p_memory, $p_memory_unit_id, $p_description)
	{
		$p_memory = isys_convert::memory($p_memory, $p_memory_unit_id);

		$l_sql = "UPDATE isys_catg_graphic_list SET " .
			"isys_catg_graphic_list__memory = '" . $p_memory . "', " .
			"isys_catg_graphic_list__isys_memory_unit__id = " . $this->convert_sql_id($p_memory_unit_id) . ", " .
			"isys_catg_graphic_list__title = " . $this->convert_sql_text($p_title) . ", " .
			"isys_catg_graphic_list__isys_graphic_manufacturer__id = " . $this->convert_sql_id($p_manufacturer_id) . ", " .
			"isys_catg_graphic_list__status = " . $this->convert_sql_id($p_status) . ", " .
			"isys_catg_graphic_list__description = " . $this->convert_sql_text($p_description) . " " .
			"WHERE isys_catg_graphic_list__id = " . $this->convert_sql_id($p_cat_level);

		if ($this->update($l_sql))
		{
			return $this->apply_update();
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Save element method.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  $p_status
	 * @param   boolean  $p_create
	 * @return  mixed
	 * @author  Dennis Stuecken <dstuecken@i-doit.org>
	 */
	public function save_element(&$p_cat_level, &$p_status, $p_create = false)
	{
		$l_catdata = $this->get_result()->__to_array();
		$p_status = $l_catdata["isys_catg_graphic_list__status"];

		try
		{
			if ($p_create)
			{
				$l_id = $this->create(
					$_GET[C__CMDB__GET__OBJECT],
					C__RECORD_STATUS__NORMAL,
					$_POST["C__CATG__GRAPHIC_TITLE"],
					$_POST["C__CATG__GRAPHIC_MANUFACTURER"],
					$_POST["C__CATG__GRAPHIC_MEMORY"],
					$_POST["C__CATG__GRAPHIC_MEMORY_UNIT"],
					$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()]);

				if ($l_id != false)
				{
					$this->m_strLogbookSQL = $this->get_last_query();
					$p_cat_level = null;
					return $l_id;
				} // if
			}
			else
			{
				$l_bRet = $this->save(
					$l_catdata["isys_catg_graphic_list__id"],
					$l_catdata["isys_catg_graphic_list__status"],
					$_POST["C__CATG__GRAPHIC_TITLE"],
					$_POST["C__CATG__GRAPHIC_MANUFACTURER"],
					$_POST["C__CATG__GRAPHIC_MEMORY"],
					$_POST["C__CATG__GRAPHIC_MEMORY_UNIT"],
					$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()]);

				if ($l_bRet)
				{
					$this->m_strLogbookSQL = $this->get_last_query();
					return null;
				} // if
			} // if
		}
		catch (isys_exception_cmdb $e)
		{
			isys_glob_display_message("Graphic: " . $e->getMessage());
		} // try

		return false;
	} // function


	/**
	 * Builds an array with minimal requirement for the sync function
	 *
	 * @param $p_data
	 *
	 * @return array
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function parse_import_array($p_data){

		if(!empty($p_data['manufacturer']))
			$l_manufacturer = isys_import_handler::check_dialog('isys_graphic_manufacturer', $p_data['manufacturer']);
		else $l_manufacturer = null;

		return
			array(
				'data_id' => $p_data['data_id'],
				'properties' => array(
					'title' => array(
						'value' => $p_data['title']
					),
					'manufacturer' => array(
						'value' => $l_manufacturer
					),
					'memory' => array(
						'value' => $p_data['memory']
					),
					'unit' => array(
						'value' => $p_data['unit']
					),
					'description' => array(
						'value' => $p_data['description']
					)
				)
			);
	}

} // class
?>
<?php

/**
 * i-doit
 *
 * DAO: specific category for organizations with assigned contacts.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Van Quyen Hoang <qhoang@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_s_organization_contact_assign extends isys_cmdb_dao_category_specific
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'organization_contact_assign';

    /**
     * Is category multi-valued or single-valued?
     * @var boolean
     */
    protected $m_multivalued = true;

	/**
	 * Category's identifier.
	 * @var    integer
     * @fixme  No standard behavior!
	 */
	protected $m_category_id = C__CATS__ORGANIZATION_CONTACT_ASSIGNMENT;

    /**
     * Category's constant.
     * @var    string
     * @fixme  No standard behavior!
     */
    protected $m_category_const = 'C__CATS__ORGANIZATION_CONTACT_ASSIGNMENT';

    /**
     * Category's template.
     * @var  string
     */
    protected $m_tpl = 'cats__contact_assign.tpl';

	/**
	 * Category's main table
	 * @var		string
	 */
	protected $m_table = 'isys_catg_contact_list';

    /**
     * Method for returning the properties.
     *
     * @return  array
     */
    protected function properties()
    {
        return array(
            'object' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::object_browser(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__LOGBOOK__TITLE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Title'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_catg_contact_list__isys_obj__id'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CONTACT__ORGANISATION_TARGET_OBJECT',
                        C__PROPERTY__UI__PARAMS => array(
                            'groupFilter' => 'C__OBJTYPE_GROUP__INFRASTRUCTURE;C__OBJTYPE_GROUP__OTHER;C__OBJTYPE_GROUP__SOFTWARE'
                        )
                    ),
	                C__PROPERTY__PROVIDES => array(
		                C__PROPERTY__PROVIDES__SEARCH => false,
		                C__PROPERTY__PROVIDES__REPORT => false,
		                C__PROPERTY__PROVIDES__LIST => false
	                ),
                    C__PROPERTY__FORMAT => array(
                        C__PROPERTY__FORMAT__CALLBACK => array(
                            'isys_export_helper',
                            'object'
                        )
                    )
                )
            ),
            'role' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog_plus(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CONTACT_ROLE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Role'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_catg_contact_list__isys_contact_tag__id',
                        C__PROPERTY__DATA__REFERENCES => array(
                            'isys_contact_tag',
                            'isys_contact_tag__id',
                        ),
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CONTACT__ORGANISATION_ROLE',
                        C__PROPERTY__UI__PARAMS => array(
                            'p_strTable' => 'isys_contact_tag'
                        )
                    ),
	                C__PROPERTY__PROVIDES => array(
		                C__PROPERTY__PROVIDES__SEARCH => false,
		                C__PROPERTY__PROVIDES__REPORT => false,
		                C__PROPERTY__PROVIDES__LIST => false
	                )
                )
            )
        );
    }

    /**
     * Synchronizes properties from an import with the database.
     *
     * @param array $p_category_data Values of category data to be saved.
     * @param int $p_object_id Current object identifier (from database)
     * @param int $p_status Decision whether category data should be created or
     * just updated.
     *
     * @return mixed Returns category data identifier (int) on success, true
     * (bool) if nothing had to be done, otherwise false.
     */
	public function sync($p_category_data, $p_object_id, $p_status) {

        assert('is_array($p_category_data) && count($p_category_data) > 0');
        assert('is_numeric($p_object_id) && $p_object_id >= 0');
        assert('is_numeric($p_status)');

		/**
		 * Typehinting
		 * @var $l_dao_connection isys_cmdb_dao_connection
		 */
		$l_dao_connection = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao_connection', $this->get_database_component());

        // Create category data identifier if needed:
        if ($p_status === isys_import_handler_cmdb::C__CREATE) {
            $p_category_data['data_id'] = $this->create_connector(
                'isys_catg_contact_list',
                $p_object_id
            );
			$l_connection_id = $l_dao_connection->add_connection($p_category_data['properties']['object'][C__DATA__VALUE]);
        }
		else
		{
			$l_connection_id = $l_dao_connection->retrieve_connection('isys_catg_contact_list', $p_category_data['data_id'], 'isys_catg_contact_list__isys_connection__id');
			$l_dao_connection->update_connection($l_connection_id, $p_category_data['properties']['object'][C__DATA__VALUE]);
		} // if

        if ($p_status === isys_import_handler_cmdb::C__CREATE ||
            $p_status === isys_import_handler_cmdb::C__UPDATE) {
            // Save category data:
            $l_status = $this->save(
                $p_category_data['data_id'],
                C__RECORD_STATUS__NORMAL,
				$l_connection_id,
                $p_category_data['properties']['role'][C__DATA__VALUE],
                $p_object_id,
                $p_category_data['properties']['description'][C__DATA__VALUE]
            );
            if ($l_status === true) {
                return $p_category_data['data_id'];
            } else {
                return false;
            } // if
        } // if

        return true;
	} // function

	/**
	 * Return Category Data
	 *
	 * @param [int $p_id]h
	 * @param [int $p_obj_id]
	 * @param [string $p_condition]
	 *
	 * @return isys_component_dao_result
	 */
	public function get_data($p_cats_list_id=null, $p_obj_id=null, $p_condition="", $p_filter=NULL, $p_status=null) {
		$p_condition .= $this->prepare_filter($p_filter);

		$l_sql = "SELECT catg.*, o1.*, isys_connection.* FROM isys_catg_contact_list AS catg ".
				 "INNER JOIN isys_connection ".
				 	"ON isys_connection__id = catg.isys_catg_contact_list__isys_connection__id ".
				 "LEFT JOIN isys_contact_tag ".
				 	"ON isys_contact_tag__id = catg.isys_catg_contact_list__isys_contact_tag__id ".
				 "INNER JOIN isys_obj AS o1 ".
				 	"ON catg.isys_catg_contact_list__isys_obj__id = o1.isys_obj__id ".
				 "INNER JOIN isys_obj AS o2 ".
				 	"ON o2.isys_obj__id = isys_connection__isys_obj__id ".
				 "WHERE TRUE ";

		if (!empty($p_cats_list_id)) {
			$l_sql .= " AND (catg.isys_catg_contact_list__id = '".$p_cats_list_id."')";
		}

		if (!is_null($p_status)) {
			$l_sql .= " AND (catg.isys_catg_contact_list__status = '".$p_status."')";
		}

		if (!empty($p_obj_id)) {
			$l_sql .= $this->get_object_condition($p_obj_id);
		}

		$l_res = $this->retrieve($l_sql);

		return $l_res;
	}

	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition($p_obj_id = NULL){
		$l_sql = '';

		if (!empty($p_obj_id)) {
			if(is_array($p_obj_id)){
				$l_sql = ' AND (isys_connection__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ') ';
			} else{
				$l_sql = ' AND (isys_connection__isys_obj__id = '.$this->convert_sql_id($p_obj_id).') ';
			}
		}
		return $l_sql;
	}

	/**
	 * Get count for graying the category title
	 *
	 * @param unknown_type $p_obj_id
	 * @return unknown
	 */
	public function get_count($p_obj_id = null){

		if(!empty($p_obj_id))
			$l_obj_id = $p_obj_id;
		else $l_obj_id = $this->m_object_id;

		$l_sql = "SELECT COUNT(isys_catg_contact_list__id) as `count` FROM isys_catg_contact_list ".
					 "INNER JOIN isys_connection ".
					 "ON isys_connection__id = isys_catg_contact_list__isys_connection__id ".
					 "WHERE isys_catg_contact_list__status = '".C__RECORD_STATUS__NORMAL."' ";

		if (!empty($l_obj_id)) {
			$l_sql .= " AND (isys_connection__isys_obj__id = ".$this->convert_sql_id($l_obj_id).")";
		}

		$l_data = $this->retrieve($l_sql)->__to_array();

		return $l_data["count"];
	}

	/**
	 * Save specific category monitor
	 *
	 * @param $p_cat_level level to save, default 0
	 * @param &$p_intOldRecStatus __status of record before update
	 */
	public function save_element($p_cat_level, &$p_intOldRecStatus) {
		$l_catdata         = $this->get_general_data();

		$p_intOldRecStatus = $l_catdata["isys_catg_contact_list__status"];

		$l_list_id = $l_catdata["isys_catg_contact_list__id"];

		if (empty($l_list_id)){
			$l_list_id = $this->create_connector("isys_catg_contact_list", $_POST["C__CONTACT__ORGANISATION_TARGET_OBJECT__HIDDEN"]);
			$l_connection_id = $this->create_connector("isys_connection", $_GET[C__CMDB__GET__OBJECT]);
		} else{
			$l_connection_id = $l_catdata["isys_catg_contact_list__isys_connection__id"];
		}

		if ($l_list_id)	{
			$l_bRet = $this->save($l_list_id,
								  C__RECORD_STATUS__NORMAL,
								  $l_connection_id,
								  $_POST["C__CONTACT__ORGANISATION_ROLE"],
								  $_POST["C__CONTACT__ORGANISATION_TARGET_OBJECT__HIDDEN"],
								  $_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()]);

			$this->m_strLogbookSQL = $this->get_last_query();

		}
		return $l_bRet  == true ? $l_list_id : -1 ;
	}


	public function save($p_catlevel, $p_status = C__RECORD_STATUS__NORMAL, $p_connection, $p_role, $p_objID, $p_description) {
		$l_sql = "UPDATE isys_catg_contact_list SET ".
				 "isys_catg_contact_list__status = ".$this->convert_sql_id($p_status).", ".
				 "isys_catg_contact_list__isys_connection__id = ".$this->convert_sql_id($p_connection).", ".
				 "isys_catg_contact_list__isys_contact_tag__id = ".$this->convert_sql_id($p_role).", ".
				 "isys_catg_contact_list__isys_obj__id = ".$this->convert_sql_id($p_objID).", ".
				 "isys_catg_contact_list__description = ".$this->convert_sql_text($p_description)." ".
				 "WHERE isys_catg_contact_list__id = ".$p_catlevel;

		if ($this->update($l_sql))	{

			if($this->apply_update()){
				$l_dao_relation = new isys_cmdb_dao_category_g_relation($this->m_db);

				$l_catdata = $this->get_data($p_catlevel)->__to_array();

				if($p_role > 0){
					$l_sql = "SELECT * FROM isys_contact_tag WHERE isys_contact_tag__id = ".$this->convert_sql_id($p_role);
					$l_contact_tag = $this->retrieve($l_sql)->__to_array();

					$l_relation_type_arr = $l_dao_relation->get_relation_type($l_contact_tag['isys_contact_tag__isys_relation_type__id'])->__to_array();

					$l_relation_type = $l_contact_tag['isys_contact_tag__isys_relation_type__id'];
					switch($l_relation_type_arr['isys_relation_type__default'])
					{
						case C__RELATION_DIRECTION__DEPENDS_ON_ME:
							$l_slave = $l_catdata["isys_connection__isys_obj__id"];
							$l_master = $l_catdata["isys_catg_contact_list__isys_obj__id"];
							break;
						case C__RELATION_DIRECTION__I_DEPEND_ON:
						default:
							$l_slave = $l_catdata["isys_catg_contact_list__isys_obj__id"];
							$l_master = $l_catdata["isys_connection__isys_obj__id"];
							break;
					}
				} else{
					$l_relation_type = C__RELATION_TYPE__USER;
					$l_master = $l_catdata["isys_catg_contact_list__isys_obj__id"];
					$l_slave = $l_catdata["isys_connection__isys_obj__id"];
				}

				$l_dao_relation->handle_relation($p_catlevel, "isys_catg_contact_list", $l_relation_type, $l_catdata["isys_catg_contact_list__isys_catg_relation_list__id"], $l_master, $l_slave);

				return true;
			}
		}

		return false;
	}

	/**
	 * Executes the query to create the category entry
	 *
	 * @param int $p_objID
	 * @param int $p_newRecStatus
	 * @param String $p_display
	 * @param int $p_unitID
	 * @param int $p_typeID
	 * @param int $p_resolutionID
	 * @param String $p_description
	 * @return int the newly created ID or false
	 * @author Dennis Bluemer <dbluemer@i-doit.org>
	 */
	public function create($p_objID, $p_newRecStatus, $p_description) {
		return null;
	}


	/**
 	 * Verifiy posted data, save set_additional_rules and validation state for further usage.
	 *
 	 * @return TRUE if posted Data is verified, FALSE if not
 	 */
	public function validate_user_data() 
	{
		return true;
	}


	public function rank_records($p_objects, $p_direction, $p_table) {
		global $g_comp_database;

		$l_dao_contact = new isys_cmdb_dao_category_g_contact($g_comp_database);
		$l_dao_relation = new isys_cmdb_dao_category_g_relation($g_comp_database);

		switch($_POST[C__GET__NAVMODE]){
			case C__NAVMODE__ARCHIVE:
					$l_status = C__RECORD_STATUS__ARCHIVED;
				break;
			case C__NAVMODE__DELETE:
					$l_status = C__RECORD_STATUS__DELETED;
				break;
			case C__NAVMODE__RECYCLE:

					if(intval(isys_glob_get_param("cRecStatus")) == C__RECORD_STATUS__ARCHIVED){
						$l_status = C__RECORD_STATUS__NORMAL;
					} elseif(intval(isys_glob_get_param("cRecStatus")) == C__RECORD_STATUS__DELETED){
						$l_status = C__RECORD_STATUS__ARCHIVED;
					}
				break;
			case C__NAVMODE__QUICK_PURGE:
			case C__NAVMODE__PURGE:
 					if(!empty($_POST["id"])){
 						foreach($_POST["id"] AS $l_val){
 							$l_dao_contact->delete($l_val);
 						}
 						unset($_POST["id"]);
 					}
 					return true;
 				break;

		}

		foreach($p_objects AS $l_catg_id){
			$l_data = $l_dao_contact->get_data($l_catg_id)->__to_array();

			if($l_dao_contact->save($l_catg_id, $_GET[C__CMDB__GET__OBJECT], $l_data["isys_catg_contact_list__isys_contact_tag__id"], $l_data["isys_catg_contact_list__description"], $l_status)){
				$l_data = $l_dao_contact->get_data($l_catg_id)->__to_array();
				$l_rel_data = $l_dao_relation->get_data($l_data["isys_catg_contact_list__isys_catg_relation_list__id"])->__to_array();

				$l_dao_relation->set_object_status($l_rel_data["isys_catg_relation_list__isys_obj__id"], $l_status);
			}
		}

		return true;
	}

} // class

?>
<?php

/**
 * i-doit
 *
 * DAO: ObjectType list for ports (subcategory of network)
 *
 * @package     i-doit
 * @subpackage  CMDB_Category_lists
 * @author      Niclas Potthast <npotthast@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_list_catg_network_port
    extends isys_cmdb_dao_list
{
    /**
     * Return constant of category.
     *
     * @return  integer
     * @author  Niclas Potthast <npotthast@i-doit.org>
     */
    public function get_category()
    {
        return C__CATG__NETWORK;
    } // function

    /**
     * Return constant of category type.
     *
     * @return  integer
     * @author  Niclas Potthast <npotthast@i-doit.org>
     */
    public function get_category_type()
    {
        return C__CMDB__CATEGORY__TYPE_GLOBAL;
    } // function

    /**
     * Returns the resultset for the list.
     *
     * @param   integer $p_object_id
     *
     * @return  isys_component_dao_result
     */
    public function get_result($p_tableName = NULL, $p_object_id, $p_cRecStatus = NULL)
    {
        $l_condition = "";

        if (!is_null($_GET["ifaceID"]))
        {
            $l_condition = " AND (isys_catg_netp_list__id = '" . $_GET["ifaceID"] . "')";
        } // if
        $l_cRecStatus = empty($p_cRecStatus) ?
            $this->get_rec_status() :
            $p_cRecStatus;

        return $this->m_cat_dao->get_data(NULL, $p_object_id, $l_condition, NULL, $l_cRecStatus);
    } // function

    /**
     * Retrieve the header-fields.
     *
     * @return  array
     * @author  Niclas Potthast <npotthast@i-doit.org>
     */
    public function get_fields()
    {
        return array(
            'isys_catg_port_list__title'         => _L('LC__CMDB__CATG__NETWORK__TITLE'),
            'interface'                          => _L('LC__CMDB__CATG__NETWORK_TREE_CONFIG_INTERFACE_P'),
            'isys_port_type__title'              => _L('LC__CMDB__CATG__NETWORK__TYPE'),
            'isys_catg_port_list__mac'           => _L('LC__CMDB__CATG__NETWORK__MAC'),
            'assigned_layer2_nets'               => _L('LC__CMDB__LAYER2_NET'),
            'ip_address'                         => _L('LC__CMDB__CATG__NETWORK__PRIM_IP'),
            'object_connection'                  => _L('LC__CMDB__CATG__NETWORK__TARGET_OBJECT'),
            'connector_title'                    => _L('LC__CATG__STORAGE_CONNECTION_TYPE'),
            'isys_catg_port_list__state_enabled' => _L('LC__CATP__IP__ACTIVE')
        );
    } // function

    /**
     * Exchange column to create individual links in columns.
     *
     * @global  array $g_dirs
     *
     * @param   array $p_arrRow (by reference)
     *
     * @todo    switch numbers with constants
     */
    public function modify_row(&$p_arrRow)
    {
        global $g_dirs;

        $p_arrRow["object_connection"]    = "-";
        $p_arrRow["connector_connection"] = "-";

        if (!empty($p_arrRow["isys_cable_connection__id"]))
        {

            $l_dao = new isys_cmdb_dao_cable_connection($this->m_db);

            $l_objID   = $l_dao->get_assigned_object($p_arrRow["isys_cable_connection__id"], $p_arrRow["isys_catg_connector_list__id"]);
            $l_objInfo = $l_dao->get_type_by_object_id($l_objID)->get_row();

            if ($l_objInfo["isys_obj_type__id"] > 0)
            {
                $l_strImage = '<img src="' . $g_dirs["images"] . 'icons/silk/link.png" class="vam" />';

                // create link obj
                $l_link = isys_helper_link::create_url(
                    array(
                        C__CMDB__GET__OBJECT     => $l_objID,
                        C__CMDB__GET__OBJECTTYPE => $l_objInfo["isys_obj_type__id"],
                        C__CMDB__GET__VIEWMODE   => C__CMDB__VIEW__LIST_CATEGORY,
                        C__CMDB__GET__CATG       => C__CMDB__SUBCAT__NETWORK_PORT,
                        C__CMDB__GET__TREEMODE   => $_GET[C__CMDB__GET__TREEMODE]
                    )
                );

                // exchange the specified column
                $p_arrRow["object_connection"] = '<a href="' . $l_link . '">' . $l_strImage . ' ' . $l_objInfo['isys_obj__title'] . '</a>';

                $p_arrRow["connector_title"] = $l_dao->get_assigned_connector_name($p_arrRow["isys_catg_port_list__isys_catg_connector_list__id"], $p_arrRow["isys_cable_connection__id"]);
            } // if
        } // if

        // We only display primary IP addresses.
        if ($p_arrRow['isys_catg_ip_list__primary'] == 1)
        {
            $l_ip_address_dao = new isys_cmdb_dao_category_s_net_ip_addresses($this->m_db);

            $l_ip_address = $l_ip_address_dao->get_data($p_arrRow['isys_catg_ip_list__isys_cats_net_ip_addresses_list__id'])
                ->get_row();

            $p_arrRow['ip_address'] = $l_ip_address['isys_cats_net_ip_addresses_list__title'];

            // Whe shorten the IPv6 addresses.
            if ($p_arrRow['isys_catg_ip_list__isys_net_type__id'] == C__CATS_NET_TYPE__IPV6)
            {
                $p_arrRow['ip_address'] = isys_helper_ip::validate_ipv6($l_ip_address['isys_cats_net_ip_addresses_list__title'], true);
            } // if
        } // if

        if ($p_arrRow['isys_catg_port_list__state_enabled'] >= 1)
        {
            $p_arrRow['isys_catg_port_list__state_enabled'] = '<span class="vam green">' .
	            '<img src="' . $g_dirs['images'] . 'icons/silk/bullet_green.png" alt="Yes" class="mr5 vam" /><span>' . _L('LC__UNIVERSAL__YES') . '</span></span>';
        }
        else
        {
            $p_arrRow['isys_catg_port_list__state_enabled'] = '<span class="vam red">' .
	            '<img src="' . $g_dirs['images'] . 'icons/silk/bullet_red.png" alt="No" class="mr5 vam" /><span>' . _L('LC__UNIVERSAL__NO') . '</span></span>';
        } // if

        $p_arrRow['isys_catg_port_list__title'] = '<span title="' . $p_arrRow['isys_catg_port_list__title'] . '">' .
            isys_glob_str_stop($p_arrRow['isys_catg_port_list__title'], 30) .
            '</span>';

        if (!empty($p_arrRow['isys_catg_netp_list__title']))
        {
            $p_arrRow['interface'] = '<span title="' . $p_arrRow['isys_catg_netp_list__title'] . '">' .
                isys_glob_str_stop($p_arrRow['isys_catg_netp_list__title'], 30) .
                '</span>';
        }
        elseif ($p_arrRow['isys_catg_hba_list__title'])
        {
            $p_arrRow['interface'] = '<span title="' . $p_arrRow['isys_catg_hba_list__title'] . '">' .
                isys_glob_str_stop($p_arrRow['isys_catg_hba_list__title'], 30) .
                '</span>';
        }

        $l_assigned_layer2_nets = $this->m_cat_dao->get_attached_layer2_net_as_array($p_arrRow['isys_catg_port_list__id']);
        $l_default_vlan_id      = $this->m_cat_dao->get_default_vlan_id();
        $l_default_vlan         = '';

        if (count($l_assigned_layer2_nets) > 0)
        {
            $l_quicklink = new isys_ajax_handler_quick_info();
            $l_list      = array();

            foreach ($l_assigned_layer2_nets as $l_l2_obj)
            {
                $l_layer2_cat = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_layer2_net', $this->m_db)
                    ->get_data(NULL, $l_l2_obj)
                    ->get_row();

                if ($l_layer2_cat !== false)
                {
                    if (empty($l_layer2_cat['isys_cats_layer2_net_list__ident']))
                    {
                        $l_layer2_cat['isys_cats_layer2_net_list__ident'] = '-';
                    } // if

                    $l_list[] = $l_quicklink->get_quick_info(
                        $l_layer2_cat['isys_obj__id'],
                        $l_layer2_cat['isys_obj__title'] . ' (VLAN: ' . $l_layer2_cat['isys_cats_layer2_net_list__ident'] . ')',
                        C__LINK__OBJECT
                    );
                    $l_object_id = $l_layer2_cat['isys_obj__id'];
                }
                else
                {
                    // The "layer2 net" category was not filled, but we still got the object information!
                    $l_layer2_obj = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao', $this->m_db)
                        ->get_object($l_l2_obj)
                        ->get_row();

                    $l_list[] = $l_quicklink->get_quick_info(
                        $l_layer2_obj['isys_obj__id'],
                        $l_layer2_obj['isys_obj__title'],
                        C__LINK__OBJECT
                    );
                    $l_object_id = $l_layer2_obj['isys_obj__id'];
                }

                if ($l_default_vlan_id == $l_object_id)
                {
                    $l_default_vlan = array_pop($l_list);
                }
            } // foreach

            if ($l_default_vlan)
            {
                $p_arrRow['assigned_layer2_nets'] = '<ul class="fl"><li class="border-bottom border-ccc mr10">Untagged (Standard VLAN)</li><li>' . $l_default_vlan . '</li></ul>';

                if (count($l_list))
                {
                    $p_arrRow['assigned_layer2_nets'] .= '<ul class="fl"><li class="border-bottom border-ccc">Tagged</li><li>' . implode('</li><li>', $l_list) . '</li></ul>';
                }
            }
            else
            {
                $p_arrRow['assigned_layer2_nets'] = '<ul class="fl"><li>' . implode('</li><li>', $l_list) . '</li></ul>';
            }
        }
        else
        {
            $p_arrRow['assigned_layer2_nets'] = '-';
        } // if
    } // function

    public function get_order_condition($p_column, $p_direction)
    {
        $l_condition = "";

        switch ($p_column)
        {
            case "isys_catg_port_list__title":
                $l_condition = "LENGTH(" . $p_column . ") " . $p_direction . ", " . $p_column . " " . $p_direction;
                break;
            default:
                $l_condition = parent::get_order_condition($p_column, $p_direction);
        }

        return $l_condition;
    }

    public function __construct(isys_cmdb_dao_category &$p_cat)
    {
        parent::__construct($p_cat);
    }
}

?>
<?php
/**
* i-doit
*
* DAO: ObjectType list for physical interfaces (subcategory of network)
*
* @package i-doit
* @subpackage CMDB_Category_lists
* @author Niclas Potthast <npotthast@i-doit.org> - 2006-02-22
* @copyright synetics GmbH
* @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
*/

class isys_cmdb_dao_list_catg_network_interface
extends isys_cmdb_dao_list
{
	/**
	 * Return constant of category
	 *
	 * @return integer
	 * @author Niclas Potthast <npotthast@i-doit.org> - 2006-09-27
	 */
	public function get_category() {
		return C__CATG__NETWORK;
	}

	/**
	 * Return constant of category type
	 *
	 * @return integer
	 * @author Niclas Potthast <npotthast@i-doit.org> - 2006-09-27
	 */
	public function get_category_type() {
		return C__CMDB__CATEGORY__TYPE_GLOBAL;
	}

	/**
	* @return isys_component_dao_result
	* @param string $p_str
	* @param integer $p_nID foreign key, i.e. the object id
	* @author Niclas Potthast <npotthast@i-doit.org> - 2006-02-22
	* @desc get result set for all interfaces for the current object
	*/
	public function get_result($p_strTableName=ISYS_NULL, $p_object_id, $p_cRecStatus=null) {
		global $g_cmdb_view;

		$l_strSQL =
			"SELECT * ".
			"FROM ".
				"isys_catg_netp_list ".
			"WHERE ".
				"isys_catg_netp_list__isys_obj__id = ".
				"'$p_object_id'";

		$l_cRecStatus = empty($p_cRecStatus) ? $this->get_rec_status() : $p_cRecStatus;
		if (!empty($l_cRecStatus)) {
			$l_strSQL.= " AND isys_catg_netp_list__status = ".
				"'".$l_cRecStatus."'";
		}

		$l_strSQL.=";";

		return $this->retrieve($l_strSQL);
	}

	/**
	 * Returns array with table headers
	 *
	 * @return array
	 * @global $g_comp_template_language_manager
	 * @author Niclas Potthast <npotthast@i-doit.org> - 2006-03-23
	 */
 	public function get_fields() {
 		global $g_comp_template_language_manager;

		return array(
			"isys_catg_netp_list__title" =>
				$g_comp_template_language_manager->
				{"LC__CMDB__CATG__INTERFACE_L__TITLE"},
			"isys_catg_netp_list__slotnumber" =>
				$g_comp_template_language_manager->
				{"LC__CMDB__CATG__INTERFACE_P_SLOTNUMBER"},
			"showports"                  =>
				"",
			"createports"                =>
				"",
		);
 	}

	/**
	 * Exchange column to create individual links in columns
	 *
	 * @global $g_active_modreq
	 * @global $g_dirs
	 * @param array $p_arrRow (by reference)
	 * @author Niclas Potthast <npotthast@i-doit.org> - 2005-03-24
	 * @todo switch numbers with constants
	 */
	public function modify_row(&$p_arrRow)
	{
		global $g_active_modreq, $g_dirs;

		$l_gets = $g_active_modreq->get_gets();

		//id of current physical interface
		$l_nIfaceID = $p_arrRow["isys_catg_netp_list__id"];

		$l_link = isys_helper_link::create_url(array(
			C__CMDB__GET__OBJECT => $l_gets[C__CMDB__GET__OBJECT],
			C__CMDB__GET__OBJECTTYPE => $l_gets[C__CMDB__GET__OBJECTTYPE],
			C__CMDB__GET__VIEWMODE => C__CMDB__VIEW__CATEGORY,
			C__CMDB__GET__CATG => C__CMDB__SUBCAT__NETWORK_PORT,
			C__CMDB__GET__TREEMODE => $l_gets[C__CMDB__GET__TREEMODE],
			C__GET__NAVMODE => C__NAVMODE__NEW,
			C__CMDB__GET__EDITMODE => C__EDITMODE__ON,
			"ifaceID" => $l_nIfaceID
		));

		$p_arrRow["createports"] = '<a href="' . $l_link . '" title="' . _L('LC__CMDB__CATG__NETWORK__NEW_PORTS__TOOLTIP') . '">' .
			'<img alt="" height="15" width="15" style="padding-right:5px;" src="' . $g_dirs["images"] . 'icons/navbar/new_icon.png" />' .
			_L('LC__CMDB__CATG__NETWORK__NEW_PORTS') . '</a>';

		$l_link = isys_helper_link::create_url(array(
			C__CMDB__GET__VIEWMODE => C__CMDB__VIEW__LIST_CATEGORY,
			C__CMDB__GET__TREEMODE => $l_gets[C__CMDB__GET__TREEMODE],
			C__CMDB__GET__OBJECT => $l_gets[C__CMDB__GET__OBJECT],
			C__CMDB__GET__OBJECTTYPE => $l_gets[C__CMDB__GET__OBJECTTYPE],
			C__CMDB__GET__CATG => C__CMDB__SUBCAT__NETWORK_PORT,
			"ifaceID" => $l_nIfaceID
		));

		$p_arrRow["showports"] = '<a href="'.$l_link.'" title="'._L('LC__CMDB__CATG__NETWORK__ASSO_PORTS__TOOLTIP').'">'.
				'<img alt="" height="15" width="15" style="padding-right:5px;" src="'.$g_dirs["images"].'icons/silk/link.png" class="vam" />'.
				_L('LC__CMDB__CATG__NETWORK__ASSO_PORTS').'</a>';
	} // function
} // class
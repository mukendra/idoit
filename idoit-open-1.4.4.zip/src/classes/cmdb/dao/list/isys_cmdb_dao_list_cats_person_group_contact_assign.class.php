<?php
/**
* i-doit
*
* DAO: Class for overview category
*
* @package i-doit
* @subpackage CMDB_Category_lists
* @author Van Quyen Hoang <qhoang@i-doit.org>
* @copyright synetics GmbH
* @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
*/

class isys_cmdb_dao_list_cats_person_group_contact_assign
extends isys_cmdb_dao_list
{


	/**
	 * @return integer
	 */
	public function get_category() {
		return C__CATS__PERSON_GROUP_CONTACT_ASSIGNMENT;
	}

	/**
	 * @return integer
	 */
	public function get_category_type() {
		return C__CMDB__CATEGORY__TYPE_SPECIFIC;
	}

	/**
	 * @param string $p_table
	 * @param integer $p_id
	 * @return isys_component_dao_result
	 * @version Dennis Blümer <dbluemer@i-doit.org>
	 */
	public function get_result($p_str = null, $p_objID, $p_cRecStatus=null) {
		$l_sql = "SELECT catg.*, o1.*, ot.*, isys_contact_tag.* FROM isys_catg_contact_list AS catg ".
				 "INNER JOIN isys_connection ".
				 "ON isys_connection__id = catg.isys_catg_contact_list__isys_connection__id ".
				 "INNER JOIN isys_obj AS o1 ".
				 "ON catg.isys_catg_contact_list__isys_obj__id = o1.isys_obj__id ".
				 "INNER JOIN isys_obj_type AS ot ".
				 "ON o1.isys_obj__isys_obj_type__id = ot.isys_obj_type__id ".
				 "INNER JOIN isys_obj AS o2 ".
				 "ON o2.isys_obj__id = isys_connection__isys_obj__id ".
				 "LEFT JOIN isys_contact_tag ".
				 "ON isys_contact_tag__id = catg.isys_catg_contact_list__isys_contact_tag__id ".
				 "WHERE isys_connection__isys_obj__id = ".$this->convert_sql_id($p_objID)." ";

		$l_cRecStatus = empty($p_cRecStatus) ? $this->get_rec_status() : $p_cRecStatus;
		if(!empty($l_cRecStatus)){
			$l_sql .= "AND catg.isys_catg_contact_list__status = ".$this->convert_sql_id($l_cRecStatus);
		}

		return $this->retrieve($l_sql);
	}


	/**
	 * Returns array with table headers.
	 *
	 * @return  array
	 */
	public function get_fields ()
	{
		return array(
			"isys_obj__title" => "LC__CMDB__LOGBOOK__TITLE",
			"isys_obj_type__title" => "LC__CMDB__OBJTYPE",
			"isys_contact_tag__title" => "LC__CMDB__CONTACT_ROLE"
		);
	} // function


	/**
	 * Modify row method.
	 *
	 * @param  array  &$p_arrRow
	 */
	public function modify_row (&$p_arrRow)
	{
		if ($p_arrRow["isys_obj__id"] != null)
		{
			$l_link = isys_helper_link::create_url(array(
				C__CMDB__GET__OBJECT => $p_arrRow["isys_obj__id"],
				C__CMDB__GET__OBJECTTYPE => $p_arrRow["isys_obj__isys_obj_type__id"],
				C__CMDB__GET__VIEWMODE => C__CMDB__VIEW__CATEGORY,
				C__CMDB__GET__CATG => C__CATG__GLOBAL,
				C__CMDB__GET__TREEMODE => $_GET["tvMode"]
			));

			$p_arrRow["isys_obj__title"] = '<a href="' . $l_link . '">' . $p_arrRow["isys_obj__title"] . '</a>';
		} // if
	} // function


	/**
	 * Make row link method.
	 *
	 * @global  isys_module_request  $g_active_modreq
	 * @param   array  $p_arrGetUrlOverride
	 * @return  string
	 */
	public function make_row_link ($p_arrGetUrlOverride = null)
	{
		global $g_active_modreq;

		$l_sql = 'SELECT isys_obj__id, isys_obj_type__isys_obj_type_group__id, isys_obj__isys_obj_type__id
			FROM isys_obj
			INNER JOIN isys_obj_type ON isys_obj_type__id = isys_obj__isys_obj_type__id
			WHERE isys_obj__id = ' . $this->convert_sql_id($_GET[C__CMDB__GET__OBJECT]) . ';';

		$l_catdata = $this->retrieve($l_sql)->get_row();
		$l_gets = $g_active_modreq->get_gets();

		$l_arrGetUrl = array(
			C__CMDB__GET__VIEWMODE => C__CMDB__VIEW__CATEGORY_GLOBAL,
			C__CMDB__GET__TREEMODE => $l_gets[C__CMDB__GET__TREEMODE],
			C__CMDB__GET__OBJECT => $l_catdata["isys_obj__id"],
			C__CMDB__GET__CATS => C__CATS__PERSON_GROUP_CONTACT_ASSIGNMENT,
			C__CMDB__GET__OBJECTGROUP => $l_catdata["isys_obj_type__isys_obj_type_group__id"],
			C__GET__MAIN_MENU__NAVIGATION_ID => $l_gets["mNavID"],
			C__CMDB__GET__OBJECTTYPE => $l_catdata["isys_obj__isys_obj_type__id"],
			C__CMDB__GET__CATLEVEL => "[{isys_catg_contact_list__id}]"
		);

		if (is_array($p_arrGetUrlOverride))
		{
			while (list($l_key, $l_val) = each($p_arrGetUrlOverride))
			{
				$l_arrGetUrl[$l_key] = $p_arrGetUrlOverride[$l_key];
			} // while
		} // if

		return isys_helper_link::create_url($l_arrGetUrl);
	} // function
} // class
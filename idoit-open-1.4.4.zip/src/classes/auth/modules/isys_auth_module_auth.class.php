<?php

/**
 * i-doit
 *
 * Auth: Class for Auth module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_auth extends isys_auth
{
	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array(
			'overview' => array(
				'title' => _L('LC__AUTH_GUI__AUTH_OVERVIEW'),
				'type' => 'boolean',
				'rights' => array(isys_auth::VIEW),
				'defaults' => array(isys_auth::VIEW)
			),
			'module' => array(
				'title' => _L('LC__AUTH_GUI__AUTH_MODULES'),
				'type' => 'modules'
			)
		);
	} // function


	/**
	 * Checks, if the current user is allowed to see the auth-overview.
	 *
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function overview ()
	{
		return $this->generic_boolean('overview', new isys_exception_auth(_L('LC__AUTH__AUTH_EXCEPTION__MISSING_RIGHT_FOR_OVERVIEW')));
	} // function


	/**
	 * @param   integer $p_right
	 * @param   integer $p_id
	 * @throws  isys_exception_general
	 * @throws  isys_exception_auth
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function module ($p_right, $p_id)
	{
		$l_module_const = strtoupper($p_id);

		if (! defined($l_module_const))
		{
			throw new isys_exception_general(_L('LC__EXCEPTION__CONSTANT_COULD_NOT_BE_FOUND', $l_module_const));
		} // if

		if (array_key_exists('module', $this->m_paths))
		{
			if (array_key_exists(isys_auth::WILDCHAR, $this->m_paths['module']) && in_array($p_right, $this->m_paths['module'][isys_auth::WILDCHAR]))
			{
				return true;
			} // if

			if (array_key_exists($p_id, $this->m_paths['module']) && in_array($p_right, $this->m_paths['module'][$p_id]))
			{
				return true;
			} // if
		} // if

		// Retrieve the module row, to display a nice exception message.
		$l_module = isys_module_manager::instance()->get_modules(constant($l_module_const))->get_row();

		throw new isys_exception_auth(_L('LC__AUTH__AUTH_EXCEPTION__MISSING_RIGHT_FOR_MODULE', _L($l_module['isys_module__title'])));
	} // function
} // class
?>
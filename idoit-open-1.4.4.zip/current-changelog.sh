#!/bin/bash

CURRENT_VERSION=`php --run 'include("src/version.inc.php"); echo(\$g_product_info["version"]);'`

cd /Users/dstuecken/coding/php/idoit-pro/updates/versions/v${CURRENT_VERSION}
./update-changelog.php
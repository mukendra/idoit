<?php
/**
 * @author Dennis Stuecken
 * @package i-doit
 * @subpackage General
 * @copyright synetics GmbH
 * @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
global $g_comp_database, $g_config, $g_absdir, $g_comp_database_system, $g_comp_template, $g_product_info, $l_dao_mandator;

try
{
	$l_module_manager = new isys_module_manager();
	$l_dao_mandator   = new isys_component_dao_mandator($g_comp_database_system);

	switch ($_REQUEST['action'])
	{
		case 'add':
			
            try
			{
				if (isset($_POST['mandator']))
				{
					if (isset($_FILES['module_file']))
					{
						if ($_FILES['module_file']['tmp_name'])
						{
							if (install_module($_FILES['module_file']['tmp_name'], $_POST['mandator']))
							{
								$g_comp_template->assign("message", 'Module successfully installed.');
							}
						}
						else
						{
							throw new Exception('Error: Please provide a valid i-doit module zip file');
						}
					}
					else {
						throw new Exception('Error: Please provide a valid i-doit module zip file');
					}
				}
				else
				{
					throw new Exception('Error: Select a module');
				}
			} catch (Exception $e)
			{
				$g_comp_template->assign("error", $e->getMessage());
			}

			break;
		case 'deactivate':

			if (isset($_REQUEST['module']) && is_array($_REQUEST['module']))
			{

				foreach ($_REQUEST['module'] as $l_tenant => $l_modules)
				{
                    if ($l_tenant)
                    {
                        connect_mandator($l_tenant);

                        foreach ($l_modules as $l_module)
                        {
                            if ($l_module)
                            {
                                $l_module_manager->deactivate($l_module);
                            }
                        }
                    }
				}

			}

			break;
        case 'uninstall':

            if (isset($_REQUEST['module']) && is_array($_REQUEST['module']))
			{
				foreach ($_REQUEST['module'] as $l_tenant => $l_modules)
				{
                    if ($l_tenant)
                    {
                        foreach ($l_modules as $l_module)
                        {
                            if ($l_module)
                            {
                                $l_moduleList[] = $l_module;

                            }
                        }
                    }
				}

                if (is_array($l_moduleList) && count($l_moduleList) > 0)
                {
                    $l_tenants = $l_dao_mandator->get_mandator();
                    while ($l_row = $l_tenants->get_row())
                    {
                        connect_mandator($l_row['isys_mandator__id']);
                        $l_mandatorDBs[] = $g_comp_database;
                    }

                    if (count($l_mandatorDBs) > 0)
                    {
                        foreach ($l_moduleList as $l_moduleToDelete)
                        {
                            $l_module_manager->uninstall($l_moduleToDelete, $l_mandatorDBs);
                        }
                    }
                }
			}
            break;
		case 'activate':

			$l_db_update = new isys_update_xml();
			if (isset($_REQUEST['module']) && is_array($_REQUEST['module']))
			{

				foreach ($_REQUEST['module'] as $l_tenant => $l_modules)
				{
					connect_mandator($l_tenant);

					foreach ($l_modules as $l_module)
					{
						if ($l_module)
						{
							$l_module_manager->activate($l_module);

							if (file_exists($g_absdir . '/src/classes/modules/' . $l_module . '/install/update_data.xml'))
							{
								$l_db_update->update_database($g_absdir . '/src/classes/modules/' . $l_module . '/install/update_data.xml', $g_comp_database);
							}

							if (file_exists($g_absdir . '/src/classes/modules/' . $l_module . '/install/update_sys.xml'))
							{
								$l_db_update->update_database($g_absdir . '/src/classes/modules/' . $l_module . '/install/update_sys.xml', $g_comp_database_system);
							}
						}
					}
				}

			}

			break;
		default:

			break;
	}

	/**
	 * Get mandators
	 */
	$l_tenants = $l_dao_mandator->get_mandator();

	/**
	 * Initialize modules
	 */
	$l_directory = $g_absdir . '/src/classes/modules/';
	$l_modules   = array();
	$i           = 0;
	while ($l_tenant = $l_tenants->get_row())
	{
		connect_mandator($l_tenant['isys_mandator__id']);

		$l_dirhandle   = opendir($l_directory);
		$l_modules[$i] = array(
			'id'       => $l_tenant['isys_mandator__id'],
			'title'    => $l_tenant['isys_mandator__title'],
			'active'   => $l_tenant['isys_mandator__active'],
			'licenced' => !!@$l_tenant['isys_licence__id'],
			'expires'  => $l_tenant['isys_licence__expires'],
			'host'     => $l_tenant['isys_mandator__db_host'],
			'db'       => $l_tenant['isys_mandator__db_name']
		);

		$l_licence_serialized_info = utf8_decode($l_tenant['isys_licence__data']);
		$l_licence_info = unserialize($l_licence_serialized_info);

		if ($l_licence_info === null)
		{
			$l_licence_info = unserialize(isys_glob_replace_accent($l_licence_serialized_info));
		} // if

		if (isset($l_licence_info[9]) && is_array($l_licence_info[9]))
		{
			$l_module_licence = array_map('utf8_encode', $l_licence_info[9]);
		}
		else
		{
			$l_module_licence = array();
		} // if

		while (($l_file = readdir($l_dirhandle)) !== false)
		{
			if (is_dir($l_directory . $l_file) && strpos($l_file, '.') !== 0)
			{
				if (file_exists($l_directory . $l_file . '/package.json'))
				{
					$l_package = json_decode(file_get_contents($l_directory . $l_file . '/package.json'), true);
					if ($l_package && $l_module_manager->is_installed($l_package['identifier']))
					{
						$l_package['active']   = $l_module_manager->is_active($l_package['identifier']);

                        if ($l_package['licence'])
						{

                            if ($l_tenant['isys_licence__id'])
                            {
                                if ($l_package['licence'])
                                {
                                    $l_package['licenced'] = isset($l_module_licence[$l_package['identifier']]) ? true : false;
                                }
                            }
                            else
                            {
                                $l_package['licenced'] = false;
                            }

                        } else $l_package['licenced'] = NULL;

						$l_modules[$i]['modules'][] = $l_package;
					}

				}
			}
		}
		$i++;
		closedir($l_dirhandle);
		unset($l_dirhandle);
		$l_tenants_array[] = $l_tenant;
	}

	$g_comp_template->assign('modules', $l_modules);
	if (isset($l_tenants_array))
	{
		$g_comp_template->assign('mandators', $l_tenants_array);
	}

} catch (Exception $e)
{
	$l_response = array(
		"error"   => true,
		"message" => $e->getMessage()
	);

	header("Content-Type: application/json");
	echo json_encode($l_response);
	die;
} // try